
# CREATE EVAL DATASETS
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
# This function creates a list of evaluation datasets. An output list has two levels: sub-population index and a main target index.
# Nil values are imputed in the output datasets and classification covariates are converted to factors.
# note: probably, only one level [[i]] can be left...
#
# input:
#   datList - A list. Each element of this list is a sub-population of the training / testing / scoring population selected according to the "mask" parameter
#     (which defines the rules for sub-population creation).
#   dat - A dataset. The model building population.
#   classificCovShort - A list of short names of classification income keypoints covariates.
#   participation - A vector with names of groups of covariates participated in the modelling.
#   modelTargets - A vector of main model targets.
#   interimModelTargets - A vector of interim model targets.
#   stage - A character string: "modelling" or "scoring".
#   covYearsBack - A number of years that we are looking back during the covariates creation.
#   targetFieldsShort - A list of short names of main targets.
# output: 
#   A list of datasets with imputed missing values and classification covariates converted into factors (so that those datasets are ready to be fed into
# the prediction function).
# CreateEvalSample <- function(datList, dat, classificCovShort, participation, modelTargets, interimModelTargets, stage, covYearsBack, targetFieldsShort, e){
#   i <- 0
#   foreach(i=1:length(datList), .export=c("ImputeMissingValues", "SetClassificFieldsAsFactors"), .errorhandling='pass') %do% {
#                                 
#     datMod <- datList[[i]]
#     #datMod <- datMod[,-which(names(datMod) %in% excludeCov)]
#     datMod <- ImputeMissingValues(datT=datMod, value=0, interimModelTargets=interimModelTargets, classificCovShort=classificCovShort, stage=stage, 
#                                   covYearsBack=covYearsBack, targetFieldsShort=targetFieldsShort) 
#     dat <- ImputeMissingValues(datT=dat, value=0, interimModelTargets=interimModelTargets, classificCovShort=classificCovShort, stage=stage, 
#                                 covYearsBack=covYearsBack, targetFieldsShort=targetFieldsShort)
#     datMod <- SetClassificFieldsAsFactors(datTemp=datMod, dat=dat, classificTargets=c(), classificCovShort=classificCovShort, participation=participation, e=e)
#                                 
#     #foreach(j=modelTargets, .errorhandling='pass') %do% {
#       datMod 
#     #}
#   }
# }   

#------------------------------------------------------------------------------------------------------

# CALCULATE PREDICTIONS
#' @import stats
#' @import randomForest
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
# This function calculates prediction of interim targets on the base of built models for a given population (the testing population / scoring population).
# Predicted probabilities adjustment is available for classification models.
# input:
#   dat - A dataset. The model building population.
#   doAdj - A logical. If TRUE, the adjustment of predicted probabilities is done.
#   modelTargets - A vector of main model targets.
#   interimModelTargets - A vector of interim model targets. 
#   modelFits - A list with the built Random Forest models.
#   evalDat - A list of evaluation datasets.
#   excludeCov - A vector of columns that should be excluded from the dataset before using it for modelling / prediction.
# output:
#   A list with three levels: a sub-population index, a main target index, and an interim target index. Each element of this list contains a dataset (
#   for classification) or a vector (for regression) with predicted values .
PredictValues <- function(datList, datHo, doAdj, modelTargets, interimModelTargets, modelFits, evalDat, excludeCov, alg, mainIndex, sc){
  i <- 0
  #foreach (i=1:1, .export=c("ChoseInterimModels", "CalcIndex"), .errorhandling='pass') %dopar% {
  foreach (i=1:length(datList), .export=c("ChoseInterimModels", "CalcIndex"), .errorhandling='pass') %do% {
    
    #cat("i=", i, "; ")
    j <- 0
    #foreach (j = 1:1, .export=c("ChoseInterimModels", "CalcIndex"), .errorhandling='pass') %do% {
    foreach (j=1:length(modelTargets), .export=c("ChoseInterimModels", "CalcIndex"), .errorhandling='pass') %do% {
      
      #cat("j=", j, "; ")
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')
      
      k <- 0
      #foreach (k = 4:4, .export=c("ChoseInterimModels", "CalcIndex"), .errorhandling='pass') %do% {
      foreach (k=1:length(intTargets), .export=c("ChoseInterimModels", "CalcIndex"), .errorhandling='pass') %do% {
        
        #cat("k=", k, "; ")
        # exclude columns that didn't participate in the model
        newData <- evalDat[[i]]
        excludeCols <- which(names(newData) %in% c(excludeCov))
        if (length(excludeCols) != 0){
          newData <- newData[, -excludeCols]
        }
        target <- intTargets[k]
        
        if (alg == 'RSpark_RF'){
          
          pred <- sparklyr::copy_to(sc, newData, overwrite = TRUE) %>%
            sparklyr::sdf_predict(object=modelFits[[i]][[j]][[k]], newdata= .) %>% 
            dplyr::collect()
          
          sparklyr::tbl_uncache(sc, "newData")
          
          if (grepl(pattern="classification", x=modelFits[[i]][[j]][[k]]$model.parameters$model)){

            tmp <- pred[, "probability"]
            
            appFun1 <- function(x){
              x[[1]][1]
            }

            appFun2 <- function(x){
              x[[1]][2]
            }

            pred$prob0 <- apply(X=tmp, MARGIN=1, FUN=appFun1)
            pred$prob1 <- apply(X=tmp, MARGIN=1, FUN=appFun2)
            pred <- pred[, c("prob0", "prob1")]
            
            lvls <- levels(datHo[, target])
            ind1 <- which(lvls %in% c("POS", "NIL", "TRUE"))
            ind2 <- mainIndex[[i]][[j]][[k]] + 1
            
            names(pred)[ind2] <- lvls[ind1]
            names(pred)[CalcIndex(ind2)] <- lvls[CalcIndex(ind1)]
            
          } else {
            
            pred <- pred$prediction
            
          }
          
          gc()

        } else {
          excl <- which(names(newData) %in% interimModelTargets)
          if (length(excl) != 0){
            newData <- newData[, -excl]
          }
          
          if (modelFits[[i]][[j]][[k]]$type == "classification"){
            pred <- predict(modelFits[[i]][[j]][[k]], newdata=newData, type="prob")
            if (doAdj){
              # prNil <- partNil[[i]][[j]][[k]]
              # prNilT <- partNilT[[i]][[j]][[k]]
              # pred[,2] <- (prNil / prNilT * pred[,2]) / (prNil / prNilT * pred[,2] + (1 - prNil) / (1 - prNilT) * pred[,1])
              # pred[,1] <- 1 - pred[,2]
            }
          } else {
            pred <- predict(modelFits[[i]][[j]][[k]], newdata=newData)
          }
        }
        
        pred
        
      }
    }
  }
}

#------------------------------------------------------------------------------------------------------

CalcIndex <- function(ind){
  if (ind == 1){
    2
  } else {
    1
  }
}


#------------------------------------------------------------------------------------------------------
# Create datasets for evaluation reports
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
# This function creates datasets that can be used for evaluation reports creation, because these datasets contain both real and predicted
# interim targets values.
# input:
#   datList - A list. Each element of this list is a sub-population of the training / testing / scoring population selected according to the "mask" parameter
#     (which defines the rules for sub-population creation).
#   predRes - A list of datasets / vectors with predicted values of interim targets
#   evalDat - A list of datasets with covariates values and real targets values.
#   modelTargets - A vector of main model targets.
#   interimModelTargets - A vector of interim model targets. 
# output:
#   A list with three levels: a sub-population index, a main target index, and an interim target index. Each element contains a data frame with 
#   real and predicted values of an interim model target.
CreateEvalDataset <- function(datList, predRes, evalDat, modelTargets, interimModelTargets){
  i <- 0
  #foreach (i = 1:1, .packages="doParallel", .export="ChoseInterimModels", .errorhandling='pass') %dopar% {
  foreach (i = 1:length(datList), .packages="doParallel", .export="ChoseInterimModels", .errorhandling='pass') %do% {

    j <- 0
    foreach (j = 1:length(modelTargets), .export="ChoseInterimModels", .errorhandling='pass') %do% {
    #foreach (j = 1:1, .export="ChoseInterimModels", .errorhandling='pass') %do% {

      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')

      k <- 0
      foreach (k = 1:length(intTargets), .errorhandling='pass') %do% {

        intTargetData <- evalDat[[i]][,intTargets[k]]

        if (is.factor(intTargetData)) {
          cbind(as.character(intTargetData), as.data.frame(predRes[[i]][[j]][[k]]))
        } else {
          cbind(intTargetData, predRes[[i]][[j]][[k]])
        }
      }
    }
  }
}

#-------------------------------------------------------------------------------

# Combine evaluation results from sub-populations
# input:
#   datList - A list. Each element of this list is a sub-population of the training / testing / scoring population selected according to the "mask" parameter
#     (which defines the rules for sub-population creation). It's used here to know the number of sub-populations.
#   datRes - A list. The function combines separate data frames of this input list.
#   x- An index of a main target. If given, the output will contain combined (through sub-populations) results for that main target. If value is not provided,
#     the default 0 value is used, and the output will not be specific for a certain main target (this option is used to combine scoring results in the 
#     final "outDat" data frame).
#   y - An index of an interim target. If given, the output will contain combined (through sub-populations) results for that interim target. If value if not
#     provided, the default 0 value is used, and the output will not be specific for a certain interim target.
# output:
#   A dataframe combining evaluation results for all sub-populations for the certain interim target / main target / whole results.
CombineResults <- function(datList, datRes, x=0, y=0){
  evalAllResTemp <- data.frame()
    i <- 1
    while (i<=length(datList)) {
      if (x != 0){
        if (y != 0){
          evalAllResTemp <- rbind(evalAllResTemp, datRes[[i]][[x]][[y]], deparse.level = 0)
        } else {
          evalAllResTemp <- rbind(evalAllResTemp, datRes[[i]][[x]], deparse.level = 0)
        }
      } else {
        evalAllResTemp <- rbind(evalAllResTemp, datRes[[i]], deparse.level = 0)  
      }
      i <- i+1
    }
  evalAllResTemp
}

#-------------------------------------------------------------------------------------------------

# The Outstanding Returns Model function
# Define a model type for each keypoint target:
# 1 - target has POS, NIL and NEG values
# 2 - target has NIL and POS values
#	3 - target has NIL and NEG values
# input:
#  name - A main target short name.
#  interimModelTargets - A vector of interim model targets.
# output:
#  A numeric 1, 2, or 3 defining the type of the model, which is used during the main targets calculation.
ORDefineModelType <- function(name, interimModelTargets){
  if (paste0("LABEL_", name) %in% interimModelTargets) {1} else {
    if (paste0(name, "_POS") %in% interimModelTargets) {2} else {3}
  }
}
  
#-------------------------------------------------------------------------------------------------

# Select interim model targets which are used to calculate a given main model target.
# input:
#   modelTarget - A vector of main model targets.
#   interimModelTargets - A vector of interim model targets.
#   numORtext - A character: "num" or "text".
# output:
#   If numORtext="text", then a vector with selected interim model targets names is returned.
#   If numORtext="num", then a vector with selected interim model targets indexes is returned.
ChoseInterimModels <- function(modelTarget, interimModelTargets, numORtext){
  interimTargets <- which(grepl(modelTarget, interimModelTargets))
  if (numORtext == 'num'){
    interimTargets
  } else {
    interimModelTargets[interimTargets]
  }
}
#-------------------------------------------------------------------------------------------------

# This function creates values of classification main targets.
# This kind of main targets do not require several interim targets to be calculated.
# Its' calculation consists of just copying the values of a corresponded interim target.
# Examples of this king of main targets are the Right Returns target or Purification targets.
# input:
#   i - a sub-population index
#   j - a main target index
#   datRes - A list of data frames with predicted values.
#   modelTarget - a main model target name
#   evalDat - A list of evaluation data sets.
# output:
#   a data frame containing real labels and predicted probability values (probability of being TRUE) for a main target (real value will be NA at the scoring stage)
SelectionEvalMainTarget <- function(i, j, datRes, modelTarget, evalDat){
  name <- modelTarget
  if (sum(names(evalDat[[i]]) == modelTarget) == 0) {evalDat[[i]][, modelTarget] <- NA} # at the scoring stage, just fill the real values as NA 
  d <- cbind(as.character(evalDat[[i]][, modelTarget]), as.data.frame(datRes[[i]][[j]][[1]][, "TRUE"])) # combine real values and predicted values
  names(d) <- c("real_value", name)
  d
}

#---------------------------------------------------------------------------

# Right Returns function
# It calculates main targets values in the Right Returns model.
# All main targets in the RR model are classification targets and do not require several interim targets to be calculated.
# So, all that is needed is to use the SelectionEvalMainTarget function to transfer the predictions from the interim level to main targets level.
# input:
#   i - a sub-population index
#   j - a main target index
#   datRes - A list of data frames with predicted values
#   modelTarget - a main model target name
#   modelTargetsList - a vector with additional classification targets names
#   interimModelTargets - a vector of interim model targets
# Note: although "modelTargetsList" and "interimModelTargets" parameters are not used in the function, they are added to keep the list of parameters
# in RREvalMainTargets and OREvalMainTargets the same (to simplify these functions' call)
# output:
#   a data frame containing real labels and predicted probability values (probability of being TRUE) for a main target (real value will be NA at the scoring stage)
RREvalMainTargets <- function(i, j, datRes, modelTarget, modelTargetsList, interimModelTargets, evalDat){
  d <- SelectionEvalMainTarget(i=i, j=j, datRes=datRes, modelTarget=modelTarget, evalDat=evalDat)
  d
}
  
#---------------------------------------------------------------------------

# Outstanding returns function
# It calculates main targets values in the Outstanding Returns model.
# "SelectionEvalMainTarget" is used for classification purification targets.
# A formula for Outstanding returns main targets depends on the type of a target (identified by ORDefineModelType function). The total probability law is used.
# input:
#   i - a sub-population index
#   j - a main target index
#   datRes - A list of data frames with predicted values
#   modelTarget - a main model target name
#   modelTargetsList - a vector with additional classification targets names
#   interimModelTargets - a vector of interim model targets
# output:
#   a) for purification targets: a data frame containing real labels and predicted probability values (prob of being TRUE) for a main target 
#     (real value will be NA at the scoring stage)
#   b) for outstanding returns targets: a data frame containing real values and predicted values (EST_...) for main target and probability of 
#     this target is being nil (PROB_NIL_...)  (real value will be NA at the scoring stage).
OREvalMainTargets <- function(i, j, datRes, modelTarget, modelTargetsList, interimModelTargets, evalDat){
  
  if (modelTarget %in% modelTargetsList){
     d <- SelectionEvalMainTarget(i=i, j=j, datRes=datRes, modelTarget=modelTarget, evalDat=evalDat)
  } else {
    modelType <- ORDefineModelType(name=modelTarget, interimModelTargets=interimModelTargets)
    
    name1 <- paste0("EST_", modelTarget)
    name2 <- paste0("PROB_NIL_", modelTarget)
    
    if (modelType == 1) {
      d <- as.data.frame(cbind(evalDat[[i]][, paste0(modelTarget, "_B0")], datRes[[i]][[j]][[1]][,"NOT NIL"] * datRes[[i]][[j]][[2]][,"POS"] * 
                                 datRes[[i]][[j]][[3]] + datRes[[i]][[j]][[1]][,"NOT NIL"] * datRes[[i]][[j]][[2]][,"NEG"] * datRes[[i]][[j]][[4]], 
                               datRes[[i]][[j]][[1]][,"NIL"]))
    } else {
  	  d <- as.data.frame(cbind(evalDat[[i]][, paste0(modelTarget, "_B0")], datRes[[i]][[j]][[1]][,"NOT NIL"] * datRes[[i]][[j]][[2]],
        datRes[[i]][[j]][[1]][,"NIL"]))
    }
    names(d) <- c("real_value", name1, name2)
  }
  d
}

#######-------------------------------------
#######-------------------------------------

# for a certain model!!!
CalcPerformMeasures <- function(alg, modelFit, testRes, trainRes=data.frame(), trainPerf=FALSE){
  
  if (alg == "R_RF"){
    
    if (modelFit$type == "classification"){
      
      if (trainPerf){
        # Training performance
        cat("***Training performance***\n",
          "OOB error: ", round(modelFit$err.rate[modelFit$ntree, "OOB"] * 100, 2),
          "%\n\nConfusion matrix:\n", sep="")
        
        print(modelFit$confusion)
      }
      
      # Testing performance
      cat("\n\n*Testing performance (cutOff=0.5)*\n\n")
      CalcClassificPerformance(testRes)
      cat("\n------------------------------------\n")
      
    } else {
      # regression
      
      if (trainPerf){
        # Training performance
        cat("***Training performance***\n\n",
          "MSE: ", modelFit$mse[modelFit$ntree],
          "\n\nRoot MSE: ", sqrt(modelFit$mse[modelFit$ntree]),
          "\n\nR-sq: ", modelFit$rsq[modelFit$ntree], "\n",
          sep="")
      }
        
      # Testing performance
      testRes <- as.data.frame(testRes)
      names(testRes) <- c("real_value", "pred_value")
      testRes <- testRes[!is.na(testRes[, "real_value"]), ]
      
      mse <- mean((testRes[, "real_value"] - testRes[, "pred_value"])^2)
      rSq <- 1 - mse / var(testRes[, "real_value"])
      
      cat("\n\n*Testing performance*\n\n",
        "MSE: ", mse,
        "\n\nRoot MSE: ", sqrt(mse),
        "\n\nR-sq: ", rSq, "\n",
        sep="")
      cat("\n------------------------------------\n")
    }
  }
  

  if (alg == "RSpark_RF"){
    
    if (grepl(pattern="classification", x=modelFit$model.parameters$model)){
      
      if (trainPerf){
        # Training performance
        cat("\n\n***Training performance***\n")
        CalcClassificPerformance(trainRes)
      }
        
      # Testing performance
      cat("\n\n*Testing performance (cutOff=0.5)*\n\n")
      CalcClassificPerformance(testRes)
      cat("\n------------------------------------\n")
      
    } else {
      if (trainPerf){
        # Training performance
        cat("\n\n***Training performance***\n")
        CalcRegressionPerformance(trainRes)
      }
      
      # Testing performance
      cat("\n\n*Testing performance*\n\n")
      CalcRegressionPerformance(testRes)
      cat("\n------------------------------------\n")
    }
  }
}

#-----------------------

CalcClassificPerformance <- function(testRes){
  names(testRes)[1] <- "real_value"
      
  testRes <- testRes[!is.na(testRes$real_value), ]
      
  lvls <- levels(testRes$real_value)
  n <-  which(lvls %in% c("POS", "NIL", "TRUE"))
  nCol <- which(names(testRes) %in% c("POS", "NIL", "TRUE"))
  name <- lvls[n]
      
  nTrue <- sum(testRes[, nCol] >= 0.5 & testRes[, "real_value"] == name)  # real true - estim true
  nFalse <- sum(testRes[, nCol] < 0.5 & testRes[, "real_value"] != name)  # real false - estim false
  totTrue <- sum(testRes[, "real_value"] == name)
  totFalse <- sum(testRes[, "real_value"] != name)
  size <- dim(testRes)[1]
      
  err <- 100 - (nTrue + nFalse) / size * 100
  
  cat("Classification error: ", err, "%\n\n", sep="")
      
  for (i in 1:2){
    cat("Class ", lvls[i], " error:" , if (i == n) {1 - nTrue / totTrue} else {1 - nFalse / totFalse},"\n\n", sep="")
  }
}

#-----------------

CalcRegressionPerformance <- function(testRes){
  testRes <- as.data.frame(testRes)
  names(testRes) <- c("real_value", "pred_value")
  testRes <- testRes[!is.na(testRes[, "real_value"]), ]
      
  mse <- mean((testRes[, "real_value"] - testRes[, "pred_value"])^2)
  rSq <- 1 - mse / var(testRes[, "real_value"])
  
  cat("MSE: ", mse,
    "\n\nRoot MSE: ", sqrt(mse),
    "\n\nR-sq: ", rSq,
    "\n",
    sep="")
}


###--------------------

PrintOverfitCheck <- function(datMod, modelTargets=e$modelTargets, interimModelTargets=e$interimModelTargets, alg=e$alg, modelFits=e$modelFits, 
                              evalRes=e$evalRes, evalResMod=list()){
  
  i <- 0
  foreach(i=1:(length(datMod)-1), .packages="doParallel", .export=c("ChoseInterimModels", "CalcPerformMeasures"), .errorhandling='stop') %dopar% {
    
    j <- 0
    foreach(j=1:length(modelTargets), .packages="doParallel", .export=c("ChoseInterimModels", "CalcPerformMeasures"), .errorhandling='stop') %do% {
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')
      
      k <- 0
      foreach(k=1:length(intTargets), .export="OverfitCheck", .packages="doParallel", .errorhandling='stop') %do% {
        
        print(paste0("i=", i, "\n"))
        print(paste0("j=", j, "\n"))
        print(paste0("k=", k, "\n"))
        
        if (alg == "RSpark_RF"){
          CalcPerformMeasures(alg=alg, modelFit=modelFits[[i]][[j]][[k]], testRes=evalRes[[i]][[j]][[k]], trainRes=evalResMod[[i]][[j]][[k]], trainPerf=TRUE)
        } else {
          CalcPerformMeasures(alg=alg, modelFit=modelFits[[i]][[j]][[k]], testRes=evalRes[[i]][[j]][[k]], trainPerf=TRUE)
        }
      }
    }
  }
}


