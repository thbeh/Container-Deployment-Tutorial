
##########------SELECT OBJECTS FOR RIGHT RETURNS MODELLING AND SCORING------############
#'  Select returns for Right Returns modelling and scoring
#'  
#' \code{RRSelectObjects} creates the DB table with returns that will be part of the model building population
#'  (at the modelling stage) or the DB table with returns for which the scoring will be done (at the scoring stage).
#'  
#' The selection procedure consists of three steps:
#'  \enumerate{
#'    \item Select all customers with a return lodgement (for a certain return type) in the year previous to the scoring year. 
#'      This base list of customers is used both at the modelling and scoring stages for steps #2 and #3 (see below). The value of RETURN_PERIOD_DATE
#'      field is defined by the \code{timestamp} value, so that a base return period date is different at the modelling and scoring stages.
#'    \item Remove from the base set all customers with outstanding income tax returns (currently outstanding on the \emph{timetsamp} date).
#'      As far as \code{timestamp} value is different at the modelling and scoring stages, different customers are deleted from the 
#'      base list during the modelling and scoring.
#'    \item Leave only returns which are comply with rules \bold{(a) AND (b) at the modelling stage}, or \bold{at least comply with the rule (b) at 
#'      the scoring stage}:
#'      \describe{
#'        \item{Rule (a)}{To build and evaluate the model, the real value of the return for the modelling base return period date should be known. 
#'          Therefore, for the base return period date (modeling return period date):
#'          \itemize{
#'            \item the return should have been filed, OR
#'            \item the return should have been finalised as not required (NR), OR
#'            \item the return should have been finalised as uneconomical to pursue (UN) by SYSRR (determined by the System as the Right Return)
#'          }
#'        }
#'        \item{Rule (b)}{It is required that the B1 period value of return to be known to improve the robustness of the model 
#'          (although it reduces the number of returns considered). Therefore, for the modelling / scoring base return period date:
#'          \itemize{
#'            \item the return should have been filed, OR
#'            \item the return should have been finalised as not required (NR), OR
#'            \item the return should have been finalised as uneconomical to pursue (UN) by SYSRR (determined by the System as the Right Return)
#'          }
#'        }}
#'      }
#'  
#' 
#' This function is run within \code{\link{RunModelling}} and \code{\link{RunScoring}} functions. It can also be run independently.
#' 
#' @inheritParams MakeDBConnections
#' @inheritParams RunRightReturns
#' @inheritParams PrepareFieldsNames
#' @inheritParams SetModelParameters
#' @param baseTable A name of the DB base table, which is used to store list of returns for the modelling / scoring population creation.
#' @param conn An Oracle connection to the Data Warehouse.
#' @param yearBase  A year for the initial selection of returns for modelling and scoring from RETURN_LODGEMENTS table. It is equal
#'  to the \code{year} parameter's value (a year for Right Returns identification). It is the same for the modelling and scoring stages.
#' @param yearSQL A year for data extraction for B0 period. At the scoring stage, \code{yearSQL} is equal to \code{yearBase},
#'  at the modelling stage, \code{yearSQL} is calculated as \code{yearBase} minus one year.
#' @param timestamp A date. Timestamp is used for timestamping in returns selection and covariates creation scripts to:
#'  \itemize{
#'    \item support reproducibility of the model results
#'    \item at the modelling stage imitate the situation of unavailability of data after a return due date, which is typical at the scoring stage
#'      (so that the model is usually not using the data which is not available during the scoring)
#'  }
#'  At the scoring stage, the \code{timestamp} is equal to \code{timestampB0} (i.e. the date of calculation by default).
#'  At the modelling stage, the \code{timestamp} is calculated as \code{timestampB0} minus 1 year. In more details, in the returns selection procedure
#'  timestamp is used (1) to delete from the population returns which are (were) outstanding on the \emph{timestamp} date; (2) to take into 
#'  account only information (from policing profiles and keypoints tables) that is (was) available by the \emph{timestamp} date.
#'
#' @return A database table with returns selected for Right Returns modelling / scoring.
#'
#' @examples
#' \dontrun{
#'   RRSelectObjects(modRetName='RR_IR3', returnName='IR3', 
#'    stage="modelling", yearSQL=2015, yearBase=2016, e=e)
#' }
#'  
#' @export
RRSelectObjects <- function(returnName=e$returnName, 
                            modRetName=e$modRetName, 
                            projectStage=e$projectStage, 
                            baseTable=e$baseTable, 
                            stage=e$stage,
                            yearSQL, 
                            yearBase, 
                              # yearSQL=2015, yearBase=2016 -- for modelling
                              # yearSQL=2016, yearBase=2016 -- for scoring
                            conn=e$conn, 
                            timestamp, 
                            timestampB0 = eval(e$timestampB0),
                            nrows=e$nrows,
                            e
                          ){
                                                                    
  startM <- Sys.time()
  stepName <- "Select objects for right returns modelling"

  timestamp <- paste0(" to_date('", timestamp,"', 'dd/mm/yyyy') ")
  timestampB0 <- paste0(" to_date('", timestampB0,"', 'dd/mm/yyyy') ")
  
  ##############################################
  # STEP 1. This query is based on an IR6 query example at page 59 of the right returns 
  # documentation: "Right Returns SRS v1.1.pdf".
  # It grabs everyone with a return lodgement (for a certain return type) in the year previous to the current year.
  # This query is run just once at the modelling step, and the results are also used at the scoring step. So the estimation 
  # "is a return is a right return?" is done for returns that were lodged one year ago (minus returns that are not satisfied to 
  # step2 and step3 conditions).
  
  tableName <- paste0(modRetName, "_filter_list")
    
  if (stage == "modelling" | (stage != "modelling" & if (dbExistsTable(conn, toupper(tableName))){
    dim(dbGetQuery(conn, paste0("select * from ", tableName)))[1] == 0} else TRUE)) {
  
    sqlCode <- paste0(
      if (projectStage == "TEST"){
        paste0("CREATE global temporary TABLE ", tableName," on commit preserve rows AS")
      } else {
        paste0("CREATE global temporary TABLE ", tableName," on commit preserve rows AS")
      },
         " SELECT distinct
            TO_CHAR(AL3.date_issued, 'yyyymm') date_issued,
              AL3.ird_number, 
              AL3.location_number,
              to_date('31-03-", yearSQL," 00:00:00','DD-MM-YYYY HH24:MI:SS') as return_period_date, 
              AL3.return_type,
              AL1.RETURN_SOURCE, 
              --AL1.TRANSACTION_STATUS,
              AL2.DESCRIPTION
          FROM 
              RETURN_LODGEMENTS AL1, 
              RETURN_SOURCES AL2,
              (SELECT 
                D0AL1.IRD_NUMBER AS ird_number,
                D0AL1.LOCATION_NUMBER AS location_number,
                D0AL1.RETURN_PERIOD_DATE AS return_period_date,
                D0AL1.RETURN_TYPE AS return_type,
                MIN (D0AL1.DATE_APPLIED) over (partition by D0AL1.IRD_NUMBER, D0AL1.LOCATION_NUMBER, D0AL1.RETURN_PERIOD_DATE) AS date_issued
              FROM 
                RETURN_LODGEMENTS D0AL1
              WHERE 
                (D0AL1.DATE_APPLIED>=to_date('01-01-", yearBase-4," 00:00:00','DD-MM-YYYY HH24:MI:SS') AND
                D0AL1.RETURN_TYPE ", if (returnName == 'IR3All') {"in ('IR3', 'IR3A') "} else {paste0("='", returnName,"' ")}, "AND
                D0AL1.RETURN_PERIOD_DATE=to_date('31-03-", yearBase-1," 00:00:00','DD-MM-YYYY HH24:MI:SS')) AND
                D0AL1.DATE_APPLIED <= ", timestampB0 ," AND
                (D0AL1.DATE_CEASED > ", timestampB0," or D0AL1.DATE_CEASED is null)
              --GROUP BY 
              --  D0AL1.IRD_NUMBER,
              --  D0AL1.LOCATION_NUMBER,
              --  D0AL1.RETURN_PERIOD_DATE,
              --  D0AL1.RETURN_TYPE
                ) AL3
              WHERE 
                (AL1.RETURN_SOURCE = AL2.RETURN_SOURCE (+)    -- left join. Description may be null
                AND AL3.ird_number=AL1.IRD_NUMBER
                AND AL3.location_number=AL1.LOCATION_NUMBER
                AND AL3.return_period_date=AL1.RETURN_PERIOD_DATE
                AND AL3.return_type=AL1.RETURN_TYPE
                AND AL3.date_issued=AL1.DATE_APPLIED)
                AND (AL2.DATE_CEASED (+) IS NULL
                AND AL2.VALIDATED(+)='Y')
    ")
    
    CreateTable(conn, sqlCode, tableName)
  
  } else {
    
    # If the "filter_list" table was created at the modelling stage and it is still not empty, it can be reused at the scoring step.
    # The only thing that is needed to be updated is the RETURN_PERIOD_DATE field values (it should be different for the modelling and scoring stages).
    sqlCode <- paste0("UPDATE ", tableName, " SET return_period_date=to_date('31/03/", yearSQL, "', 'dd/mm/yyyy')")
    dbGetQuery(conn, sqlCode)
    dbCommit(conn)
    
  }
  
   if (projectStage == "TEST")
     ReduceRows(nrows=nrows, tableN=tableName, conn=conn)

  ######################################
  # STEP 2. This query removes from our base set all those with outstanding income tax returns.
  # The script was changed from the usage of the  CURRENT_RETURNS_OUTSTANDING to the POLICING PROFILES WITH TIMESTAMPING
  tableName <- paste0(modRetName, "_base_temp_", stage)
  
#   sqlCode <- paste0("
#     CREATE global TEMPORARY TABLE  ", tableName," ON COMMIT PRESERVE ROWS AS
#       SELECT * 
#       FROM 
#         ", modRetName, "_filter_list 
#       WHERE 
#         ird_number NOT IN 
#           (SELECT  
#             ird_number
#           FROM 
#             current_returns_outstanding b
#           WHERE 
#             b.return_type ", if (returnName == 'IR3All') {"in ('IR3', 'IR3A') "} else {paste0("='", returnName,"' ")}, "AND
#             b.return_period_date < to_date('31/03/", yearSQL,"', 'dd/mm/yyyy') AND
# 				    b.action_status_code = '02')
#     ")
  
  sqlCode <- paste0("
    CREATE global TEMPORARY TABLE  ", tableName," ON COMMIT PRESERVE ROWS AS
      SELECT * 
      FROM 
        ", modRetName, "_filter_list 
      WHERE 
        ird_number NOT IN 
          (SELECT  
            ird_number
          FROM 
            policing_profiles b
          WHERE 
            b.return_type ", if (returnName == 'IR3All') {"in ('IR3', 'IR3A') "} else {paste0("='", returnName,"' ")}, "AND
            b.return_period_date < to_date('31/03/", yearSQL,"', 'dd/mm/yyyy') AND
  			    b.date_finalised is null AND
            b.finalisation_code = 'XX' AND
            b.date_actually_due < ", timestamp," AND
            b.date_applied < ", timestampB0," AND
            (b.date_ceased > ", timestampB0," OR b.date_ceased is null))
    ")
  
  
  CreateTable(conn, sqlCode, tableName)
    
  # Delete some rows if it is a testing stage to reduce calculation time
  if (projectStage == "TEST")
     ReduceRows(nrows=nrows, tableN=tableName, conn=conn)
  
  
  ######################################
  # STEP 3. Leave only returns that comply with (A) and (B) for modelling / comply with (B) for scoring:
  #  (A) (we should know the real value of the return to build and evaluate the model)
  #   - have been filed for the modelling year OR 
  #   - were finalised as not required (NR) OR
  #   - were finalised as uneconomical to pursue (UN) by SYSRR (determined by system as right returns)
  #  AND 
  #  (B) (we require the B1 period value to be known to improve the robustness of the model, but it will reduce the number of returns considered)
  #   - have been filed one year ago OR
  #   - were finalised as NR one year ago OR
  #   - were finalised as UN by SYSRR one year ago
  #
  # Note: this script does not take into account the fact that for IR6 and IR9 return types in and before 2013 tax year right returns weren't 
  # coded as UN by SYSRR and have to be identified through CORRESPONDENCE_OUTBOUND table. This is not significant because it is unlikely that
  # the Right REturns model will be required to be run for 2013 or earlier tax years. However, as far as model covariates are created for several 
  # historical years, CORRESPONDENCE_OUTBOUND table is taken into account at the covariates creation step.
  
  CreateBaseSQL <- function(returnName, modRetName, stage, timestamp, mb){
    paste0("
      SELECT 
        base.ird_number
      FROM ",
      modRetName, "_base_temp_", stage, " base
        JOIN policing_profiles p ON
          base.ird_number = p.ird_number
          AND p.return_period_date = add_months(base.return_period_date, ", mb,")
      WHERE
        p.return_type ", if (returnName == 'IR3All') {"in ('IR3', 'IR3A') "} else {paste0("='", returnName,"' ")}, "
        AND (p.finalisation_code = 'NR' OR (p.finalisation_code = 'UN' AND p.finalised_by = 'SYSRR')) 
        AND p.date_applied < ", timestamp,  
        " AND (p.date_ceased > ", timestamp," OR p.DATE_CEASED IS NULL)
              
    UNION  
          
      SELECT  
        base.ird_number
      FROM ",
  	  modRetName, "_base_temp_", stage, " base
        JOIN returns_keypoints_", if (returnName %in% c('IR3A', 'IR3All')) {"IR3"} else {returnName}," ir ON
          base.ird_number = ir.ird_number
          AND ir.return_period_date = add_months(base.return_period_date, ", mb,") 
        JOIN returns ret ON 
          ret.ird_number = ir.ird_number 
          AND ret.return_period_date = ir.return_period_date 
          AND ret.return_version_no = ir.return_version_no   
      WHERE  
        ret.return_type = '", if (returnName %in% c('IR3A', 'IR3All')) {"IR3"} else {toupper(returnName)},"'
        AND ret.date_processed < ", timestamp)
  }
  
  tableName <- baseTable
  
  sqlCode <- paste0(
    if (projectStage == "TEST"){
      paste0("CREATE TABLE ", tableName," AS")
    } else {
      paste0("CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS")
    }, 
    " SELECT 
      base.*, ", 
      timestamp, " AS TIMESTAMP
    FROM ",
      modRetName, "_base_temp_", stage, " base
    WHERE 
      ird_number IN  
        ((", CreateBaseSQL(returnName=returnName, modRetName=modRetName, stage=stage, timestamp=timestamp, mb=-12), ")",
        if (stage == "modelling"){
    	paste0("INTERSECT 
  		  (", CreateBaseSQL(returnName=returnName, modRetName=modRetName, stage=stage, timestamp=timestampB0, mb=0),")")
  	  },
  	  ")")
  
  CreateTable(conn, sqlCode, tableName)

  res <- dbGetQuery(conn, paste0("SELECT 1 FROM ", tableName," GROUP BY ird_number HAVING count(1)>1"))
  if (dim(res)[1] != 0){stop("Duplications in the base table!")}
  
  e$log <- LogEdit(e$modRetName, stepName, e$log, startM)
  
}
