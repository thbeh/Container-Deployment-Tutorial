
##########------MODELLING------############
#' Prepare data, build a model and evaluate it
#' 
#' \code{RunModelling} runs return models building and evaluation process. This function is universal for all implemented
#'  returns models and return types.
#' 
#' This function includes the following main modelling steps:
#' \itemize{
#'  \item Prepare fields names (\code{\link{PrepareFieldsNames}} function)
#'  \item Select objects for modelling (\code{\link{RRSelectObjects}}, \code{\link{ORSelectObjects}} functions)
#'  \item Create values of targets and covariates (\code{\link{CreateValues}} function)
#'  \item Clean values (\code{\link{CleanValues}} function)
#'  \item Create model targets (\code{\link{RRCreateModelTargets}}, \code{\link{ORCreateModelTargets}} functions)
#'  \item Prepare the data population for the model building, including:
#'  \itemize{
#'    \item Set classification targets as factors (\code{\link{SetClassificFieldsAsFactors}} function)
#'    \item Split the data into training and testing sets (\code{\link{SplitData}} function)
#'    \item (Optional) Split the training population into several sub-populations using certain conditions (\code{\link{DoConditionalSplit}} function)
#'    \item Exclude redundant fields (empty, temporary) (\code{\link{ExcludeCovar}} function)
#'  }
#'  \item Build the model (\code{\link{BuildModel}} function)
#'  \item Evaluate the model (\code{\link{DoEvaluation}} function)
#'  \item Combine the evaluation results through sub-populations and interim targets (\code{\link{JoinSptittedResults}} function)
#' }
#' 
#' The majority of functions listed above is used both at the modelling and scoring steps.
#' This function could be used by different returns models and for different return types.
#' 
#' @inheritParams FullModelling
#' @inheritParams MakeDBConnections
#' @inheritParams SetModelParameters
#' @param outputPath A path to a sub-folder in the output folder (for the current return type and run date).
#' @param modelTargetsList A vector of additional classification targets (purification targets in the Outstanding returns model,
#'  low-risk targets' names in the Right Returns model).
#' @param DataSelect A list of additional classification targets definitions (formulas).
#' @param targetList A vector of returns keypoints, which are considered as model targets.
#' @param targetTransf A list of target keypoints transformations (expressions for calculated targets creation).
#' @param covList A vector of keypoints that will be considered in the model as income tax keypoints covariates.
#' @param covTransf A list of income covariates keypoints transformations (expressions for calculated income covariates creation).
#' @param classificCov A vector of income keypoints that should be considered as classification variables.
#' @param participation A vector with names of covariates groups participating in the model.
#' @param conn An Oracle connection to the Data Warehouse.
#'
#' @return The output of this function consists of the outputs of the functions listed in the \strong{Details} section.
#' 
#' @examples
#' \dontrun{
#'    RunModelling(e=e)
#' }
#' @export
RunModelling <- function(model=e$model, returnName=e$returnName, modRetName=e$modRetName, projectStage=e$projectStage, purificationOnly=e$purificationOnly, 
                        conn=e$conn, participation=e$participation, clientStatusList=e$clientStatusList, selectObjectsArgsMod=e$selectObjectsArgsMod,
                        year=e$year, yearsBack=e$yearsBack, covYearsBack=e$covYearsBack, considerRR=e$considerRR, UNbyUserIsNill=e$UNbyUserIsNill,
                        conditionalSplit=e$conditionalSplit, mask=e$mask, timestampB0=e$timestampB0,
                        ss=e$ss, ssMax=e$ssMax, nrows=e$nrows, nTrees=e$nTrees, setMtry=e$setMtry, method=e$method, coeff=e$coeff,
                        targetList=e$targetList, targetTransf=e$targetTransf, covList=e$covList, covTransf=e$covTransf, classificCov=e$classificCov,
                        DataSelect=e$DataSelect, modelTargetsList=e$modelTargetsList, outputPath=e$outputPath, runDate=e$runDate, alg=e$alg, 
                        modelPath=e$modelPath, log=e$log, e){
  
  #------PREPARE FIELDS NAMES------#
  output <- PrepareFieldsNames(stage="modelling", e=e)
  AssignOutput(output, e)
  
  
  #------SELECT OBJECTS FOR MODELLING------#
  # if it's a testing run and the base table exists and not empty, then use the existing table.
  # Otherwise, create a new base table.
  # NOTE: Different functions are used for different model types. That's why a "do.call" construction is used
  # (we don't know the full function name in advance).
  # As far as lists of parameters are also different for those functions, 
  # parameters are transferred into the function's call as a preliminary created list of parameters with their values.
  if (!(projectStage == "TEST" & dbExistsTable(conn, toupper(e$baseTable)))){
    do.call(paste0(toupper(model), "SelectObjectsNew"), selectObjectsArgsMod)
  } else {
    if (dim(dbGetQuery(conn, paste0("select * from ", e$baseTable)))[1] == 0)
      do.call(paste0(toupper(model), "SelectObjectsNew"), selectObjectsArgsMod)
  }
  # Delete some rows if it is a testing stage to reduce the calculation time
  if (projectStage == "TEST"){
    startM <- Sys.time()
    stepName <- "Reduce the number of rows"
    ReduceRows(nrows=nrows, tableN=e$baseTable, conn=conn)
    e$log <- LogEdit(e$modRetName, stepName, e$log, startM)
  }
  
  
    #------CREATE VALUES------#
    # if it's a testing run and the final population table exists and not empty, then use the existing table.
    # Otherwise, recreate all values. 
    # Note: be careful if doing several TEST runs one after another, with some parameters are changing. If changed parameters can affect
    # returns selection, DB tables may be needed to be cleaned manually (otherwise tables won't be recreated and obsolete tables will be used).
    fullCreation <- TRUE
    if (projectStage == "TEST" & dbExistsTable(conn, toupper(paste0(modRetName, "_FINAL_POP_", e$stage)))){
      if (dim(dbGetQuery(conn, paste0("select * from ", paste0(modRetName, "_FINAL_POP_", e$stage))))[1] != 0){
        fullCreation <- FALSE
      } 
    }
    output <- CreateValues(fullCreation=fullCreation, e=e)
    AssignOutput(output, e)
    if (length(dim(e$dat)) == 0) stop("The model population data set is empty")
  
  
  #------CLEAN VALUES------#
  # Note: Null values imputation is done at this step only for some certain fields. 
  # Imputation isn't done for all fields at this step, because it can affect the procedure of the conditional split.
  e$dat <- CleanValues(dat=e$dat, clientStatusList=eval(clientStatusList), e=e)
  if (length(dim(e$dat)) == 0) stop("The model population data set is empty")
  
  # Even after cleaning, there may be a few returns in the population with null keypoints values for the B0 period.
  # The reason why it happens is that in the Outstanding returns model the selection of returns for modelling is done on the base of 
  # POLICING_PROFILES table only. There may be a few cases when a return was outstanding and then was finalised with the 'RL' finalisation code. 
  # If this return was not filed (there is no information in the keypoints table), we can't treat this return as NIL return.
  # Therefore, we don't know the real value of this return and can't use it for modelling. That's why those returns 
  # should be deleted from the modelling population.
  if ("INCOME TAX RETURN FIELDS" %in% participation){
    name <- toupper(paste0(e$groupCovNames[["INCOME TAX RETURN FIELDS"]][[1]], "_B0"))
    n <- sum(is.na(e$dat[, name]))
    if(n != 0) {
      e$dat <- e$dat[!is.na(e$dat[, name]),]
      print(paste0("NA values in the model target. ", n," NA values were deleted."))
    }
  }
  
  #------CREATE TARGETS VALUES------#
  # Different functions are used for different model types. That's why the "do.call" construction is used.
  output <- do.call(paste0(toupper(model), "CreateModelTargets"), list(e=e))
  AssignOutput(output, e)
  
  # Join vectors for main targets and additional classification targets (e.g. Outstanding returns targets and purification targets).
  #e$modelTargets <- c(e$modelTargets, e$modelTargetsList)
  #e$interimModelTargets <- c(e$interimModelTargets, e$modelTargetsList)
  #e$interimModelTargetsClassific <- c(e$interimModelTargetsClassific, e$modelTargetsList)
  
  SaveImage(e=e)
  
  #------PREPARE DATA FOR THE MODEL BUILDING------#
  startM <- Sys.time()
  stepName <- "Prepare data for the model building"
  
  # split the data into the training and testing sets
  output <- SplitData(dat=e$dat, rate=0.3, e=e)
  AssignOutput(output, e)
  
  # do conditional split (split the general modelling population into several sub-populations according to the given mask)
  e$datList <- DoConditionalSplit(dat=e$datFit, e=e)
  
  # check the number of elements in each sub-population
  #for (i in 1:length(e$datList)){cat(dim(e$datList[[i]])[1], "\n")}
  
  e$log <- LogEdit(modRetName, stepName, e$log, startM)
  
  #datLIstModelling <- e$datList
  
  # exclude covariates (covariates [almost] without data, "rubbish" fields from previous steps)
  output <- ExcludeCovar(dat=e$dat, e=e)
  AssignOutput(output, e)
      
  
  startM <- Sys.time()
  stepName <- "Prepare datMod"
  datMod <- PrepareData(e=e)
  e$log <- LogEdit(modRetName, stepName, e$log, startM)
  
  #e$excludeCols <- CreateExcludeCols(datMod=datMod, conditionalSplit=conditionalSplit, mask=mask, 
  #  groupCovNamesInc=e$groupCovNames[['INCOME TAX RETURN FIELDS']], e=e)

  #rm(e$datList)
  gc()
  #e$log <- LogEdit(modRetName, stepName, e$log, startM)
  
  
  #------BUILD THE MODEL------#
  #set.seed(10)
  
  startM <- Sys.time()
  stepName <- "Build the RF model"
  e$modelFits <- BuildModel(datMod=datMod, e=e)
  e$log <- LogEdit(modRetName, stepName, e$log, startM)
  print(e$log)
  
  # prep for eval
  e$mainIndex <- list()
  e$covarImp <- list()
  if (alg == "RSpark_RF") {
    
    e$sc <- MakeSparkConnection()
    
    startM <- Sys.time()
    stepName <- "Load models"
    e$modelFits <- LoadModels(datMod=datMod, e=e)
    e$log <- LogEdit(modRetName, stepName, e$log, startM)
    
    startM <- Sys.time()
    stepName <- "Save indeces for classification targets"
    e$mainIndex <- SaveStringToIndexLabels(datMod=datMod, e=e)
    e$log <- LogEdit(modRetName, stepName, e$log, startM)
    
    startM <- Sys.time()
    stepName <- "Extract importance coefficients"
    e$covarImp <- ExtractCovarImportance(datMod=datMod, e=e)
    e$log <- LogEdit(modRetName, stepName, e$log, startM)
    
    #output <- DoEvaluation(datTemp=e$datFit, mainIndex=mainIndex, e=e)
    #AssignOutput(output, e)
  }
  
  #rm(datMod)   #??
  gc()
  #e$log <- LogEdit(modRetName, stepName, e$log, startM)
  
  format(object.size(e$modelFits), units = "Mb")

  #------DO EVALUATION------#
  #output <- DoEvaluation(datTemp=e$datFit, mainIndex=e$mainIndex, e=e)
  #AssignOutput(output, e)
  
  # apply the built models to the testing data set datHo
  output <- DoEvaluation(datTemp=e$datHo, mainIndex=e$mainIndex, e=e)
  AssignOutput(output, e)
    
  # combine evaluation results
  output <- JoinSptittedResults(e=e)
  AssignOutput(output, e)

}

