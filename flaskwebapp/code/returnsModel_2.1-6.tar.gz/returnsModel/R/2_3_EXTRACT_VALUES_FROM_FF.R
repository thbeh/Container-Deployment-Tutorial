

ExtractFeaturesValues <- function(){
  
  fea_nam <- c("INCOME_AFTER_EXPENSES_101",
    "OVERSEAS_TAX_CREDITS_107",
    "RESIDUAL_INCOME_TAX_108",
    "TAXABLE_INCOME_109",
    "TOTAL_LOSS_CARRIED_FWD_114",
    "TOTAL_TAX_CREDITS_115",
    "LOSS_CLAIMED_133",
    "LOSS_BROUGHT_FORWARD_136",
    "SHARE_OF_IMP_CREDITS_705",
    "INC_ALLOCN_TO_BENEFICIARY_714",
    "INC_ALLOC_TO_TRUSTEE_716",
    "OVERSEAS_INCOME_828",
    "OTHER_INCOME")
  
  feature_list<-c(paste0(fea_nam,"_B1"),paste0(fea_nam,"_B2"),paste0(fea_nam,"_B3"),paste0(fea_nam,"_B4"),paste0(fea_nam,"_B5"))
  RequiredFeatures<-feature_list[1:15]
  
  
  # Specify the table name containing teh returns to score and the as at date for each return.
  returnListTableName<-"`dfs`.`tmp`.`BASE_TABLE`"
  # Specify the name of the result set.
  outputTableName<-"`dfs`.`tmp`.`Modelling_population`"
  
  
  # Run the function.
  ExtractFeaturesFromCat(returnListTableName,RequiredFeatures,outputTableName)
  
  #Examine the results.
  sergeant::drill_query(dcon,paste0("select count(*) from ", outputTableName)) # 
  sergeant::drill_query(dcon,paste0("select * from ", outputTableName,"LIMIT 10"))
  
   
}


ExtractFeaturesFromCat<-function(returnListTableName,RequiredFeatures,outputTableName){
    
    query <- paste0("
      create table ", outputTableName,"  as 
        select distinct ",
          paste0(" 
            sum(case when a.FEATURE_NAME = '",RequiredFeatures,"' then cast(a.FEATURE_VALUE as FLOAT) else 0.0 end) 
            OVER (PARTITION BY a.IRD_NUMBER, a.LOCATION_NUMBER, a.RETURN_TYPE, a.RETURN_PERIOD_DATE ) as ", RequiredFeatures, "," , collapse=""),
        " a.IRD_NUMBER, 
          a.LOCATION_NUMBER, 
          a.RETURN_TYPE, 
          a.RETURN_PERIOD_DATE
        from  
          `dfs`.`default`.`./poc/FZ/IR/feature_catalogue` a 
          inner join ", returnListTableName, " b on
            a.IRD_NUMBER=b.IRD_NUMBER and
            a.LOCATION_NUMBER=b.LOCATION_NUMBER and
            a.RETURN_PERIOD_DATE=b.RETURN_PERIOD_DATE and
            a.RETURN_TYPE=b.RETURN_TYPE    
        where  
          a.FEATURE_NAME in ('", paste(RequiredFeatures, collapse="','"), "') ",
          "and a.DATE_APPLIED <= b.AS_AT
          and (a.DATE_CEASED > b.AS_AT OR a.DATE_CEASED IS NULL)   
        ")
      
      
      sergeant::drill_query(dcon,paste0("DROP TABLE IF EXISTS ", outputTableName))
      st<-Sys.time()
      sergeant::drill_query(dcon,query)
      Sys.time()-st
      
      #return(NULL)
  }


