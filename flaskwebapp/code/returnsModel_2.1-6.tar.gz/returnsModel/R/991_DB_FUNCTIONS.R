
# MAKE ORACLE CONNECTION
#' Make connections to the Oracle database
#' 
#' \code{MakeDBConnections} creates connections to the Data Warehouse, the Property data scheme, and a scheme for the modelling output publishing.
#' \emph{connection_config.R} file with the model attributes and Oracle connection settings must be presented in the \code{data} folder for a
#' correct function execution.
#' 
#' @inheritParams SetModelParameters
#' @param modRetName A character string with a model name and a return type name (e.g. \code{OR_IR4}, \code{RR_IR7}, etc.)
#' 
#' @return \code{modelName} - A full model name extracted from the \emph{connection_config.R} file.
#' @return \code{modelOwner} - A model owner (department / team name). Default value is \code{"IC_MODELLING"}.
#' @return \code{modelCustomer} - A model customer (department / team name).
#' @return \code{dbModelTable} - A name of the DB table used for keeping the list of models and their attributes.
#' @return \code{dbLogTable} - A name of the DB table used for keeping logs of models run.
#' @return \code{dbOutputTable} - A name of the DB table used for saving the model output data.
#' @return \code{credentialsFullPathName} - A full path to a secured file with Oracle databases credentials.
#' @return \code{dbnameEDW} - A DB connection name for the connection with the EDW.
#' @return \code{usernameEDW} - A user name for the connection with the EDW.
#' @return \code{dbnameMod} - A DB connection name for the connection with the output data storage.
#' @return \code{usernameMod} - A user name for the connection with the output data storage.
#' @return \code{dbnameProp} - A DB connection name for the connection with the schema containing the property data.
#' @return \code{usernameProp} - A user name for the connection with the schema containing the property data.
#' @return \code{conn} - An Oracle connection to the Data Warehouse.
#' @return \code{conn1} - An Oracle connection to the Modelling scheme (for results publishing).
#' @return \code{conn2} - An Oracle connection to the Property scheme (used in the Right Returns model only).
#' 
#' @examples
#' \dontrun{
#'  MakeDBConnections(model="OR", modRetName="OR_IR4", e=e)
#' }
#' 
#' @export
MakeDBConnections <- function(model=e$model, modRetName=e$modRetName, log=e$log, e){
  #-----
  # Make DB connection
  startM <- Sys.time()
  stepName <- "Make connections to the database"
  
  data(list="connection_config", envir = e) # load connection settings and model metadata from the file
  modelName <- e$GiveModelName(model)
  
  conn <- CreateConnection(e$credentialsFullPathName, e$dbnameEDW, e$usernameEDW)   # create a connection to the EDW
  conn1 <- CreateConnection(e$credentialsFullPathName, e$dbnameMod, e$usernameMod)  # create a connection to the Modelling schema
  conn2 <- CreateConnection(e$credentialsFullPathName, e$dbnameProp, e$usernameProp)  # create a connection to the property schema
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  list("modelName"=modelName, "conn"=conn, "conn1"=conn1, "conn2"=conn2)
}
  

#--------------------------------------------------------------------------------
# CREATE A RECORD IN THE LOG TABLE
#' Create a record in the database LOG table
#' 
#' \code{CreateDBLog} creates a new record about the model run in the \code{dbLogTable} table.
#' If the \code{dbModelTable} table (the dictionary of existing models and its' attributes) does not contain
#'  information about a given model with given attributes, the function also creates a new record in the \code{dbModelTable}.
#' 
#' @inheritParams MakeDBConnections
#' @inheritParams SetModelParameters
#' @param conn1 An Oracle connection to the Modelling schema where the model log and the output will be saved.
#' @param dbModelTable A name of the DB table used for keeping the list of models and their attributes.
#' @param modelOwner A model owner (department / team name).
#' @param modelCustomer A model customer (department / team name).
#' @param dbLogTable A name of the DB table used for keeping logs of models runs.
#' @param modelName A short model name (e.g. "OR" or "RR").
#' 
#' @return \code{status} - The status is updated to "IN PROGRESS".
#' @return \code{oldTZs} - Initial \code{ORA_SDTZ} and \code{TZ} environment settings.
#' @return \code{modelId} - A unique ID of the model in the database.
#' @return \code{runId} - A unique ID of the model run in the database.
#' 
#' @examples
#' \dontrun{
#'  CreateDBLog(conn1=e$conn1, dbModelTable="MODEL", modelName=e$modelName,
#'    modelOwner=e$modelOwner, modelCustomer=e$modelCustomer, 
#'    dbLogTable=e$dbLogTable, modRetName=e$modRetName)
#' }
#' @export
CreateDBLog <- function(conn1=e$conn1, dbModelTable=e$dbModelTable, modelName=e$modelName, modelOwner=e$modelOwner, 
                        modelCustomer=e$modelCustomer, dbLogTable=e$dbLogTable, modRetName=e$modRetName, log=e$log, e){
  # Set modelId and create a row into the MODEL_RUN_LOG table
  startM <- Sys.time()
  stepName <- "Fill in the MODEL and MODEL_RUN_LOG tables (status IN PROGRESS)"
  
  output=list()
  status <- "IN PROGRESS"
  output[["status"]] <- status 
  output[["oldTZs"]] <- SetTimeZones(status)   # save old environment time zone options
  
  # Extract model id or create a new record in the MODEL table if there is no record about the given model with the given attributes
  modelId <- UpdateModelTable(conn1, dbModelTable, modelName, modelOwner, modelCustomer)
  output[["modelId"]] <- modelId
  
  # Use DB sequence to create new run ID
  runId <- GetRunId(conn1)
  output[["runId"]] <- runId
  
  # Create a new record in the LOG table
  UpdateLogTable(status=status, conn1=conn1, dbLogTable=dbLogTable, runId=runId, modelId=modelId,
                   modelVersion=paste0(modRetName, "_", as.character(packageVersion("returnsModel"))))
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  output
}


#--------------------------------------------------------------------------------

# Create a Connection Object to an Oracle DBMS (using ROracle package)
# input:
#   credentialsFullPathName: A full path to a secured file with Oracle databases credentials.
#   dbname: A DB connection name.
#   username: A user name for the connection.
#   drv: An object of class OraDriver.
# output: 
#   The connection object which can be used to execute operations on the database.
CreateConnection <- function(credentialsFullPathName, dbname, username, drv=dbDriver("Oracle")){
  credentials <- read.table(file=credentialsFullPathName, sep=",")
  mask <- which(tolower(credentials[,1]) == tolower(dbname) & tolower(credentials[,2]) == tolower(username))
  if (length(mask) > 0) {
    credentials <- credentials[mask,]
    return(dbConnect(drv, username = credentials[1,2], password = credentials[1,3], dbname=credentials[1,1]))
    rm(credentials)
  } else 
    stop('No relevant database credentials found')
}


#-------------------------------------------------------------------------------------------------------------------

# When status=="IN PROGRESS": set same time zone for data frames and Oracle connection 
# to avoid conflicts during inserting the data with 'date' type from a data frame into a database table.
# When status=="COMPLETE" or "ERROR": return time zone options to the initial values.
SetTimeZones <- function(status, oldORASDTZ="", oldTZ="")
  if (status == "IN PROGRESS") {
    oldORASDTZ <- Sys.getenv("ORA_SDTZ")
    oldTZ <- Sys.getenv("TZ")
    Sys.setenv(ORA_SDTZ = "NZ")
    Sys.setenv(TZ = "NZ")
    list(oldORASDTZ, oldTZ)
  } else {
    Sys.setenv(ORA_SDTZ = oldORASDTZ)
    Sys.setenv(TZ = oldTZ)
  }


#-------------------------------------------------------------------------------------------------------------------

# Function for a new DB table creation
# If a table with the same name already exists, the function truncates and drops it, and then creates a new table according to the input query.
CreateTable <- function(conn, sqlCode, tableName){
  if (dbExistsTable(conn, toupper(tableName))) {
    result <- dbGetQuery(conn, paste0("truncate table ", tableName))
    result <- dbGetQuery(conn, paste0("drop table ", tableName," purge"))
  }
  startM <- Sys.time()
  result <- dbGetQuery(conn, sqlCode)
  endM <- Sys.time()
  text <- paste0(tableName, " - ", dbGetQuery(conn, paste0("select count (*) from ", tableName))[[1]], " rows;  Time taken ", FormatTimeTaken(startM, endM))
  print(text)
  #e$log <- paste0(log, "    ", text, "\n\n")
}

#-------------------------------------------------------------------------------------------------------------------

# Function that identifies the modelID or updates the MODEL table on modelling schema
# in the eventuality that there is no entry for MODEL_ID.
# input:
#   conn1: connection to the MODELLING schema
#   dbModelTable: the name of the MODEL table
#   modelName: name of the model
#   modelOwner: owner of the model (Intelligence Capability for instance)
#   modelCustomer: name of the customer for which the model is developed/run
# output: modelId
UpdateModelTable <- function(conn1, dbModelTable, modelName, modelOwner, modelCustomer){
  modelExists <- dbGetQuery(conn1, paste0("select nvl(sum(1),0) from ", dbModelTable," where model_name='", 
                                          modelName,"' and model_owner='", modelOwner,"' and model_customer='", modelCustomer,"'"))
  if (modelExists < 1) {
    modelId <- dbGetQuery(conn1, paste0("select nvl(max(model_id), 0) from ", dbModelTable)) + 1
    dbGetQuery(conn1, paste0("insert into ", dbModelTable," values (", as.numeric(modelId),", '", modelName,"', '", modelOwner,"', '", 
                             modelCustomer,"')"))
    dbCommit(conn1)
  } else {
    modelId <- dbGetQuery(conn1, paste0("select model_id from ", dbModelTable, " where model_name='", modelName,"' and model_owner='", 
                                        modelOwner,"' and model_customer='", modelCustomer,"'"))
  }
  as.numeric(modelId)
}

#-------------------------------------------------------------------------------------------------------------------

# Get the next runId using the sequence in the database (modelling schema)
# input: conn1
# output: runId
GetRunId <- function(conn1){
  runId <- dbGetQuery(conn1, "select model_seq.nextval from dual")
  as.numeric(runId)
}

#-------------------------------------------------------------------------------------------------------------------

# Function that updates the LOG table on modelling schema for the run iteration runId of
# the model identified by modelId. This function is made of two separate parts
# depending upon the value of the argument 'status': (1) "IN PROGRESS" or 
# (2) "COMPLETE" or "ERROR". 
# Input:
#   status: either "IN PROGRESS", "COMPLETE" or "ERROR"
#   conn1: connection to the MODELLING schema
#   dbLogTable: the name of the MODEL_RUN_LOG table
#   modelId: identification number of the model
#   runId: identification number of the current run iteration for the model
#   modelVersion: version number of the model
#   numRecords: number of rows in the record (output) variable that are to be 
#              written in the DOCUMENT_MODEL_OUTPUT table
#   log: current log text
#   imageName: the path to the file with the saved workspace
UpdateLogTable <- function(status, conn1, dbLogTable, runId, modelId=0, modelVersion="", numRecords=0, log="", imageName=""){
  if (status == "IN PROGRESS") {
    # Create a new row in the MODEL_RUN_LOG table. Set model status = IN PROGRESS
    dbGetQuery(conn1, paste0("insert into ", dbLogTable,"(RUN_ID, MODEL_ID, MODEL_VERSION, START_TIME, STATUS) 
		values (", runId,", ", modelId,", '", modelVersion,"', to_date('", format(Sys.time()),"', 'yyyy-mm-dd HH24:Mi:SS'), '", status,"')"))
    dbCommit(conn1)
  }
  
  if (status == "COMPLETE" | status == "ERROR") {
    endTime <- Sys.time()
    if (imageName != "NULL"){
      workspaceSize <- file.info(imageName)$size / 1024
    } else {workspaceSize <- "NULL"}
    dbGetQuery(conn1, paste0("update ", dbLogTable,"  set END_TIME=to_date('", endTime,"', 'yyyy-mm-dd HH24:Mi:SS'), 
                             STATUS='", status,"', NUM_RECORDS=", numRecords,", WORKSPACE_SIZE=", 
                             if (imageName != "NULL") {round(workspaceSize,0)} else workspaceSize, ",
                             LOG_DETAILS='", gsub("'", "-", log), "' where RUN_ID=", runId))
    dbCommit(conn1)
  }
}

#-------------------------------------------------------------------------------------------------------------------

# Function that updates the 'output' table, identified by 'tableName', on 
# Modelling schema for the run iteration runId of the model identified by modelId. 
# Input:
#   conn1: connection to the MODELLING schema
#   dbOutputTable: the name of the 'output' table (DOCUMENT_MODEL_OUTPUT table)
#   outDat: the data frame variable that is to be written in the table 
#		    'tableName'. Note that the 'output' data frame must ONLY have the
#           columns of 'tableName' for which data will be added to. For instance
#			if 'tableName' has columns A, B, C, D, but the results of the model
#           concern only A and D, then 'output' is a data frame composed of the
#           columns A and D only. 
UpdateOutputTable <- function(conn1, dbOutputTable, outDat, runId){
  
  dbGetQuery(conn1, paste0("delete from ", dbOutputTable," where run_id=", runId))
  dbCommit(conn1)
  
  insCol <- paste0(names(outDat), collapse=", ")
  insPar <- paste0(":", c(1:length(names(outDat))), collapse=", ")
  insStr <- paste0("insert into ", dbOutputTable," (", insCol,") values (", insPar,")")
  # Insert data in DOCUMENT_MODEL_OUTPUT
  dbGetQuery(conn1, insStr, data=outDat)
  dbCommit(conn1)
  #grantSelect<-dbGetQuery(conn1, paste0("GRANT SELECT ON ", dbOutputTable, " TO CAMPAIGN"))
}

#-------------------------------------------------------------------------------------------------------------------

# Drop temporary tables in the EDW schema
DropTables <- function(modRetName, conn){
  tableList <- c(
    paste0(modRetName, "_FILTER_LIST"),
    paste0(modRetName, "_BASE_TEMP_MODELLING"),
    paste0(modRetName, "_BASE_TEMP_SCORING"),
    paste0(modRetName, "_BASE_VALUE"),
    paste0(modRetName, "_SCORING"),
    
    paste0(modRetName, "_POLICING_TEMP"),
    paste0(modRetName, "_POLICING"),
    paste0(modRetName,"_AGG_INC"),
    paste0(modRetName,"_INC_ALL"),
    paste0(modRetName,"_INC_TEMP1"),
    paste0(modRetName,"_INC_TEMP2"),
    paste0(modRetName,"_INC"),
    paste0(modRetName,"_S068_TEMP1"),
    paste0(modRetName,"_S068_TEMP2"),
    paste0(modRetName,"_S068"),
    paste0(modRetName,"_TAX_REGISTRATIONS"),
    paste0(modRetName,"_GST"),
    paste0(modRetName,"_GST_ANN_TEMP"),
    paste0(modRetName,"_GST_ANN_TEMP2"),
    paste0(modRetName,"_NO_EMP"),
    paste0(modRetName,"_NO_EMP_TEMP"),
    paste0(modRetName,"_NO_EMP_TEMP2"),
    paste0(modRetName,"_EMS"),
    paste0(modRetName,"_EMS_TEST"),
    paste0(modRetName, "_CUS"),
    paste0(modRetName, "_INB"),
    paste0(modRetName, "_TR"),
    paste0(modRetName, "_TR_TEMP"),
    paste0(modRetName, "_AGENTS"),
    paste0(modRetName, "_REF"),
    paste0(modRetName, "_REF_TEMP"),
    paste0(modRetName, "_REF_TEMP2"),
    paste0(modRetName, "_INFO"),
    paste0(modRetName, "_INFO_TEMP"),
    paste0(modRetName, "_INFO_TEMP2"),
    paste0(modRetName, "_INFO_TEMP3"),
    
    paste0(modRetName,"_POPULATION"),
    paste0(modRetName,"_FINAL_POP_MODELLING"),
    paste0(modRetName,"_FINAL_POP_SCORING"))
  
  for (tableName in tableList) {
    if (dbExistsTable(conn, tableName)) {
      dbGetQuery(conn, paste0('truncate table ', tableName))
      dbGetQuery(conn, paste0('drop table ', tableName))
    }
  }
}

#-------------------------------------------------------------------------------------------------------------------

# If the projectStage=="TEST", delete some rows in the BASE (or BASE_TEMP) tables
# to reduce the calculation time.
# This function use the SQL-query that orders a 'tableN' table by IRD_NUMBER column 
# and select the first 'nrows' rows deleting the rest of the table.
ReduceRows <- function(nrows, tableN, conn){ 
  
  dbGetQuery(conn, paste0("
    DELETE FROM ", tableN," WHERE ird_number>=
      (SELECT MIN(ird_number) FROM
        (SELECT 
          LEAD(ird_number, ", nrows,", 0) OVER (ORDER BY ird_number) AS ird_number
          FROM ", tableN,")
      WHERE ird_number<>0)"))
  dbGetQuery(conn, "commit")
  
}

#-------------------------------------------------------------------------------------------------------------------

# Create a DB view with the results of the current model only.
# input:
#   conn1 - connection to the MODELLING schema
#   dbOutputTable - a name of the table with modes output data
#   outDat - the output data frame of the current model
#   runId - a unique ID of the current model
#   returnName - a return type
# output:
#   A view in the MODELLING schema
#
#It is currently designed for the Outstanding returns / Returns purification models.
# Changes can be needed for other models.
CreateOutputView <- function(conn1, dbOutputTable, outDat, runId, returnName, model, year){
  
  if (model == 'RR'){
    viewName <- paste0("_RR", year, dbGetQuery(conn1, paste0("SELECT '_' || TO_CHAR(start_Time, 'DDMONYY') from MODEL_RUN_LOG where RUN_ID = ", runId))[[1]])
  } else {
    viewName <- dbGetQuery(conn1, paste0("SELECT '_RTN_' || TO_CHAR(start_Time, 'DDMONYY') || '_PER' from MODEL_RUN_LOG where RUN_ID = ", runId))[[1]]
  }
  
  viewName <- paste0(returnName, viewName)
  
  columnNames <- names(outDat)
  columnNames <- columnNames[-which(columnNames %in% c("MODEL_ID", "RUN_ID", "LOCATION_NUMBER", "TAX_TYPE", "FILING_FREQUENCY"))]
  columnNames <- paste0(columnNames, collapse=", ")
  
  sql <- paste0("
    CREATE OR REPLACE FORCE VIEW ", viewName," AS
      SELECT ",
        columnNames,
      " FROM ",
        dbOutputTable,
      " WHERE
        run_id = ", runId)
  
  dbGetQuery(conn1, sql)
  
  sql <- paste0("GRANT SELECT ON ", viewName," TO CAMPAIGN_USER")
  res <- dbGetQuery(conn1, sql)
  
  viewName
}

