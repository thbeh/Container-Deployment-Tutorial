
# SAVE WORKSPACE  
#' Save a workspace
#' 
#' \code{SaveImage} saves a workspace in the output folder.
#' 
#' @inheritParams RunModelling
#' @inheritParams PrepareFieldsNames
#' @inheritParams MakeDBConnections
#' 
#' @return A workspace in the output folder.
#' @return \code{imageName} A name of a workspace.
#' 
#' @examples
#' \dontrun{
#'  SaveImage(e=e)
#' }
#' 
#' @export
SaveImage <- function(outputPath=e$outputPath, runDate=e$runDate, stage=e$stage, modRetName=e$modRetName, e) {
  imageName <- paste0(outputPath, modRetName,"_",  runDate, "_", stage,".RData")
  save(file=imageName, list=ls(envir=e, all.names = TRUE), envir=e)
  imageName
}

#--------------------------------------------------------------------------------------------------------------

# IsFactor <- function(x, dat) is.factor(dat[,x])

#--------------------------------------------------------------------------------------------------------------


# Time taken
# This function calculates the difference between the start time and the end time, and presents it as a text
# with the time taken in seconds or minutes depending on the operation duration.
FormatTimeTaken <- function(startM, endM){
  if (difftime(endM, startM, units="mins") < 1){
    paste0(round(difftime(endM, startM, units="secs"), 4)," secs")
  } else {
    paste0(round(difftime(endM, startM, units="mins"), 4)," mins")
  }
}

#--------------------------------------------------------------------------------------------------------------


# Create and edit the log
LogEdit <- function(modRetName, stepName = "Next step", log, startM){
  if (log == "")
    log <- paste0(log, SaveLogTime(),": Running ", modRetName," return model \n\n")   #log start
  endM <- Sys.time()
  logStep <- paste0(format(startM, "%T"), ": ", stepName, "    ")
  #log <- paste0(log, format(startM, "%T"), ": ", stepName, "    ")
  dtime <- FormatTimeTaken(startM, endM)
  #log <- paste0(log, "Time taken: ", dtime, "\n\n")
  logStep <- paste0(logStep, "Time taken: ", dtime)
  print(logStep)
  log <- paste0(log, logStep, "\n\n")
  log
}


#--------------------------------------------------------------------------------------------------------------

# System time 
SaveLogTime <- function()
  format(Sys.time(), "%T")

# # System date
# save.run.date <- function()
#   format(Sys.Date(), "%Y-%m-%d")

#--------------------------------------------------------------------------------------------------------------

# If the function is called from the GlobalEnvironment, it copies all variables (with values) from the Global environment to the "env" environment.
# If the function is called from another environment (for example, from the parent environment of the function "funct"), it creates variables in the 
#  "env" environment and assign values to them according to the parameters and their default values of the function "funct".
# input:
#   env - an environment where variables have to be created
#   currEnv - an environment, from which AssignParam function is called
#   funct - a name of a function, which parameters should be copied to the "env" environment (optional)
# output:
#   new variables are created in the "env" environment and values are assigned to them.
AssignParam <- function(env, currEnv, funct=""){
  if (!identical(globalenv(), currEnv)){
    y <- ls(currEnv)
    for (i in 1:length(y))
      assign(y[i], currEnv[[y[i]]], envir=env)
  } else {
    y <- formals(funct)
    for (i in 1:length(y))
      assign(names(y)[i], y[[i]], envir=env)
  }
}

#--------------------------------------------------------------------------------------------------------------

# Create  variables in the "env" environment and assign values to them on the base of the "output" list
# input:
#   output - a list. Each element of this list contains value of a certain variable (can be a vector, list, etc.)
#   env - an environment where variables have to be created
# output:
#   new variables are created in the "env" environment and values are assigned to them.
#' Assign output into variables
#' 
#' \code{AssignOutput} assigns values of the output list to variables with corresponded names in a given environment.
#' 
#' @param output A list. Can have several elements, each of which contain value of the certain output variable.
#' @param env An environment. The output will be assign into variables of that environment.
#' 
#' @return  Creates variables in the given environment and assign values into them. If a variable with a certain name
#'   already exists, the function overwrite its value.
#'  
#' @export
AssignOutput <- function(output, env){
  i <- 1
  while (length(output) >= i){
    assign(names(output)[i], output[[i]], envir=env)
    i <- i+1
  }
}

#--------------------------------------------------------------------------------------------------------------

# Creates the data frame with the Right Returns output in the required format
CreateRRDataFrame <- function(irdNumbers, returnDate) {
  
  # publishing the file
  
  irdNumbers <- data.frame(IRD_NUMBER = irdNumbers[, "IRD_NUMBER"],
                            LOCATION_NUMBER = '0001', 
                            TAX_TYPE = 'INC', 
                            RETURN_TYPE = irdNumbers[, "RETURN_TYPE"],
                            RETURN_PERIOD = returnDate)

  # apply required formats
  tempformat1 <- formatC(as.numeric(irdNumbers$IRD_NUMBER), width = 9, format = "d", flag = "0")
  tempformat2 <- formatC(as.numeric(irdNumbers$LOCATION_NUMBER), width = 4, format = "d", flag = "0")
  tempformat3 <- formatC(as.character(irdNumbers$TAX_TYPE), width = 3, format = "s", flag = "")
  tempformat4 <- formatC(as.character(irdNumbers$RETURN_TYPE), width = 5, format = "s", flag = "")
  tempformat5 <- formatC(as.numeric(irdNumbers$RETURN_PERIOD), width = 8, format = "d", flag = "")

  rightReturns  <- data.frame(IRD_NUMBER = tempformat1,
                             LOCATION_NUMBER = tempformat2,
                             TAX_TYPE = tempformat3,
                             RETURN_TYPE = tempformat4,
                             RETURN_PERIOD = tempformat5)

  rightReturns
}


#--------------------------------------------------------------------------------------------------------------

# Right Returns function
# Write control file
# input:
#   controlFileName - The full path to a control file (paste0(outputDir, "ftpupload.ctl"))
#   textString - A text string of standard content, containing information about a corresponded output CSV file's name and size.
#   fileName - A name of a corresponded CSV file.
#   returnName - A character. Modelling return type name.
# output:
#   The function creates or updates a control file.
WriteControlFile <- function(controlFileName, textString, fileName, returnName){

  # Create the control file.
  # A nested process - do we need to create a file, append to an existing file or over-write a row in the file.
  
  fileSize <- file.info(controlFileName)$size
  appendVal <- FALSE #If appendVal is FALSE, a new control file is created. Let's set it to FALSE by default
  
  # For Individual Select a new file will always be created (it is only one return type, so that there is no need to update a file, 
  # it's easier to re-create it)
  if (returnName != "IR3"){
    if (file.exists(controlFileName) & fileSize!=0){
      # If there is a control file, then does it have a row for the current return type in it?
      currentFile <- read.table(controlFileName, sep=" ")
      numRows <- dim(currentFile)[1]
      isEachRow <- fileName == currentFile[,1]
      retTypeExists <- sum(isEachRow) != 0
                                 
      # If the row for the current return type already exists and there is more than one row in the file, over-write the current return type row.
      if (retTypeExists & numRows > 1) {
        rowDelete <- which(isEachRow) 
        newFile <- currentFile[-rowDelete,]
        write.table(newFile, file = controlFileName, quote = FALSE, row.names = FALSE, col.names = FALSE)
        appendVal = TRUE
      }

	  # If we don't have a row for the current return type then append a new row.
      if(!retTypeExists)
        appendVal = TRUE
    }
  }
  write.table(textString, file = controlFileName, quote = FALSE, row.names = FALSE, col.names = FALSE, append=appendVal)
}

#----------------------

Start <- function(e){
  e <<- .GlobalEnv
  output <- MakeDBConnections(e=e)
  AssignOutput(output, e)
  
  #oldTZs <- SetTimeZones(status)
  
  Sys.setenv(ORA_SDTZ = "NZ")
  Sys.setenv(TZ = "NZ")
  
  #oldTZs
}

#-----------------------

OutputInterimTargetsSummary <- function(modelTarget, interimModelTargets=e$interimModelTargets, dat=e$dat){
  intTargets <- ChoseInterimModels(modelTarget, interimModelTargets, numORtext='text')
  #print(modelTarget)
  summary(dat[, intTargets])
}
