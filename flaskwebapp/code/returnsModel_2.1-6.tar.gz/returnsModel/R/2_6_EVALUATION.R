
##########------DO EVALUATION------############
#' Do evaluation of models
#' 
#' \code{DoEvaluation} calculates predictions of interim model targets on the base of covariates values and built Random Forest models.
#'  
#' The algorithm of evaluation consists of several steps:
#'  \itemize{
#'    \item Split the input data frame \code{datTemp} on sub-populations according to the \code{mask} parameter. Reduce the number of elements 
#'      in obtained data frames of the \code{datList} list if it exceeds \code{ssMax}.
#'    \item Call \code{CreateEvalSample} function. It creates \code{evalDat} list with the separate copy of the sub-population for each
#'      main model target. It also impute missing values and converts classification covariates into factors.
#'    \item Call \code{PredictValue} function. It calculates predictions of all interim model targets for all sub-populations (\code{predRes}).
#'    \item At the modelling stage only call \code{CreateEvalDataSet} function. It combines real and predicted values of all interim targets
#'      for all sub-populations. The output list \code{evalRes} is used to build evaluation reports and evaluate the model's performance.
#'  }
#' 
#' This function is run within the \code{\link{RunModelling}} and \code{\link{RunScoring}} functions, but also can be run separately. 
#'  
#' @inheritParams BuildModel  
#' @inheritParams PrepareFieldsNames
#' @inheritParams FullModelling
#' @inheritParams MakeDBConnections
#' @inheritParams RunModelling
#' @inheritParams CreateValues
#' @inheritParams SetModelParameters
#' @param datTemp A data frame for evaluation (generally, the testing population \code{datHo} at the modelling stage, 
#'  and the scoring population \code{datScor} at the scoring stage). It should contain all covariates that took part in the modelling. 
#'  At the modelling stage it should also have a field with real target values.
#' @param modelFits A list of objects of class \code{randomForest}. This list has three levels: the sub-population's number, the index of a main target,
#'  the index of an interim target.
#' 
#' @return \code{datList} - A list. Each element of this list is a sub-population of the input \code{datTemp} data frame. 
#' @return \code{evalDat} - A list with two levels: the sub-population's number and the index of a main target. Each element of this list is a corresponded
#'  element of \code{datlist} list (generally, copies of each sub-population are created for each main targets).
#' @return \code{predRes} - A list with three levels: the sub-population's number, the index of a main target, the index of an interim target. 
#'  Each element contains predictions for the certain sub-population and the certain interim model target.
#' @return \code{evalRes} - A list with three levels: the sub-population's number, the index of a main target, the index of an interim target. This list
#'  is created only at the modelling stage. It combines the predicted values and real values of interim targets. Data frames of this list are used
#'  to build evaluation reports and evaluate the model's performance.
#'  
#' @examples
#'  \dontrun{
#'    # Do evaluation of the testing population
#'    DoEvaluation(datTemp=e$datHo, stage="modelling", e=e)
#'  }
#'  
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
DoEvaluation <- function(datTemp, datHo=e$datHo, dat=e$dat, modelFits=e$modelFits, modelTargets=e$modelTargets, stage=e$stage, 
                         classificCovShort=e$classificCovShort, conditionalSplit=e$conditionalSplit, modRetName=e$modRetName, mask=eval(e$mask), 
                         ssMax=e$ssMax, participation=e$participation, interimModelTargets=e$interimModelTargets, covYearsBack=e$covYearsBack, 
                         targetFieldsShort=e$targetFieldsShort, excludeCov=e$excludeCov, alg=e$alg, mainIndex=e$mainIndex, sc=e$sc, log=e$log, e){
  startM <- Sys.time()
  stepName <- "Evaluate the model"  

  datList <- DoConditionalSplit(dat=datTemp, e=e)
  
  set.seed(10)
  if (alg == "R_RF"){
    if (stage == "modelling"){
      for (i in 1:length(datList)){
        if(dim(datList[[i]])[1] > ssMax/3){
          datList[[i]] <- DatSampling(datList[[i]], ssMax/3)
        }
      }
    }
  }
    
  #e$evalDat <- CreateEvalSampleBal()
  evalDat <- PrepareData(dat=dat, datList=datList, excludeCov=excludeCov, interimModelTargets=interimModelTargets, participation=participation,
                          classificCovShort=classificCovShort, stage=stage, covYearsBack=covYearsBack, targetFieldsShort=targetFieldsShort, eval=TRUE, e=e)
    
  # predict interim targets values
  predRes <- PredictValues(datList=datList, datHo=datHo, doAdj=FALSE, modelTargets=modelTargets, interimModelTargets=interimModelTargets, 
                           modelFits=modelFits, evalDat=evalDat, excludeCov=excludeCov, alg=alg, mainIndex=mainIndex, sc=sc)
  
  output <- list("evalDat"=evalDat, "predRes"=predRes, "datList"=datList)
  
  if (stage == "modelling"){
    evalRes <- CreateEvalDataset(datList=datList, predRes=predRes, evalDat=evalDat, modelTargets=modelTargets, interimModelTargets=interimModelTargets)
    output <- c(output, list("evalRes"=evalRes))
  }
    
  e$log <- LogEdit(modRetName, stepName, log, startM)
  output
}


#-------------------------------------------------------------------------------------------------

##########------JOIN RESULTS------############
#' Combine modelling or scoring results
#' 
#' \code{JoinSptittedResults} calculates main model targets values and combines results through sub-populations.
#'  
#' First of all, this function calculates the main model targets values. The calculation algorithm depends on the model type and 
#'  a main target type. For instance, for all additional classification targets (e.g. purification targets in the Outstanding
#'  Returns model) and the Right Returns targets the simple algorithm of copying value of interim target to the main target is implemented.
#'  At the same time, values of main targets of the Outstanding Returns model are calculated according to the Law of total probability on the
#'  base of interim model targets values.
#'  
#' After that, aggregation of results is done to present the results at different levels of aggregation (results combined through all 
#'  sub-populations at the level of interim targets or main targets). These different levels of aggregation are used for different
#'  purposes, such as creation of detailed evaluation reports or a model's summaries, or publication of scoring results.
#' 
#' This function is run within the \code{\link{RunModelling}} and \code{\link{RunScoring}} functions, but also can be run separately. 
#'  
#' @inheritParams BuildModel
#' @inheritParams PrepareFieldsNames
#' @inheritParams MakeDBConnections
#' @inheritParams FullModelling
#' @inheritParams RunModelling
#' @inheritParams SetModelParameters
#' @param datRes A list with three levels: the sub-population's number, the index of a main target, the index of an interim target. 
#'  Each element contains predictions for the certain sub-population and the certain interim model target.
#' @param evalDat A list with two levels: the sub-population's number and the index of a main target. Each element of this list is a corresponded
#'  element of \code{datlist} list (generally, copies of each sub-population are created for each main targets).
#' @param evalRes A list with three levels: the sub-population's number, the index of a main target, the index of an interim target. This list
#'  is created only at the modelling stage. It combines the predicted values and real values of interim targets. Data frames of this list are used
#'  to build evaluation reports and evaluate the model's performance.
#' @param modelId A unique ID of the model in the database.
#' @param runId A unique ID of the model run in the database.
#' 
#' @return \code{evalMainRes} - A list with two levels: the sub-population's number and the index of a main target. This variable contains 
#'  results of calculation of the main model targets depending on the interim model targets' values and the model type.
#' @return At the modelling stage:
#' \itemize{
#'  \item \code{evalMainResModelling} - A copy of \code{evalMainRes} variable. It is created to keep the \code{evalMainRes} variable values 
#'    received at the modelling stage and use these results later at the scoring stage (\code{evalMainRes} values will be overwritten at the scoring stage).
#'  \item \code{evalAllRes} - A list with one level: the index of a main target. Each element of this list is a joint of a main model target values through 
#'    all sub-populations.
#'  \item \code{evalInterim} - A list with two levels: the index of a main target and the index of an interim target. Each element of this list is a joint of 
#'    an interim model target values through all sub-populations.
#' }
#' @return At the scoring stage:
#' \itemize{
#'  \item \code{outDat} - A data frame. It contains the scoring results in the form, in which it will be published in the database. The data frame should
#'    contain several mandatory columns (MODEL_ID, RUN_ID, IRD_NUMBER, LOCATION_NUMBER, TAX_TYPE, RETURN_PERIOD_DATE, FILING_FREQUENCY, RETURN_TYPE)
#'    and a set of columns with targets values, as well as a column with indexes of sub-populations. \bold{Note: the columns with corresponded names should be 
#'    created in the output DB table in advance.}
#' }
#'  
#' @examples
#'  \dontrun{
#'    JoinSptittedResults(datRes=e$predRes, stage="scoring", e=e)
#'  }
#'  
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
JoinSptittedResults <- function(datRes=e$predRes, datList=e$datList, stage=e$stage, modelTargets=e$modelTargets, interimModelTargets=e$interimModelTargets,
                                evalDat=e$evalDat, evalRes=e$evalRes, modelId=e$modelId, runId=e$runId, modRetName=e$modRetName, model=e$model, 
                                modelTargetsList=e$modelTargetsList, log=e$log, e){
  startM <- Sys.time()
  stepName <- "Prepare the joint evaluation data set or the output data set"
  
  i <- 0
  evalMainRes <- list()
  evalMainRes <- foreach (i = 1:length(datList), .export=c("OREvalMainTargets", "RREvalMainTargets", "ORDefineModelType"), .errorhandling='stop', 
    .packages="doParallel") %do% {
    foreach (j = 1:length(modelTargets), .errorhandling='stop') %do% {      
      do.call(paste0(model, "EvalMainTargets"), list(i=i, j=j, datRes=datRes, modelTarget=modelTargets[j], modelTargetsList=modelTargetsList,
        interimModelTargets=interimModelTargets, evalDat=evalDat))
    }
  }
  
  if (stage == "modelling") {
    output <- list("evalMainRes"=evalMainRes, "evalMainResModelling"=evalMainRes)
  } else {
    output <- list("evalMainRes"=evalMainRes)
  }
      
  if (stage == "scoring") {
    outDat <- foreach (i = 1:length(datList), .errorhandling='pass', .packages="doParallel") %dopar% {
      j <- 1
      while (j <= length(modelTargets)) {
        if (j == 1) {
          outDat <- evalDat[[i]][, c("IRD_NUMBER", "RETURN_PERIOD_DATE_BASE", "RETURN_TYPE")]
          names(outDat)[2] <- "RETURN_PERIOD_DATE"
          outDat[, "MODEL_ID"] <- modelId
          outDat[, "RUN_ID"] <- runId
          outDat[, "LOCATION_NUMBER"] <- 1
          outDat[, "TAX_TYPE"] <- 'INC'
          outDat[, "FILING_FREQUENCY"] <- 1
          outDat[, "POPULATION_NO"] <- i
        }
        #outDat[, outputNames[j]] <- if (dim(evalMainRes[[i]][[j]])[2] > 1) evalMainRes[[i]][[j]][,2] else evalMainRes[[i]][[j]][,1]
        #outDat <- cbind(outDat, evalMainRes[[i]][[j]][,-which(names(evalMainRes[[i]][[j]])=="real_value")])
        outDat <- cbind(outDat, evalMainRes[[i]][[j]])
        outDat <- outDat[, -which(names(outDat)=="real_value")]
        j <- j+1
      }
      outDat              
    } 
    # combine results from separate datasets for each main target
    outDat <- CombineResults(datList=datList, datRes=outDat)
    output <- c(output, list("outDat"=outDat))
  }
  
  if (stage == "modelling"){
    # combine results from separate datasets for each main target - evaluation step
    evalAllRes <- list()
    for (j in 1:length(modelTargets)) {
      evalAllRes[[j]] <- CombineResults(datList=datList, datRes = evalMainRes, x=j)
    }
    output <- c(output, list("evalAllRes"=evalAllRes))
    
    evalInterim <- list()
    for (j in 1:length(modelTargets)) {
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text') 
      evalInterim[[j]] <- list()
      for (k in 1:length(intTargets)){
        evalInterim[[j]][[k]] <- CombineResults(datList=datList, datRes=evalRes, x=j, y=k)
      }
    }
    output <- c(output, list("evalInterim"=evalInterim))
  }
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  output
}

