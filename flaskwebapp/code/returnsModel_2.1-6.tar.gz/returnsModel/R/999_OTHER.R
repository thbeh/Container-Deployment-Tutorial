CalcRFDepth <- function(){
  modelFit <- modelFits[[1]][[1]][[3]]
  
  maxDepth <- c()
  medDepth <- c()
  
  for (k in 1:1000){
    
    if (modelFit$type == "classification"){
      m <- modelFit$forest$treemap[ , , k]
      mf <- as.data.frame(m)
    } else {
       mLeft <- modelFit$forest$leftDaughter[, k]
       mRight <- modelFit$forest$rightDaughter[, k]
       mf <- data.frame("V1"=mLeft, "V2"=mRight)
    }
    
    termNodes <- which(mf[, 1] == 0 & mf[, 2] == 0)
    
    depths <- c()
    
    for (j in 1:length(termNodes)){
      
      i <- 0
      node <- termNodes[j]
    
      while (length(node) != 0){
        i <- i + 1
        node <- which(mf[, 1] == node | mf[, 2] == node)
      }
      
      depths[j] <- i - 1
    
    }
      
    maxDepth[k] <- max(depths)
    #mean(depths[depths != 0])
    medDepth[k] <- median(depths[depths != 0])
  }  
  
  max(maxDepth)
  median(maxDepth)
  median(medDepth)
}