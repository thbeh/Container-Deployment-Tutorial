
ORSelectObjectsDrill <- function(dcon=e$dcon, 
                                 firstYear=as.character(as.numeric(eval(e$year)) - eval(e$yearsBack)), 
                                 lastYear=as.character(as.numeric(eval(e$year)) - 1), 
                                 timestampB0=eval(format(Sys.Date(), "%d-%m-%Y"))){
  
  timestB0 <- paste0("to_timestamp('", timestampB0, "', 'DD-MM-YYYY')")
  
  ppqry <- paste0("  
    create table `dfs`.`tmp`.`BASE_TABLE` as
      SELECT 
        columns[0] as IRD_NUMBER, 
        columns[1] as LOCATION_NUMBER,
        columns[2] as RETURN_TYPE, 
        columns[3] as RETURN_PERIOD_DATE,
        columns[14] as AS_AT
      FROM 
        `dfs`.`default`.`./poc/AZ/Collections/CollectionsRaw3of4/POLICING_PROFILES.txt`
      WHERE 
        columns[2] = 'IR6' and
        columns[3] >= to_timestamp('31-03-", firstYear,"', 'dd-MM-YYYY') and
        columns[3] <= to_timestamp('31-03-", lastYear,"', 'dd-MM-YYYY') and
        columns[14] < columns[16] and (
          columns[11]='RL'
          or columns[11]='NR' 
          or (columns[11]='UN' and columns[12] < 'A')) and
        columns[4] < ", timestB0," and
        (NULLIF(columns[19],'') > ", timestB0," or NULLIF(columns[19],'') IS NULL)
      LIMIT 100
  ")
  
  #LIMIT 1000
  #NULLIF(columns[19],'') is null and
  #columns[11] in ('RL','NR') and
  #columns[3]  > to_timestamp('01-01-2005', 'DD-MM-YYYY') 
  #and add_months(pp.date_actually_due,60) > pp.date_finalised)
  
  sergeant::drill_query(dcon, "DROP TABLE IF EXISTS `dfs`.`tmp`.`BASE_TABLE`")
  st <- Sys.time()
  sergeant::drill_query(dcon, ppqry)
  Sys.time() - st
  
  #sergeant::drill_query(dcon, "select count(*) from `dfs`.`tmp`.`BASE_TABLE`")
  #sergeant::drill_query(dcon, "select * from `dfs`.`tmp`.`BASE_TABLE`")
  
}