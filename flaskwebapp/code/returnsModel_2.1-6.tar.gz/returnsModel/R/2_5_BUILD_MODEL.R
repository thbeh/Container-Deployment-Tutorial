##########------BUILD THE MODEL------############
#' Build the Random Forest model
#' 
#' \code{BuildModel} builds classification or regression Random Forest models for each interim model target.
#'  
#' This function prepares each sub-population for modelling (excludes excessive columns, imputes missing values, converts classification fields into factors),
#'  calls function which calculates a required proportion of elements of different classes in the sub-population (for classification models), and finally calls the
#'  function which builds the Random Forest model (regression or classification) for each interim target.
#' 
#' This function is run within the \code{\link{RunModelling}} function, but it also can be run separately. 
#'   
#' @inheritParams RunModelling
#' @inheritParams FullModelling
#' @inheritParams PrepareFieldsNames
#' @inheritParams CreateValues
#' @param datList A list. Each element of this list is a sub-population of the modelling population.  
#' @param dat A data frame. The model building population (covariates and targets).
#' @param excludeCov A vector of names of covariates that shouldn't participate in the model.
#' @param interimModelTargets A vector of nams of interim model targets.
#' @param modelTargets A vector of names of main model targets.
#' @param classificCovShort Short names for classification keypoints participating in income covariates creation.
#' @param groupCovNames A list. The length of the list is equal to the number of covariates groups participating in the modelling.
#'  Each element in this list contains a vector with names of covariates (without period, e.g. "finalisation_code", not "finalisation_code_b0") 
#'  from a particular covariates group.
#' 
#' @return  A list of objects of class \code{randomForest}. This list has three levels: the sub-population's number, the index of a main target,
#'  the index of an interim target.
#'  
#' @examples
#'  \dontrun{
#'    # Use all parameters with default values
#'    BuildModel(e=e)}
#'  
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
BuildModel <- function(datMod, modelTargets=e$modelTargets, interimModelTargets=e$interimModelTargets,
                       method=e$method, ss=e$ss, coeff=e$coeff, setMtry=e$setMtry, nTrees=e$nTrees,
                       alg=e$alg, modelPath=e$modelPath, e){
  
  startM <- Sys.time()
  stepName <- "Build the model" 
  
  if (modelPath != ""){
    unlink(x=paste0(modelPath, list.files(path=modelPath)), recursive=TRUE)
  }
  
  excludeCols <- c("IRD_NUMBER", "RETURN_PERIOD_DATE_BASE", "RETURN_TYPE", interimModelTargets) 
  
  # building the model!
  i <- 0
  #foreach(i=1:1,
  foreach(i=1:length(datMod), 
          .packages=c("doParallel", "randomForest"), 
          .export=c("DatSampling", "BuildModel_RSpark_RF", "BuildModel_R_RF", "CreateBalancedDataset", 
                    "MakeSparkConnection", "CalcBalParam", "SetMtry", "FindClassificBalCoef", "ChoseInterimModels", "DatSampling"), 
          .errorhandling='pass', .verbose=FALSE) %do% {
      
    #print(paste0("i=", i, "\n"))
    
    RFDat <- datMod[[i]] 
    exclCols <- excludeCols
      
    j <- 0
    #foreach(j=1:1, 
    foreach(j=1:length(modelTargets), 
            .packages=c("doParallel", "randomForest"), 
            .export=c("DatSampling", "BuildModel_RSpark_RF", "BuildModel_R_RF", "CreateBalancedDataset", 
                      "MakeSparkConnection", "CalcBalParam", "SetMtry", "FindClassificBalCoef", "ChoseInterimModels", "DatSampling"), 
            .errorhandling='pass', .verbose=FALSE) %do% {
      
      #print(paste0("j=", j, "\n"))
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')        
      
      k <- 0
      #foreach(k=1:1, 
      foreach(k=1:length(intTargets), 
              .packages=c("doParallel", "randomForest"), 
              .export=c("DatSampling", "BuildModel_RSpark_RF", "BuildModel_R_RF", "CreateBalancedDataset",
                        "MakeSparkConnection", "CalcBalParam", "SetMtry", "FindClassificBalCoef", "DatSampling"), 
              .errorhandling='pass', .verbose=FALSE) %dopar% {
        
        #print(paste0("k=", k, "\n")) 
        target <- intTargets[k]        
        RFdat <- RFDat[!is.na(RFDat[, target]), ]
        
        v <- CalcBalParam(RFdat, target, method, coeff, ss, FindClassificBalCoef)
        
        # if either "reduce_sampling" or "oversampling" balancing methods was selected,
        # the population is balanced before the model build according to values from "v1" vector.
        # if "reduce_param" method is used, "v2" vector's values are used in the "sampsize" parameter of the randomForest function,
        # otherwise default value of "sampsize" is used.
        if (length(v[[1]]) != 0) {
          RFdat <- CreateBalancedDataset(RFdat=RFdat, target=target, v1=v[[1]], nameMin=v[[3]], nameMax=v[[4]], DatSampling=DatSampling)
        }
          
        # Edit mtry for regression (if the default value is too high) only if setMtry is TRUE
        # otherwise use a default value (if setMtry is FALSE) or a given value (if setMtry is numeric)
        # Always use a given value or default value for classification
        mtry <- SetMtry(RFdat, target, setMtry, exclCols)
        
        if (alg == "RSpark_RF"){
          sparklyr::spark_disconnect(sc)
          gc()
          sc <- MakeSparkConnection()
          RFfit <- BuildModel_RSpark_RF(RFdat=RFdat, target=target, nTrees=nTrees, exclCols=exclCols, sc=sc, i=i, j=modelTargets[j], 
                                        modelPath=modelPath)
          #sparklyr::spark_disconnect(sc)
          gc()
        }
        
        if (alg == "R_RF"){
          RFfit <- BuildModel_R_RF(RFdat=RFdat, target=target, nTrees=nTrees, exclCols=exclCols, mtry=mtry, v2=v[[2]])
          RFfit
        }
      }      
    }                 
  }
  #e$log <- LogEdit(modRetName, stepName, log, startM)
  #RFfit
  
}


#############################################################################################################################

# For classification models only.
# Calculate the required number of elements of the minority and majority classes.
# A balancing of the data sample before or during the classification model building is often necessary to obtain the model with
# a good classification accuracy for all labels (classes) of a target. It is especially important if an initial population is 
# very unbalanced.
#
# input:
#   RFdat - a data frame for a certain sub-population (missing values imputed, classification target and covariates are presented as factors).
#   target - a name of an interim classification target.
#   coeff - a desirable proportion of elements of the minority class in the population (should be from 0 to 1, default value is 0.5).
#   method - a character string. Possible values: "reduce_sampling", "reduce_param", "oversampling".
# A method define two characteristics of balancing:
#  1) when does the balancing have it's place
#    a) the population can be balanced prior to the model build
#    b) we can balance not the population itself, but each sample selected from the population for a particular decision tree build.
#       I think this approach is better, because it combines preferences of balancing with usage of a full population (different chunks of 
#       data are used for each tree build - if the number of trees is big enough, all or almost all available data should be covered).
#  2) Reducing a data sample or oversampling:
#    a) Oversample elements of the minority class
#    b) Reduce the number of elements of the majority class
# Accordingly:
#  
#  "reduce_sampling" method - balance before model build (1a), reduce the majority class (2b)
#  "oversampling" method - balance before model build (1a), oversample the minority class (2a)
#  "reduce_param" method - balancing of samples (1b), reduce the majority class (2b) <-- DEFAULT METHOD
#   the combination of balancing of samples (1b) and oversampling (2a) is not supported by the RandomForest function.
#
# output:
#   a list of following objects:
#   - v1 - a vector with the number of elements of the minority and majority class. It shows how many elements of each class should be 
#           left / created in the population prior to the model build. This vector is used for "reduce_sampling" and "oversampling" methods.
#   - v2 - a vector with the number of elements of the minority and majority class. It shows how many elements of each class should be 
#           left / created in each sample selected from the population during the model build. This vector is used for the "reduce_param" method.
#   - nameMin - a name of the minority class.
#   - nameMax - a name of the majority class.
#
FindClassificBalCoef <- function(RFdat, target, method="reduce_param", coeff=0.5, ss){
  
  s <- summary(RFdat[, target])
  
  # number of elements of each class
  nMin <- min(s)
  nMax <- max(s)
  
  # labels of minority and majority classes
  nameMin <- names(s)[which(s == nMin)]
  nameMax <- names(s)[which(s == nMax)]
  
  if (length(nameMin) > 1){nameMin <- nameMin[1]}
  if (length(nameMax) > 1){nameMax <- nameMax[2]}
  
  v1 <- c()
  v2 <- c()
  
  if (method == "reduce_param") {
    v2 <- c(min(nMin, ss * coeff), min(nMax, nMin * (1 - coeff) / coeff, ss * (1 - coeff)))
  }
  
  if (method == "reduce_sampling"){
    v1 <- c(min(nMin, ss * coeff), min(nMax, nMin * (1 - coeff) / coeff, ss * (1 - coeff)))
  }
  
  if (method == "oversampling"){
    v1 <- c(min(nMax * coeff / (1 - coeff), ss * coeff), min(nMax, ss * (1 - coeff)))
  }
  
#   if (method == "oversampling_new"){
#     m <- 1
#     while (nMin*m / (nMin*m + nMax) *100 < 15 & m <= 5)
#       m <- m+1
#     
#     v1 <- c(nMin*m, nMax)
#     
#     v2 <- c(min(nMin*m, ss*coeff), min(nMax, ss - min(nMin*m, ss*coeff)))
#   }
#   
#   if (method == "oversampling_new1"){
#     v1 <- c(2*nMin, (nMax+nMin)/2-nMin) 
#   }
  
  list(v1, v2, nameMin, nameMax)
}

#--------------------------------------------------------------------

# Balance the data sample (if "reduce_sampling" or "oversampling" method is used)
# input:
#   RFdat - a dataset that will be balanced
#   target - a classification target's name
#   v1 - a vector with calculated number of elements of each class (shows how many elements of each class should be left/created in the 
#         population to do it balanced according to given balanced method and coefficient parameters values)
#   nameMin - a name of the minority class
#   nameMax - a name of the majority class
# output:
#   RFdat - a balanced dataset
CreateBalancedDataset <- function(RFdat, target, v1, nameMin, nameMax, DatSampling){

  RFDatMin <- RFdat[RFdat[,target] == nameMin,]
  ssMin <- v1[1]
  RFDatMin <- DatSampling(RFDatMin, ssMin)
          
  RFDatMax <- RFdat[RFdat[,target] == nameMax,]
  ssMax <- v1[2]
  RFDatMax <- DatSampling(RFDatMax, ssMax)
          
  RFdat <- rbind(RFDatMin, RFDatMax)
  
  RFdat

}

  
#--------------------------------------------------------------------

# Build the randomForest model
# input:
#   RFdat - a data frame for a certain sub-population (missing values imputed, classification target and covariates are presented as factors)
#   v2 - a vector with the number of elements of the minority and majority class. It shows how many elements of each class should be 
#        left / created in each sample selected from the population during the model build. This vector is used for the "reduce_param" method.
#   target - a name of an interim classification target.
#   nTrees - The Random Forest algorithm's parameter. It defines the number of random trees to grow.
#   mtry - The Random forest algorithm's parameter. Number of covariates randomly sampled for each separate decision tree building.
# output:
#   RFfit - An object of class randomForest.

BuildModel_R_RF <- function(RFdat, target, nTrees, exclCols, mtry, v2, sc=""){
  
  #set.seed(17)
  
  # if mtry was passed as a parameter of the function
#   if (length(mtry) > 0){
#     RFfit <- randomForest(RFdat[ , target] ~ .,
#                           data=RFdat[ , -exclCols],
#                           importance=TRUE,
#                           ntree=nTrees, 
#                           na.action=na.fail,
#                           mtry=mtry,
#                           sampsize = if (length(v2) != 0) v2 else nrow(RFdat))
#   } else {
#   # use default mtry  
#     RFfit <- randomForest(RFdat[ , target] ~ .,
#                           data=RFdat[ , -exclCols],
#                           importance=TRUE,
#                           ntree=nTrees, 
#                           na.action=na.fail,
#                           sampsize = if (length(v2) != 0) v2 else nrow(RFdat))
#   }
  
# Use x, y definition of target and covariates instead of a formula to keep the output model smaller  
# (a recommendation from the RandomForest help) 
  if (length(mtry) > 0){
    RFfit <- randomForest(x=RFdat[ , -which(names(RFdat) %in% exclCols)],
                          y=RFdat[ , target],
                          importance=TRUE,
                          ntree=nTrees, 
                          na.action=na.fail,
                          mtry=mtry,
                          proximity=FALSE,
                          sampsize = if (length(v2) != 0) v2 else nrow(RFdat), keep.inbag=TRUE)
  } else {
  # use default mtry  
    RFfit <- randomForest(x=RFdat[ , -which(names(RFdat) %in% exclCols)],
                          y=RFdat[ , target],
                          importance=TRUE,
                          ntree=nTrees, 
                          na.action=na.fail,
                          proximity=FALSE,
                          sampsize = if (length(v2) != 0) v2 else nrow(RFdat), keep.inbag=TRUE)
    
  }
  
  RFfit
}

#-----------------------------------------------------------------------------------

BuildModel_RSpark_RF <- function(RFdat, target, nTrees, exclCols, sc, i, j, modelPath){
  
  exclCols <- gsub(x = exclCols, pattern = target, replacement = "")  
  exclCols <- which(names(RFdat) %in% exclCols)
  
  RFdat <- RFdat[, -exclCols]
  RFdatSpark <- sparklyr::copy_to(sc, RFdat, overwrite = TRUE)
  
  formula <- as.formula(paste(target,"~", "."))   
  
  ###building the model
  RFfit <- sparklyr::ml_random_forest(RFdatSpark, formula, num.trees = nTrees, type = "auto")
  
  #saving model
  path <- paste0(modelPath, "model_", i, "_", j, "_", target)
  saved <- sparklyr::ml_save(RFfit, path)
  
  RFfit

}

#-----------------------------------------------------------------------------------

SaveStringToIndexLabels <- function(datMod, modelTargets=e$modelTargets, interimModelTargets=e$interimModelTargets, sc=e$sc, 
                                    method=e$method, ss=e$ss, coeff=e$coeff, e){
  
  i <- 0
  #foreach(i=1:1, .packages=c("doParallel", "sparklyr"), .export=c("ChoseInterimModels", "CalcBalParam", "CreateBalancedDataset"), .errorhandling='stop') %do% {
  foreach(i=1:length(datMod), .packages=c("doParallel", "sparklyr"), .export=c("ChoseInterimModels", "CalcBalParam", "CreateBalancedDataset"), .errorhandling='stop') %do% {
                                                                                      
    print(paste0("i=", i, "\n"))
    RFDat <- datMod[[i]]
                                                                                      
    j <- 0
    #foreach(j=1:1, .packages=c("doParallel", "sparklyr"), .export=c("ChoseInterimModels", "CalcBalParam", "CreateBalancedDataset", "FindClassificBalCoef", "DatSampling"), .errorhandling='stop') %do% {
    foreach(j=1:length(modelTargets), .packages=c("doParallel", "sparklyr"), .export=c("ChoseInterimModels", "CalcBalParam", "CreateBalancedDataset"), .errorhandling='stop') %do% {
      
      print(paste0("j=", j, "\n"))
                                                                                                
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')
      
      k <- 0
      #foreach(k=3:3, .packages=c("doParallel", "sparklyr"), .export=c("CalcBalParam", "CreateBalancedDataset"), .errorhandling='stop') %do% {
      foreach(k=1:length(intTargets), .packages=c("doParallel", "sparklyr"), .export=c("CalcBalParam", "CreateBalancedDataset", "FindClassificBalCoef", "DatSampling"), .errorhandling='stop') %do% {
                                                                                                                                                                                                                               
        print(paste0("k=", k, "\n"))
        target <- intTargets[k]
        
        if (is.factor(RFDat[, target])){
          RFdat <- RFDat[!is.na(RFDat[, target]), ]
           
          v <- CalcBalParam(RFdat, target, method, coeff, ss, FindClassificBalCoef)
          if (length(v[[1]]) != 0) {
            RFdat <- CreateBalancedDataset(RFdat=RFdat, target=target, v1=v[[1]], nameMin=v[[3]], nameMax=v[[4]], DatSampling)
          }
          
          targetColumn <- RFdat[, c("IRD_NUMBER", target)]
          
          targetColumn <- sparklyr::copy_to(sc, targetColumn, overwrite = TRUE) %>% 
            sparklyr::ft_string_indexer(target, "target_index") %>% 
            dplyr::collect()
          
          names(targetColumn)[2] <- "target"
          
          tab <- table(targetColumn$target, targetColumn$target_index) %>%
            as.data.frame(stringsAsFactors=FALSE)
          
          filter <- tab$Var1 %in% c("TRUE", "NIL", "POS") & tab$Freq > 0
          
          mainIndex <- as.numeric(tab[filter, "Var2"])
          
          sparklyr::tbl_uncache(sc, "targetColumn")
        } else {
          mainIndex <- NA
        }
        mainIndex
      }                                                                                                                                                                                                                                  
    }                 
  }
}

#-----------------------------------------------------------------------------------

ExtractCovarImportance <- function(datMod, modelTargets=e$modelTargets, interimModelTargets=e$interimModelTargets, 
                                   modelPath=e$modelPath, modelFits=e$modelFits, e){
  
  i <- 0
  #foreach(i=1:1, .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %do% {
  foreach(i=1:length(datMod), .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %do% {
    
    print(paste0("i=", i, "\n"))
    
    j <- 0
    #foreach(j=1:1, .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %dopar% {
    foreach(j=1:length(modelTargets), .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %do% {
      
      print(paste0("j=", j, "\n"))
      
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')
      
      k <- 0
      #foreach(k=3:3, .packages="doParallel", .errorhandling='stop') %dopar% {
      foreach(k=1:length(intTargets), .packages="doParallel", .errorhandling='stop') %do% {
        
        print(paste0("k=", k, "\n"))
        target <- intTargets[k]

        # config <- spark_config()
        # config$`sparklyr.shell.driver-memory` <- "8G"
        # config$`sparklyr.shell.executor-memory` <- "4G"
        # config$`spark.yarn.executor.memoryOverhead` <- "2G"
        # sc <- spark_connect(master = "local", config = config)
          
        #path <- paste0(modelPath, "model_", i, '_', modelTargets[j], '_', target)
        #modelLoaded <- ml_load(sc, path)
        
        modelLoaded <- modelFits[[i]][[j]][[k]] 
         
        imp <- sparklyr::ml_tree_feature_importance(sc, modelLoaded)
        imp$importance <- as.numeric(as.character(imp[, 1]))
        imp$feature <- as.character(imp$feature)
        imp <- dplyr::arrange(imp, importance)
        
        #spark_disconnect(sc)
        gc()
        
        imp
      }
    }
  }
}

#--------------------------------------------------------------------------------

LoadModels <- function(datMod, sc=e$sc, modelPath=e$modelPath, modelTargets=e$modelTargets, 
                       interimModelTargets=e$interimModelTargets, e){
  
  i <- 0
  #foreach(i=1:1, .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %dopar% {
  foreach(i=1:length(datMod), .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %do% {
    
    print(paste0("i=", i, "\n"))
    
    j <- 0
    #foreach(j=1:1, .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %do% {
    foreach(j=1:length(modelTargets), .packages="doParallel", .export=c("ChoseInterimModels"), .errorhandling='stop') %do% {
      
      print(paste0("j=", j, "\n"))
      
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text')
      
      k <- 0
      #foreach(k=1:1, .packages="doParallel", .errorhandling='stop') %dopar% {
      foreach(k=1:length(intTargets), .packages="doParallel", .errorhandling='stop') %do% {
        
        print(paste0("k=", k, "\n"))
        path <- paste0(modelPath, "model_", i, '_', modelTargets[j], '_', intTargets[k])
        sparklyr::ml_load(sc, path)
      }
    }
  }
}


#---------------------------------------------

CalcBalParam <- function(RFdat, target, method, coeff, ss, FindClassificBalCoef){
  
  if (method != ""){
    if (is.factor(RFdat[, target])){
      v <- FindClassificBalCoef(RFdat=RFdat, target=target, method=method, coeff=coeff, ss=ss)
    } else {
      N <- dim(RFdat)[1]
      v <- list(c(), min(N, ss))
    }
  } else {v <- list(c(), c())}
  
  v
}

#---------------------------------------------

SetMtry <- function(RFdat, target, setMtry, exclCols){
  
  if (is.numeric(setMtry)){
    setMtry
  } else {
    if (is.factor(RFdat[, target])){
      NULL
    } else {
      if (is.logical(setMtry)){
        if (setMtry){
          covNmb <- (dim(RFdat)[2] - length(exclCols)) / 3
          if (covNmb > 30){
            30
          } else {
            covNmb
          }
        } else {
          NULL
        }
      } else {
        NULL
      }
    }
  }
}

