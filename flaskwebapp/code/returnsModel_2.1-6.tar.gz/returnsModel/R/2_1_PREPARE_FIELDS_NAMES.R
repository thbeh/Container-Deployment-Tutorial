
##########------PREPARE FIELDS NAMES--------############
#'  Prepare short fields names
#'  
#' \code{PrepareFieldsNames} creates short fields names and SQL chunks for the \code{CreateValues} function.
#' 
#' @inheritParams MakeDBConnections
#' @inheritParams FullModelling
#' @inheritParams SetModelParameters
#' @inheritParams RunModelling
#' @param stage A character string defining the stage of the model run. Possible values: "initialisation", "modelling", "scoring".
#'
#' @return \code{stage} - A character string defined the stage of the model run (initialisation / modelling / scoring).
#' @return \code{baseTable} - A name of the base table (depends on a model type, a return type and a current stage). 
#'  It's used during the database tables creation.
#' @return Only for the modelling stage:
#' \itemize{
#'   \item \code{targetFieldsShort} - A list of vectors with short names of income keypoints participating in the model targets creation.
#'   \item \code{targetFields} - A vector containing SQL chunks for income keypoints values creation (\code{nvl(...) as ...}). 
#'   \item \code{covList} - An updates vector of covariates keypoints without target keypoints.
#'   \item \code{covFieldsShort} - A list of short names for keypoints participating in income covariates creation.
#'   \item \code{covFields} - A vector containing SQL chunks for income keypoints values creation (\code{nvl(...) as ...}). 
#'   \item \code{classificCovShort} - A list of short names for classification keypoints participating in income covariates creation.
#'   \item \code{rpdTextBack} - A list of SQL chunks for conditions on the return period date fields for different years 
#'    (the size of a vector depends on the \code{covYearsBack} parameter value).
#'   \item \code{aggCovars} - A vector with names of covariates from the "AGGREGATED INCOME TAX FIELDS" group.
#'   \item \code{aggCovarsText} - A list of SQL code chunks for creation of covariates from the "AGGREGATED INCOME TAX FIELDS" group.
#'   \item \code{timeDiffers} - A list of SQL code chunks for the creation of an auxiliary table with possible time differences between 
#'    the base return period dates and covariates' return period dates.
#' }
#'
#' This function is run within \code{\link{RunModelling}} and \code{\link{RunScoring}} functions. It can also be run independently.
#'
#' @examples
#' \dontrun{
#'   # Prepare fields names at the modelling step
#'   PrepareFieldsNames(stage="modelling", e=e)
#' }
#'  
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
PrepareFieldsNames <- function(stage="modelling", modRetName=e$modRetName, targetList=e$targetList, targetTransf=e$targetTransf,
                                covList=e$covList, covTransf=e$covTransf, classificCov=e$classificCov, 
                                covYearsBack=e$covYearsBack, log = e$log, e){

  startM <- Sys.time()
  stepName <- "Prepare fields names"
  
  output=list()
  
  # update the stage and the base table name
  output[["stage"]] <- stage
  output[["baseTable"]] <- CreateBaseTableName(stage=stage, modRetName=modRetName)

  # prepare short fields names and other SQL chunks for values creation
  if (stage == "modelling"){
    targetFieldsShort <- CreateShortNames(List=targetList, transf=targetTransf)
	  targetFields <- CreateNvlText(List=targetList, transf=targetTransf, fieldsShort=targetFieldsShort, classificCov=c())
		
	  covList <- covList[-which(toupper(covList) %in% toupper(targetList))]
	  
	  covFieldsShort <- CreateShortNames(List=covList, transf=covTransf)
	  covFields <- CreateNvlText(List=covList, transf=covTransf, fieldsShort=covFieldsShort, classificCov)
    
	  classificCovShort <- CreateShortNames(classificCov, transf=list())
    
    i <- 0
    rpdTextBack <- foreach (i = 1:covYearsBack) %do% paste0(" add_months(base.return_period_date, ", i*(-12), ")")
    
    aggCovars <- CreateAggrCovar(targetFieldsShort)
    aggCovarsText <- CreateAggrCovarText(targetFieldsShort)
    
    timeDiffers <- foreach (i = 0:covYearsBack) %do% {paste0("SELECT ", i," AS time_differ FROM dual")}
    
    output <- c(output, list("targetFieldsShort"=targetFieldsShort, "targetFields"=targetFields, "covList"=covList, 
                "covFieldsShort"=covFieldsShort, "covFields"=covFields, "classificCovShort"=classificCovShort, 
                "rpdTextBack"=rpdTextBack, "aggCovars"=aggCovars, "aggCovarsText"=aggCovarsText, "timeDiffers"=timeDiffers))
  }

  e$log <- LogEdit(e$modRetName, stepName, log, startM)
  
  output
}

##############################################################################################

# Set baseTable name
# input:
#   stage - could be "modelling" or "scoring"
#   modRetName - a character string with the current model type and return type (for example, \code{"RR_IR3"}).
# output:
#   baseTable - the base table name. This name is actually used as name of the database table.
CreateBaseTableName <- function(stage, modRetName){
  if (stage == "modelling")
    baseTable <- paste0(tolower(modRetName), "_base_value")
  if (stage == "scoring")
    baseTable <- paste0(tolower(modRetName), "_scoring")
  baseTable
}

#--------------------------------------------------------------------------------------------------

# Function for shrinking fields names by deleting some vowel letters at the end of a word
# to comply with Oracle restrictions (the length of field's name can't be longer than 30 symbols)
# input:
#   name - an initial field name (keypoint name)
#   nMax - a maximum allowable initial length of a field name 
#    (nMax value is set taking into account all prefixes and suffixes that will be added to initial keypoints names
#    in the algorithm)
# output:
#   a shortened name
ShrinkName <- function(name, nMax) {
  if (nchar(name) > nMax) {
    vow <- c("a", "e", "o", "u", "y", "d") #without "i" to keep "inc" for "income" ; + "d" for "DIV_RWT_WITHHOLDING_CR_805"
    letters <- strsplit(name, '')[[1]]
    vowLetters <- which(strsplit(tolower(name), '')[[1]] %in% vow)
    nExcessLet <- nchar(name) - nMax
    vowMaxPosition <- vowLetters[length(vowLetters) - nExcessLet]
    name <- paste0(letters[-vowLetters[vowLetters > vowMaxPosition]], collapse="")
    name
  } else {name}
}
# I think the code can be shorter if using the gregexpr function, but it works properly, so that I decided to leave it as it is.

#--------------------------------------------------------------------------------------------------

#-----create short target/covariates names
# This function deletes the numeric part of keypoints names and shrinks its to the maximum allowable length.
# This function is suitable for both the targets and covariates lists.
# For calculated fields (which are presented as an expression of two keypoints), 
# the function includes a given calculated field name into the vector of targets / covariates names,
# and excludes initial keypoints (parts of that expression) names from the vector of targets / covariates names.
# input:
#   List - the targetList or covarList
#   transf - a list of transformations (if any)
# output:
#   the list of targets/covariates' short names
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
CreateShortNames <- function(List, transf) {
  namesTr <- c()
  namesSh <- c()
  # set names for calculated fields
    i <- 1
    while (i <= length(transf)) {
      #listOfTransf <- List[c(as.numeric(transf[[i]]['keypoint1']), as.numeric(transf[[i]]['keypoint2']))]
      namesTr <- c(namesTr, transf[[i]]['fieldName'])
      List <- setdiff(List, c(transf[[i]]['keypoint1'][[1]], transf[[i]]['keypoint2'][[1]]))
      i <- i+1
    }  
  # short other targets/covariates names
  namesSh <- foreach(name=List) %do% {
    name <- substr(name, 1, max(which(strsplit(name, '')[[1]]=='_'))-1)
    ShrinkName(name, 21)
  }
  # join vectors
  c(namesTr, namesSh)
}

#--------------------------------------------------------------------------------------------------

#---create text chunks for SQL statements ("... NVL(keypoint_name,0) as field_name")
# This function is suitable for both the targets and covariates lists.
# Also, for complex fields, which are calculated as an expression of two keypoints,
# this function creates an SQL statement for these fields calculation.
# input:
#   List - the targetList or covarList
#   transf - a list of targets/covariates transformations (if any)
#   fieldsShort - short targets / covariates names (the output of the CreateShortNames function)
# output:
#   SQL text for keypoints selection
CreateNvlText <- function(List, transf, fieldsShort, classificCov) {
  calcField = list()
  calcFieldStr =  c()
  fields <- c()
  # create SQL chunks for calculated targets
    i <- 1
    while (i <= length(transf)) {
      #listOfTransf <- 
      calcField[[i]] <- c("nvl(ir.", transf[[i]]['keypoint1'][[1]], ",0)", transf[[i]]['sign'], 
                         "nvl(ir.", transf[[i]]['keypoint2'][[1]], ",0) as ", transf[[i]]['fieldName'], ",")
      calcFieldStr[i] <- paste0(calcField[[i]], collapse="")
      List <- setdiff(List,c(transf[[i]]['keypoint1'][[1]], transf[[i]]['keypoint2'][[1]]))
      i <- i+1
    }
  # create SQL chunks for other targets / covariates
  for (j in 1:length(List))
    if (List[j] %in% classificCov)
      fields[j] <- paste0("ir.", List[j], " as ", fieldsShort[[j+length(transf)]], ",") else
      fields[j] <- paste0("nvl(ir.", List[j], ",0) as ", fieldsShort[[j+length(transf)]], ",")
  # join vectors
  c(calcFieldStr, fields)
}

#--------------------------------------------------------------------------------------------------

#   prepare SQL chunks for creation of aggregated income tax variables(min, max, avg etc.)
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
CreateAggrCovarText <- function(targetFieldsShort){
  name <- c()
  foreach(name=targetFieldsShort) %do% {
    paste0(
      ",\n min(",name,") min_", name,
      ",\n max(",name,") max_", name,
  	  ",\n avg(",name,") avg_", name,
		  ",\n round(min(CASE WHEN ",name, "<>0 THEN (RETURN_PERIOD_DATE_BASE-RETURN_PERIOD_DATE_COVARIATES)/365 END) ) ys_nn_", name,
		  ",\n sum(CASE WHEN ", name, ">0 THEN 1 ELSE 0 END) nm_po_", name,
		  ",\n sum(CASE WHEN ", name, "=0 THEN 1 ELSE 0 END) nm_ni_", name,
		  ",\n sum(CASE WHEN ", name, "<0 THEN 1 ELSE 0 END) nm_ne_", name
    )									   
  }
}

#--------------------------------------------------------------------------------------------------

CreateAggrCovar <- function(targetFieldsShort){
  aggCovar <- c()
  for(name in targetFieldsShort){
    aggCovar <- c(aggCovar, 
                  paste0("min_", name),    # minimum value
                  paste0("max_", name),    # maximum value
                  paste0("avg_", name),    # average value
                  paste0("ys_nn_", name),  # years since the last not nil return was filed
                  paste0("nm_po_", name),  # number of positive returns
                  paste0("nm_ni_", name),  # number of nil returns
                  paste0("nm_ne_", name))  # number of negative returns
  }
  aggCovar
}

#--------------------------------------------------------------------------------------------------

  