
# MODEL PARAMETERS FOR IR4 RETURN TYPE 
# THESE PARAMETERS VALUES ARE ALLOWED TO BE CHANGED BY EXPERIENCED USERS

#### ----------------------- (1) TARGERS -------------------------- ####

# --- Outstanding returns values targets --- #

# A vector of targets keypoints 
targetList <- c("TOTAL_INCOM_OR_NET_LOSS_100698", "RESIDUAL_INCOME_TAX_108", "TOTAL_SHAREHOLDER_SALARY_809")
# Targets transformations (if any)
targetTransf = list()


# --- Low-value definition targets --- #

# Target(s) name(s)
modelTargetsList <- c()

# Low-value targets formulas
DataSelect = list()


#### ----------------------- (2) COVARIATES -------------------------####

# Groups of covariates
participation <- c(
		"FINALISATION CODE",           #do not delete!
		"INCOME TAX RETURN FIELDS",    #do not delete!
		"CLIENT STATUS",			   #do not delete!
		"TAX ASSESSED AND PAID",
		"TAX REGISTRATIONS", 
		"GST RETURN EXTRACT", 
		"ANNUALISED EMPLOYMENT DATA", 
		"TAX AGENTS",
		"INBOUND INFO ABOUT CESSATION")
		
# A vector of keypoints, which will be considered in the model as covariates of the "INCOME TAX RETURN FIELDS" group.
# Note: Lists of covariates for other covariates groups are hard-coded and can be changed only on request.
covList <- c("OVERSEAS_TAX_CREDITS_107",
			"RESIDUAL_INCOME_TAX_108",
			"TAXABLE_INCOME_109",
			"TOTAL_LOSS_CARRIED_FWD_114",
			"TOTAL_TAX_CREDITS_115",
			"LOSS_CLAIMED_133",
			"LOSS_BROUGHT_FORWARD_136",
			"LAQC_LOSS_144",
			"GROSS_EARNINGS_407",
			"FRGN_INVESTORS_TAX_CREDS_428",
			"SHARE_OF_IMP_CREDITS_705",
			"TOTAL_SHAREHOLDER_SALARY_809",
			"OTHER_INCOME_LIABLE_100087",
			"TOTAL_INCOM_OR_NET_LOSS_100698")

# Classification income keypoints covariates
classificCov <- c()	

# Covariates transformations (if any)
covTransf = list()
covTransf[[1]] <- c(fieldName="OTHER_INCOME", keypoint1="GROSS_EARNINGS_407", sign="+", keypoint2="OTHER_INCOME_LIABLE_100087")


#### ----------------------- (3) CUTOFF COEFF  -------------------------####
cutOffCoeff <- 0.85

