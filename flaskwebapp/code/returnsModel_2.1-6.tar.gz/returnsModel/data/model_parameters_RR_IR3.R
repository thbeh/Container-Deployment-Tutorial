
# MODEL PARAMETERS FOR IR3 RETURN TYPE 
# THESE PARAMETERS VALUES ARE ALLOWED TO BE CHANGED BY EXPERIENCED USERS
# Note: The same parameters are uased for the IR3 and IR3A amalgamated model

#### ----------------------- (1) TARGERS -------------------------- ####

# --- Outstanding returns values targets --- #

# A vector of targets keypoints 
targetList <- c("INCOME_AFTER_EXPENSES_101", "RESIDUAL_INCOME_TAX_108", "TOTAL_EXPENSES_CLAIMED_100026")
# Targets transformations (if any)
targetTransf = list()


# --- Low-value definition targets --- #

# Target(s) name(s)
#modelTargetsList <- c()
modelTargetsList <- c("RR_PROB_NIL_4")

# Low-value targets formulas
DataSelect = list()

DataSelect[[1]] <- function(dat){                
  return(abs(dat$RESIDUAL_INCOME_TAX_B0) <= 200 & dat$INCOME_AFTER_EXPENSES_B0 <= 1000 & dat$INCOME_AFTER_EXPENSES_B0 >= -10000)
}


#### ----------------------- (2) COVARIATES -------------------------####

# Groups of covariates
participation <- c(
		"FINALISATION CODE",           #do not delete!
		"INCOME TAX RETURN FIELDS",    #do not delete!
		"CLIENT STATUS",			   #do not delete!
		"TAX ASSESSED AND PAID",
		"TAX REGISTRATIONS", 
		"GST RETURN EXTRACT", 
		"ANNUALISED EMPLOYMENT DATA", 
		"EMS SCHEDULE INFORMATION",
		"TAX AGENTS",
		"INBOUND INFO ABOUT CESSATION")
		
# A vector of keypoints, which will be considered in the model as covariates of the "INCOME TAX RETURN FIELDS" group.
# Note: Lists of covariates for other covariates groups are hard-coded and can be changed only on request.
covList <- c("INCOME_AFTER_EXPENSES_101",
			  "OVERSEAS_TAX_CREDITS_107",
			  "RESIDUAL_INCOME_TAX_108",
			  "TAXABLE_INCOME_109",
			  "TOTAL_LOSS_CARRIED_FWD_114",
			  "TOTAL_TAX_CREDITS_115",
			  "LOSS_CLAIMED_133",
			  "LOSS_BROUGHT_FORWARD_136",
			  "GROSS_EARNINGS_407",
			  "NET_PROFIT_702",
			  "TOTAL_REBATES_703",
			  "SHARE_OF_IMP_CREDITS_705",
			  "TAX_ON_TAXABLE_INCOME_721",
			  "OTHER_TAX_DEDUCTIONS_799",
			  "TOTAL_INTEREST_802",
			  "TOTAL_GROSS_DIVIDENDS_804",
			  "TOTAL_ESTATE_TRUST_INCOME_806",
			  "TOTAL_PARTNERSHIP_INCOME_808",
			  "TOTAL_SHAREHOLDER_SALARY_809",
			  "NET_RENTS_826",
			  "OTHER_INCOME_827",
			  "OVERSEAS_INCOME_828",
			  "TOTAL_EXPENSES_CLAIMED_100026",
			  "ALLOWABLE_IMP_CREDITS_100607",
			  "TOTAL_ACTIVE_LTC_INCOME_100792",
			  "FUTUR_SHR_EMPLOYEE_SLRY_100795",
			  "SCHEDULAR_EXPENSES_100827")

# Classification income keypoints covariates
classificCov <- c("FUTUR_SHR_EMPLOYEE_SLRY_100795")	

# Covariates transformations (if any)
covTransf = list()


#### ----------------------- (3) CUTOFF COEFF  -------------------------####
cutOffCoeff <- 0.85

