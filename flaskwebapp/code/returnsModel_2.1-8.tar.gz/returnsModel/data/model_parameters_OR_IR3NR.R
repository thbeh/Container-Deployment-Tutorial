
# MODEL PARAMETERS FOR IR3NR RETURN TYPE 
# THESE PARAMETERS VALUES ARE ALLOWED TO BE CHANGED BY EXPERIENCED USERS

#### ----------------------- (1) TARGERS -------------------------- ####

# --- Outstanding returns values targets --- #

# A vector of targets keypoints 
targetList <- c("RESIDUAL_INCOME_TAX_108")
# Targets transformations (if any)
targetTransf = list()


# --- Purification targets --- #

# Purification targets names
modelTargetsList <- c("PROB_RIT_LESS_200")
# Purification targets formulas
DataSelect = list()
DataSelect[[1]] <- function(dat){                
  return(dat$RESIDUAL_INCOME_TAX_B0 < 200)                                            
}


#### ----------------------- (2) COVARIATES -------------------------####

# Groups of covariates
participation <- c(
		"FINALISATION CODE",           #do not delete!
		"INCOME TAX RETURN FIELDS",    #do not delete!
		"CLIENT STATUS",			   #do not delete!
		"AGGREGATED INCOME TAX FIELDS",
		"TAX ASSESSED AND PAID",
		"TAX REGISTRATIONS", 
		"GST RETURN EXTRACT", 
		"ANNUALISED EMPLOYMENT DATA", 
		"EMS SCHEDULE INFORMATION",
		"TAX AGENTS",
		"INBOUND INFO ABOUT CESSATION",
		"REFERENCES STATUS")
		
# A vector of keypoints, which will be considered in the model as covariates of the "INCOME TAX RETURN FIELDS" group.
# Note: Lists of covariates for other covariates groups are hard-coded and can be changed only on request.
covList <- c("INCOME_AFTER_EXPENSES_101",
			"RESIDUAL_INCOME_TAX_108",
			"TOTAL_LOSS_CARRIED_FWD_114",
			"LOSS_CLAIMED_133",
			"LOSS_BROUGHT_FORWARD_136",
			"GROSS_EARNINGS_407",
			"NET_PROFIT_702",
			"TAX_ON_TAXABLE_INCOME_721",
			"OTHER_TAX_DEDUCTIONS_801",
			"TOTAL_INTEREST_802",
			"TOTAL_GROSS_DIVIDENDS_804",
			"TOTAL_ESTATE_TRUST_INCOME_806",
			"TOTAL_PARTNERSHIP_INCOME_808",
			"NET_RENTS_826",
			"OTHER_INCOME_827",
			"TOTAL_EXPENSES_CLAIMED_100026",
			"TOTAL_TAX_CREDITS_100173",
			"WORK_IN_NZ_INDICATOR_100249")

# Classification income keypoints covariates
classificCov <- c("WORK_IN_NZ_INDICATOR_100249")	

# Covariates transformations (if any)
covTransf = list()



#### ----------------------- (3) EVALUATION.XLSM REPORT PARAMETERS -------------------------####

# Outstanding returns model targets and purification targets that should be considered together in the evaluation report (a list of pairs of related targets)
complemTargets=list(c("RESIDUAL_INCOME_TAX", "PROB_RIT_LESS_200"))

# Short targets names which will be used as Excel worksheets names. A vector of the same length as complemTargets list.
shortNames = c("RIT")

# Values of the target keypoints which distinguish low-value returns and high-value returns. A vector of the same length as complemTargets list.
# Generally, this threshold is the same with the threshold used in the definition (formula) of a corresponded purification target.
thVal = c(200)

# Threshold values for estimated absolute values of target keypoints. A list of the same length as complemTargets list.
estTh = list(c(0, 200, 500, 1000))

# Threshold values for estimated probabilities (probabilities of keypoints are being NIL, probabilities of keypoints are being less than N (purification targets)).
# A vector of the same length as complemTargets list.
prsTh = c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1)

