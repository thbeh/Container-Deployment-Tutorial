
# MODEL PARAMETERS FOR IR7 RETURN TYPE 
# THESE PARAMETERS VALUES ARE ALLOWED TO BE CHANGED BY EXPERIENCED USERS

#### ----------------------- (1) TARGERS -------------------------- ####

# --- Outstanding returns values targets --- #

# A vector of targets keypoints 
targetList <- c("TOTAL_TAX_CREDITS_115", "TOTAL_EXPENSES_829", "TOTAL_INCOME_100472")
# Targets transformations (if any)
targetTransf = list()
targetTransf[[1]] <- c(fieldName="INC_AFTER_EXP", keypoint1="TOTAL_EXPENSES_829", sign="+", keypoint2="TOTAL_INCOME_100472")


# --- Purification targets --- #

# Purification targets names
modelTargetsList <- c("PROB_INC_AFT_EXP_LESS_1000")

# Purification targets formulas
DataSelect = list()

DataSelect[[1]] <- function(dat){
  return(dat$INC_AFTER_EXP_B0 <= 1000)                                            
}


#### ----------------------- (2) COVARIATES -------------------------####

# Groups of covariates
participation <- c(
		"FINALISATION CODE",           #do not delete!
		"INCOME TAX RETURN FIELDS",    #do not delete!
		"CLIENT STATUS",			   #do not delete!
		"AGGREGATED INCOME TAX FIELDS",
		"TAX REGISTRATIONS", 
		"GST RETURN EXTRACT", 
		"ANNUALISED EMPLOYMENT DATA", 
		"TAX AGENTS",
		"INBOUND INFO ABOUT CESSATION")
		
# A vector of keypoints, which will be considered in the model as covariates of the "INCOME TAX RETURN FIELDS" group.
# Note: Lists of covariates for other covariates groups are hard-coded and can be changed only on request.
covList <- c("OVERSEAS_TAX_CREDITS_107",
			"TAXABLE_INCOME_109",
			"TOTAL_TAX_CREDITS_115",
			"GROSS_EARNINGS_407",
			"NET_PROFIT_702",
			"TOTAL_INTEREST_802",
			"RWT_AND_OTHER_TAX_CR_803",
			"TOTAL_GROSS_DIVIDENDS_804",
			"DIV_RWT_WITHHOLDING_CR_805",
			"PSHIP_ESTATE_TRUST_INCOME_810",
			"OVERSEAS_INCOME_828",
			"TOTAL_EXPENSES_829",
			"OTHER_INCOME_LIABLE_100087",
			"INC_DIST_TO_PARTNERS_100208",
			"TOTAL_INCOME_100472",
			"TAX_CREDITS_TO_PARTNERS_100524",
			"NET_INC_RNTAL_ACTVITIES_100785",
			"IR7P_ATTACHED_100800",
			"IR7L_ATTACHED_100801")

# Classification income keypoints covariates (if any)
classificCov <- c("IR7P_ATTACHED_100800", "IR7L_ATTACHED_100801")	

# Covariates transformations (if any)
covTransf = list()
covTransf[[1]] <- c(fieldName="OTHER_INCOME", keypoint1="NET_PROFIT_702", sign="+", keypoint2="OTHER_INCOME_LIABLE_100087")



#### ----------------------- (3) EVALUATION.XLSM REPORT PARAMETERS -------------------------####

# Outstanding returns model targets and purification targets that should be considered together in the evaluation report (a list of pairs of related targets)
complemTargets=list(c("INC_AFTER_EXP", "PROB_INC_AFT_EXP_LESS_1000"))

# Short targets names which will be used as Excel worksheets names. A vector of the same length as complemTargets list.
shortNames = c("INC_AFT_EXP")

# Values of the target keypoints which distinguish low-value returns and high-value returns. A vector of the same length as complemTargets list.
# Generally, this threshold is the same with the threshold used in the definition (formula) of a corresponded purification target.
thVal = c(1000)

# Threshold values for estimated absolute values of target keypoints. A list of the same length as complemTargets list.
estTh = list(c(0, 1000, 3000, 5000))

# Threshold values for estimated probabilities (probabilities of keypoints are being NIL, probabilities of keypoints are being less than N (purification targets)).
# A vector of the same length as complemTargets list.
prsTh = c(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1)

