
# THESE PARAMETERS VALUES CAN BE CHANGED
#---------------------------------------------------------------------------------
# Set the credentials to make an access to the database

# Set a path to a secure file with passwords
credentialsFullPathName <- "\\\\CMEKMODDEV01\\e\\SecureFolders\\67EKED\\db_credentials.txt"  
#credentials are stored as comma separated file, e.g. 
#dwp,username,password
#alczr_t,username,password

# DB credentials for EDW queries
dbnameEDW <- "DWP"
usernameEDW <- "67EKED"

# DB credentials for the Model output storage
dbnameMod <- "ALCZR"
usernameMod <- "Modelling"

# DB credentials for the property data
dbnameProp <- "ALCZR"
usernameProp <- "Modelling" 

#---------------------------------------------------------------------------------

# Set output tables names in the database
dbModelTable <- "MODEL"
dbLogTable <- "MODEL_RUN_LOG"
dbOutputTable <- "DOCUMENT_MODEL_OUTPUT"

# Set model attributes (name, owner, customer)
GiveModelName <- function(model){
  if (model == 'RR') {return("RIGHT_RETURNS_MODEL")} 
  if (model == 'OR') {return("OUTSTANDING_RETURNS_VALUE_MODEL")} 
  #if (model == 'RP') {return("RETURNS_PURIFICATION_MODEL")} 
}
#modelName <- GiveModelName(model)
modelOwner <- "IC_MODELLING"
modelCustomer <- "DELIVERY"
