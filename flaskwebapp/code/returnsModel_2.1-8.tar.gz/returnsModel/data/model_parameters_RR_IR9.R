
# MODEL PARAMETERS FOR IR9 RETURN TYPE 
# THESE PARAMETERS VALUES ARE ALLOWED TO BE CHANGED BY EXPERIENCED USERS

#### ----------------------- (1) TARGERS -------------------------- ####

# --- Outstanding returns values targets --- #

# A vector of targets keypoints 
targetList <- c("RESIDUAL_INCOME_TAX_108", "TOTAL_INCOM_OR_NET_LOSS_100698")
# Targets transformations (if any)
targetTransf = list()


# --- Low-value definition targets --- #

# Target(s) name(s)
modelTargetsList <- c()

# Low-value targets formulas
DataSelect = list()


#### ----------------------- (2) COVARIATES -------------------------####

# Groups of covariates
participation <- c(
		"FINALISATION CODE",           #do not delete!
		"INCOME TAX RETURN FIELDS",    #do not delete!
		"CLIENT STATUS",			   #do not delete!
		"S068 LETTERS",				   #do not delete!
		"TAX ASSESSED AND PAID",
		"TAX REGISTRATIONS", 
		"GST RETURN EXTRACT", 
		"ANNUALISED EMPLOYMENT DATA", 
		"TAX AGENTS",
		"INBOUND INFO ABOUT CESSATION")
		
# A vector of keypoints, which will be considered in the model as covariates of the "INCOME TAX RETURN FIELDS" group.
# Note: Lists of covariates for other covariates groups are hard-coded and can be changed only on request.
covList <- c("DEEMED_LOSS_102",
			"OVERSEAS_TAX_CREDITS_107",
			"RESIDUAL_INCOME_TAX_108",
			"TAXABLE_INCOME_109",
			"TOTAL_LOSS_CARRIED_FWD_114",
			"LOSS_CLAIMED_133",
			"LOSS_BROUGHT_FORWARD_136",
			"PROVISIONAL_INCOME_503",
			"OTHER_TAX_DEDUCTIONS_801",
			"OTHER_TAX_CREDITS_100231",
			"TOTAL_LOSSES_CFWD_100232",
			"TOT_INCOME_SPORTS_ORG_100233",
			"TOT_INCOME_OTHER_CLUB_100234",
			"TOTAL_INCOM_OR_NET_LOSS_100698")

# Classification income keypoints covariates
classificCov <- c()	

# Covariates transformations (if any)
covTransf = list()


#### ----------------------- (3) CUTOFF COEFF  -------------------------####
cutOffCoeff <- 0.75

