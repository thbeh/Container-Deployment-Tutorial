
##########------SAVE RESULTS--------############
#' Save the modelling results
#' 
#' \code{SavingResults} saves the output data in the Output table, creates an output view (optional), saves a workspace,
#'  drops all database tables that were created (optional), updates the LOG table (the model run status is set to "COMPLETE"), 
#'  returns the environment options to the initial statement.
#' 
#' The function runs the following functions:
#' \itemize{
#'  \item \code{UpdateOutputTable}
#'  \item \code{CreateOutputView}
#'  \item \code{SaveImage}
#'  \item \code{DropTables}
#'  \item \code{UpdateLogTable}, \code{writeLines}, \code{SetTimeZones}, \code{dbDisconnect}
#' }
#' 
#' This function is run within the \code{\link{FullModelling}} function, but also can be run separately. 
#'  
#' @inheritParams CreateValues
#' @inheritParams CreateDBLog
#' @inheritParams FullModelling
#' @inheritParams RunModelling
#' @inheritParams JoinSptittedResults
#' @inheritParams MakeDBConnections
#' @inheritParams PrepareFieldsNames
#' @param outDat A data frame with the scoring results. 
#' @param conn2 An Oracle connection to the Property schema.
#' @param dbOutputTable A name of the DB table used for saving the model output data.
#' @param oldTZs Initial \code{ORA_SDTZ} and \code{TZ} environment settings. They will have been changed to \code{"NZ"} time zone 
#'  until the end of calculation.
#' @param cl The number of clusters for parallel calculations.
#' 
#' @return The output of this function consists of the outputs of the functions listed in the \strong{Details} section.
#'  
#' @examples
#' \dontrun{
#'  SavingResults(returnName="IR7", dropTables=FALSE)
#' }
#' @export
SavingResults <- function(outDat=e$outDat, conn=e$conn, conn1=e$conn1, conn2=e$conn2, dbOutputTable=e$dbOutputTable, dbLogTable=e$dbLogTable,
                          outputPath=e$outputPath, returnName=e$returnName, runId=e$runId, dropTables=e$dropTables, runDate=e$runDate,
                          oldTZs=e$oldTZs, cl=e$cl, modRetName=e$modRetName, stage=e$stage, createView=e$createView, model=e$model, year=e$year, 
                          log=e$log, e){  
  
  
#   Sys.setenv(ORA_SDTZ = "NZ")
#   Sys.setenv(TZ = "NZ")
  
  ##########------SAVE THE OUTPUT DATA IN THE DOCUMENTS TABLE ------############
  startM <- Sys.time()
  stepName <- "Update the output table"
  UpdateOutputTable(conn1, dbOutputTable, outDat, runId)
  log <- LogEdit(modRetName, stepName, log, startM)
  
  ##########------ CREATE OUTPUT VIEW ------############
  if (createView){
    startM <- Sys.time()
    stepName <- "Create a view"
    e$viewName <- CreateOutputView(conn1, dbOutputTable, outDat, runId, returnName, model, year)
    log <- LogEdit(modRetName, stepName, log, startM)
  }
  
  ##########------SAVE THE WORKSPACE ------############
  startM <- Sys.time()
  stepName <- "Save the workspace"
  imageName <- SaveImage(e=e)
  log <- LogEdit(modRetName, stepName, log, startM)
  
  ##########------DROP TEMPORARY TABLES------############
  startM <- Sys.time()
  stepName <- "Drop temp tables"
  if (dropTables)
    DropTables(toupper(modRetName), conn)
  log <- LogEdit(modRetName, stepName, log, startM)
  
  ##########------UPDATE LOG TABLE------############
  startM <- Sys.time()
  stepName <- "Update the log table"
  status <- "COMPLETE"
  e$status <- status
  numRecords <- dim(outDat)[1]
  # trim the log if it is too long to be written into the corresponded DB table's field.
  if (nchar(log) > 4000) {logText <- paste0(substr(log, 1, 50), " <...>\n\n", substr(log, 60+nchar(log)-4000, nchar(log)))} else {logText <- log}
  UpdateLogTable(status=status, conn1=conn1, dbLogTable=dbLogTable, runId=runId, numRecords=numRecords, imageName=imageName, log=logText)
  e$log <- LogEdit(modRetName, stepName, log, startM)
    
  # Save a log
  writeLines(e$log, paste0(outputPath, "log_", returnName,".txt"))
  
  # Return environment options to the initial values
  SetTimeZones(status, oldORASDTZ=oldTZs[[1]], oldTZ=oldTZs[[2]])
  
  if (length(cl) != 0){
    parallel::stopCluster(cl)
  }
  
  # Close connections
  dbDisconnect(conn)
  dbDisconnect(conn1)
  dbDisconnect(conn2)
  #closeAllConnections() 
}

