fun <- function(){

######## Environment set up #############
rm(list = ls())
e <<- .GlobalEnv
log <- ""


### Install the returns package
detach("package:returnsModel", unload = TRUE)
remove.packages("returnsModel", lib="~/R/win-library/3.3")
#install.packages("Y:/AZ/Kate/returnsModel_2.1-4.zip", repos = NULL, type = "win.binary")
install.packages("Y:/AZ/Kate/returnsModel_2.1-4.tar.gz", repos = NULL, type = "source")

### Attach the library
library("returnsModel", lib.loc="~/R/win-library/3.3")

### Parameters set up

# Main parameters:
model <- "OR"
returnName <- "IR6"
modRetName <- "OR_IR6"
projectStage <- "TEST"   #TEST or PRODUCTION 
purificationOnly <- FALSE

# Data selection parameters:
year <- format(Sys.Date(), "%Y")
yearsBack <- if (projectStage == "TEST") {2} else {7}
covYearsBack <- 5
considerRR <- FALSE
UNbyUserIsNill <- TRUE
conditionalSplit <- FALSE
mask <- list(c("B1", "B2", "B3"), c("B1", "B2", "no B3"), c("B1", "no B2"), c("no B1", "B2"), c("no B1", "no B2", "any return"), c("no B1", "no B2", "no returns"))
timestampB0 <- format(Sys.Date(), "%d/%m/%Y")
clientStatusList <- c('A', 'U')
nrows <-1000

# Features and targets
targetFieldsShort <- list("OTHER_INCOME", "RESIDUAL_INCOME_TAX")  # main regression targets
modelTargetsList <- c("PROB_RIT_LESS_200", "PROB_OTHER_INC_LESS_1000", "PROB_NIL_INC_ALLOCN_TO_BNFICIR")  # main classification targets
DataSelect = list(
  function(dat){return(dat$RESIDUAL_INCOME_TAX_B0 <= 200)},                                  
  function(dat){return(dat$OTHER_INCOME_B0 <= 1000)},
  function(dat){return(dat$INC_ALLOCN_TO_BNFICIR_B0 == 0)}
)
#participation <- c('FINALISATION CODE', 'INCOME TAX RETURN FIELDS', 'CLIENT STATUS', 'INFORMATION ABOUT CUSTOMERS', 
#                   'AGGREGATED INCOME TAX FIELDS', 'TAX ASSESSED AND PAID', 'TAX REGISTRATIONS', 'GST RETURN EXTRACT', 
#                   'ANNUALISED EMPLOYMENT DATA', 'TAX AGENTS', 'REFERENCES STATUS IR6')

participation <- c('INCOME TAX RETURN FIELDS')

covFieldsShort <- list("INCOME_AFTER_EXPENSES", "OVERSEAS_TAX_CREDITS", "TAXABLE_INCOME", "TOTAL_LOSS_CARRIED_FW", "TOTAL_TAX_CREDITS", 
  "LOSS_CLAIMED", "LOSS_BROUGHT_FORWARD", "SHARE_OF_IMP_CREDITS", "INC_ALLOCN_TO_BNFICIR", "INC_ALLOC_TO_TRUSTEE", 
  "OVERSEAS_INCOME", "ESTATE_TRUST_EXS_CLIM")
classificCovShort <- list()
excludeCov <- c('S068_B0', 'S068_B1', 'S068_B2', 'S068_B3', 'S068_B4', 'S068_B5', 'ESTATE_TRUST_EXS_CLIM_B0', 'OVERSEAS_INCOME_B0', 
  'INC_ALLOC_TO_TRUSTEE_B0', 'INC_ALLOCN_TO_BNFICIR_B0', 'SHARE_OF_IMP_CREDITS_B0', 'LOSS_BROUGHT_FORWARD_B0', 
  'LOSS_CLAIMED_B0', 'TOTAL_TAX_CREDITS_B0', 'TOTAL_LOSS_CARRIED_FW_B0', 'TAXABLE_INCOME_B0', 'OVERSEAS_TAX_CREDITS_B0', 
  'INCOME_AFTER_EXPENSES_B0', 'RESIDUAL_INCOME_TAX_B0', 'OTHER_INCOME_B0', 'CLIENT_STATUS_B0', 'FINALISATION_CODE_B0', 
  'FINALISATION_CODE_B1', 'FINALISATION_CODE_B2', 'FINALISATION_CODE_B3', 'FINALISATION_CODE_B4', 'FINALISATION_CODE_B5', 
  'FINALISED_BY_B0', 'FINALISED_BY_B1', 'FINALISED_BY_B2', 'FINALISED_BY_B3', 'FINALISED_BY_B4', 'FINALISED_BY_B5')

# Model (Random Forest) parameters:
alg <- "R_RF"
ssMax <- 20000
ss <- 20000
nTrees <- 1000
setMtry <- TRUE # positive numeric / TRUE to allow automatic editing / FALSE to use default values
method <- "reduce_param"
coeff <- 0.5

# Parallel processing:
numCores <- 8

# Reporting parameters:
createReport <- TRUE
intervals <- c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05))  #c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05)),   # c(seq(0, 1, by=0.1))

# Output parameters:
outputPathIni <- "Y:/AZ/Kate/Output/"

set.seed=101

#--------------------------------------------


# MODELLING #
stage <- "modelling"
# Set parallel processing
cl <- SetParallel(numCores=8)

dcon <- sergeant::drill_connection(host = "mapr-1")

######## 1 Select objects for modelling #############
######## 2 Extract features values from Feature factory #############

datBase <- ORSelectObjectsDrill()

#dat <- ExtractFeaturesValues()
#dat <- as.data.frame(dat)

# load modelling dataset (will be substituted by functions extracting data from feature factory)
#load("Y:/AZ/Collections Scenario/2_PoC_collections_scenario_full_data.RData")
#dat <- datFull[, c(1:186)]
#rm(datFull)

#if (projectStage == "TEST"){
#  sam <- sample(c(1:dim(dat)[1]), size=nrows)
#  dat <- dat[sam, ]
#}

######## 3 Validate and clean data #############
#dat <- CleanValues(dat, e=e) #?


######## 4 Create targets #############
output <- ORCreateModelTargets(dat, e=e)
AssignOutput(output, e)

#or
#dat <- output[["dat"]]
#modelTargets <- output[["modelTargets"]]
#interimModelTargets <- output[["interimModelTargets"]]
#interimModelTargetsClassific <- output[["interimModelTargetsClassific"]]


######## 5 Split modelling population into training and testing sets #############
output <- SplitData(dat, rate=0.1, e=e)
#AssignOutput(output, e)

datFit <- output[["datFit"]]
datHo <- output[["datHo"]]


######## 6 Split training set into sub-populations #############
datList <- DoConditionalSplit(datFit, e=e)


######## 7 Prepare data for modelling (impute missing values, set factors) #############
datMod <- PrepareData(datList=datList, eval=FALSE, e=e)


######## 8 Build models #############
st <- Sys.time()
modelFits <- BuildModel(datMod, modelPath="", e=e)
Sys.time() - st

# Save a workspace
#save.image("Y:/AZ/Kate/Workspaces/Returns_models/Run_Model_built.RData")


# 9 EVALUATION #
# apply the built models to the testing data set datHo
output <- DoEvaluation(datTemp=datHo, modelFits=modelFits, interimModelTargets=interimModelTargets, e=e)
# output list contains following objects: 
# "datList" - datHo splitted into 6 subpopulations
# "evalDat" - list of data for evaluation (datlist with imputed missing values some columns set as factors)
# "predRes" - list with predictions. 
#       For example, predRes[[1]][[1]][[1]] contains predictions for subpopulation #1, main target #1 (OTHER_INCOME), interim target #1 (LABEL_NIL_OTHER_INCOME);
#       predRes[[1]][[1]][[3]] contains predictions for subpopulation #1, main target #1 (OTHER_INCOME), interim target #3 (OTHER_INCOME_POS);
#       predRes[[3]][[4]][[1]] contains predictions for subpopulation #3, main target #4 (PROB_OTHER_INC_LESS_1000), and there is no need in interim targets, 
#         so that the intherim target is the same as the main target here - "PROB_OTHER_INC_LESS_1000"
# "evalRes" - list where predictions were combined with real values, so that they can be compared.
AssignOutput(output, e)

# combine evaluation results (calculate main targets values for main regression targets, e.g. calculate values for OTHER_INCOME main target based on
# prediction for interim targets LABEL_NIL_OTHER_INCOME, LABEL_OTHER_INCOME, OTHER_INCOME_POS, OTHER_INCOME_NEG)
output <- JoinSptittedResults(e=e)
evalMainRes <- output[["evalMainRes"]]
#AssignOutput(output, e)


#save.image("Y:/AZ/Kate/Workspaces/Returns_models/Run_Eval2.RData")


# 10 EVALUATION REPORTS #
# Overall reports (classification targets)
# Prints AUC values and plots showing how accurately objects of each class were classified by the model for each sub-population
PrintOverallChart(target="PROB_RIT_LESS_200")
PrintOverallChart(target="PROB_OTHER_INC_LESS_1000")
PrintOverallChart(target="PROB_NIL_INC_ALLOCN_TO_BNFICIR")

# Overall reports (regression targets)
# Prints preudo R-squared values and plots showing how accurately targets values were predicted (real vs predicted values) for each sub-population
PrintOverallChart(target="OTHER_INCOME")
PrintOverallChart(target="RESIDUAL_INCOME_TAX")

# Detailes reports (examples)
CreateDetailedReport(populationNo=1, mainTarget="OTHER_INCOME", interimTarget="LABEL_NIL_OTHER_INCOME", e=e)
CreateDetailedReport(populationNo=1, mainTarget="OTHER_INCOME", interimTarget="OTHER_INCOME_POS", e=e)

}

