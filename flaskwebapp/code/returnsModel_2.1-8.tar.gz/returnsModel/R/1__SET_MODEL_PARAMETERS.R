
##########------SET MODEL PARAMETERS--------############
# Important model parameters setting
#' Set the model parameters
#' 
#' \code{SetModelParameters} loads or calculates the model parameters for the certain return type.
#'  Parameters values are assigned into \code{e} environment. This function deals with parameters
#'  that might be different for different return types (for example, a return name or a vector of targets).
#'
#' Model parameters are loaded from a file in the \code{data/} folder, which is corresponded to the current 
#'  model and return type.
#'
#' This function is run within the \code{\link{FullModelling}} function, but also can be run separately. 
#' Parameters will be inherited from the top level function's parameters values, or,
#' if function is run separately, parameters should be set (if different from defaults).
#'
#' @inheritParams FullModelling
#' @param log A character string containing the log information. It's empty in the beginning by default. It is complemented during the function run.
#' 
#' @return The function returns the following values:
#'  \itemize{
#'    \item \code{log} - a character string containing the log information. It is complemented during the function run.
#'    \item \code{returnName} - a type of return.
#'    \item \code{model} - a character string defining the model type (\code{"RR"}, \code{"OR"}, etc.)
#'    \item \code{modRetName} - a character string with the current model type and return type (for example, \code{"RR_IR3"}).
#'    \item \code{runDate} - the current date in the "Y-m-d" format.
#'    \item \code{outputPath} - a path to a sub-folder in the output folder (for the current return type and run date).
#'      This folder is created as a result of the function run.
#'    \item \code{targetList} - a vector of returns keypoints, which are considered as model targets.
#'    \item \code{targetTransf} - a list of target keypoints transformations (expressions used for creation of calculated targets).
#'    \item \code{modelTargetsList} - a vector of additional classification targets (purification targets' names in the Outstanding Returns model,
#'      low-risk targets' names in the Right Returns model).
#'    \item \code{DataSelect} - a list of additional classification targets definitions (formulas).
#'    \item \code{participation} - a vector with names of covariates groups participating in the model.
#'    \item \code{covList} - a vector of keypoints that will be considered in the model as income tax keypoints covariates.
#'    \item \code{covTransf} - a list of income covariates keypoints transformations (expressions for creation of calculated income keypoints covariates).
#'    \item \code{classificCov} - a vector of income keypoints that should be considered as classification variables.
#'    \item \code{complemTargets} - a list of Outstanding returns model targets and Purification targets that should be considered together 
#'      in the evaluation report.
#'    \item \code{shortNames} - A vector with short targets names which will be used as Excel worksheets names. 
#'      A vector of the same length as the \code{complemTargets} list.
#'    \item \code{thVal} - A vector with values of the target keypoints which distinguish low-value returns and high-value returns. 
#'      A vector of the same length as the \code{complemTargets} list.
#'    \item \code{estTh} - A list of vectors with threshold values for estimated absolute values of target keypoints.
#'      A list of the same length as the \code{complemTargets} list.
#'    \item \code{prsTh} - A vector with threshold values for estimated probabilities.
#'    \item \code{cutOffCoeff} - a threshold probability of the return being nil. All returns with the predicted probability of being nil
#'      more or equal to \code{cutOffCoeff} value are considered in the output as nil returns (for the Right Returns model only).
#'    \item \code{cl} - the number of clusters for parallel calculations.
#'  }
#'  
#' @examples
#' \dontrun{
#'   SetModelParameters(model="RR", returnName="IR7", e=e)
#' }
#'
#' @export
SetModelParameters <- function(model, returnName=e$returnName, outputPathIni=e$outputPathIni, log = "", e){

  startM <- Sys.time()
  stepName <- "Set model parameters"
  
  # modRetName includes both a model name and a return name
  modRetName <- paste0(model, "_", returnName)
  
  # create output folders for the current return type and run date
  runDate <- format(Sys.Date(), "%Y-%m-%d")
  outputPath <- paste0(outputPathIni, returnName, "\\")
  dir.create(outputPath, showWarnings = FALSE)
  outputPath <- paste0(outputPath, returnName, "_", runDate, "\\")  
  dir.create(outputPath, showWarnings = FALSE) 
  
  # loading model parameters from the file
  data(list=paste0("model_parameters_", if (toupper(returnName) == "IR3ALL") {paste0(toupper(model), "_IR3")} else toupper(modRetName)), envir = e)  
  
  e$log <- LogEdit(e$modRetName, stepName, log, startM)
  
  # output list
  list("model"=model, "modRetName"=modRetName, "runDate"=runDate, "outputPath"=outputPath)
  
}

#--------------------------------------------------------------------------------
#' Register doParallel process
#' 
#' @param modRetname Model name.
#' @param numCores Number of cores to use.
#' @param log Log.
#' @param e Environment.
#' @export
SetParallel <- function(numCores){
  
  # Set a parallel process
  #startM <- Sys.time()
  #stepName <- "Set up a parallel process"
  
  # set parallel processing 
  numCores <- parallel::detectCores()
  #cl <- parallel::makeCluster(numCores-1)
  cl <- parallel::makeCluster(numCores)
  doParallel::registerDoParallel(cl)
  
  #e$log <- LogEdit(modRetName, stepName, log, startM)
  
  #cl
}

#--------------------------------------------------------------------------------

# MakeSparkConnection <- function(modRetName=e$modRetName, log=e$log, e){
#   # Connect to Spark
#   startM <- Sys.time()
#   stepName <- "Connect to Spark"
#   
#   config <- sparklyr::spark_config()
#   config$`sparklyr.shell.driver-memory` <- "10G"  #"8G"
#   config$`sparklyr.shell.executor-memory` <- "6G"  #"4G"
#   config$`spark.yarn.executor.memoryOverhead` <- "2G"
#   sc <- sparklyr::spark_connect(master = "local", config = config)
#   
#   e$log <- LogEdit(modRetName, stepName, log, startM)
#   sc
# }

MakeSparkConnection <- function(){
  # Connect to Spark
  config <- sparklyr::spark_config()
  config$`sparklyr.shell.driver-memory` <- "25G"  #"8G"
  config$`sparklyr.shell.executor-memory` <- "15G"  #"4G"
  config$`spark.yarn.executor.memoryOverhead` <- "5G"
  config$`spark.yarn.driver.memoryOverhead` <- "5G"
  config$`spark.executor.heartbeatInterval` <- "2000s"
  config$`spark.network.timeout` <- "2000s"

  sc <- sparklyr::spark_connect(master = "local", config = config)
  sc
}



