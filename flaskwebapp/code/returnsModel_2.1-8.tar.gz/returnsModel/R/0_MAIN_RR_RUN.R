
##########------RIGHT RETURNS SELECTION (INDIVIDUAL / NON-INDIVIDUAL RUN)--------############
#' Run the Right Returns predictive modelling
#' 
#' \code{RunRightReturns} Creates a predictive model to distinguish NIL (low-value) income tax returns
#'   ("Right Returns") from NOT NIL (high-value) income tax returns. Then the obtained model is applied
#'   to identify entities that are likely to have a NIL (low-value) income tax return for a given tax year.
#' 
#' This function is designed to predict Right Returns either for individuals (IR3, IR3A, IR3NR 
#'  return types) or non-individuals (IR4, IR6, IR7, and IR9 return types). The function runs the Right Returns 
#'  modelling in the loop for all given return types. In the end, it assembles results for all given individual return types 
#'  in one output file (for Individual Select) or creates a separate output file for each given return type (for Non-individual Select).
#' 
#' The type of run (\code{runType="Ind"} or \code{runType="NonInd"}), the scoring year (\code{year}), and the path to an output folder
#'  (\code{outputDir}) should be set by a user before function's execution. All other function's input parameters have pre-set default 
#'  values, but can be altered if necessary. Please, pay attention that there is also a set of parameters which values are slightly different 
#'  for each return type (e.g. targets and covariates list): those parameters default values can be found and changed in files in the \code{data} 
#'  folder (for advanced users only).
#'
#' @param projectStage A character string. If it's equal to \code{"TEST"} then initial datasets are reduced to the 
#'  \code{nrows} size to reduce the calculation time. If it's equal to \code{"PRODUCTION"} then the full datasets are used.
#' @param year A year for Right Returns identification. For example, if \code{year=2016}, the model will predict 
#'  likelihoods of returns being NIL / low-value for the period from \code{01/04/2015} to \code{31/03/2016}.
#' @param runType Either \code{"Ind"} or \code{"NonInd"}. Defines for which list of return types the model will be run 
#'  (\code{indReturnTypes} and \code{nonIndReturnTypes} vector are used for individuals and non-individuals respectively).
#' @param indReturnTypes A vector of return types for the individual select. (Note: the Individual select was canceled in 2016 year,
#'  and it is likely that it will not be run further).
#' @param nonIndReturnTypes A vector of return types for the non-individual select.
#' @param runNo A number of selection. Before 2016, there were two main selection for the Individual Right Returns select
#'  (the 1st usually took place in the middle of March, the 2nd - in the beginning of April). During the 2nd run,
#'  the output is cleaned from Right Returns that already were caught during the 1st run. There is onlty one (1st) run for 
#'  the Non-individual select.
#' @param allIndivTogether Logical. This parameter is considered only for Individual select. If it is equal to \code{TRUE}, 
#'  and both \code{IR3} and \code{IR3A} return types are in the \code{indReturnTypes} vector, the model is built on
#'  the base of data amalgamated for \code{IR3} and \code{IR3A} return types. The output, respectively, is created without 
#'  separation into customers who have a tax agent and customers who have not. If the parameter is equal to
#'  \code{FALSE}, two distinct models are created and the output is presented separately for \code{IR3} and \code{IR3A}
#'  return types. The recommended value is \code{TRUE}, because it helps to increase the data density (data includes less
#'  missing values), leads to more accurate consideration of outstanding returns, and, generally, better reflects
#'  the approaches used by the business.
#' @param covYearsBack A positive integer. It defines how many years we are looking back during covariates creation. E.g.,
#'  if \code{covYearsBack = 3}, all types of covariates will be created to describe the state of an entity three, two,
#'  and one year ago (and, for some covariate types, during the current year too). The minimum recommended value is \code{3},
#'  the maximum recommended value is \code{5}.
#' @param considerRR A logical. If \code{TRUE}, returns identified as Right Returns during previous years are treated as 
#'  NIL returns for the purposes of data selection and cleaning. If \code{FALSE}, those returns are considered as returns
#'  with unknown value. The default value for the Right Returns model is TRUE, for the Outstanding Returns model is FALSE.
#'	Previous years Right Returns are identified by a finalisation code ('UN') and a finalisation user ('SYSRR'). Additionally,
#'	for IR6 and IR9 return types, returns that were finalised with issue of a S068 letter in or before 2013 tax year 
#'	are also considered as Right Returns for corresponded financial years.
#' @param UNbyUserIsNill A logical. If \code{TRUE}, returns that were finalised as UN by IR's staff user (FINALISED_BY 
#'  field's value is a user's identification number) are treated as NIL returns. If \code{FALSE}, those returns are 
#'  considered as returns with unknown value. The default value for the Right Returns model is \code{FALSE},
#'	for the Outstanding Returns model is \code{TRUE}.
#' @param conditionalSplit A logical. If \code{TRUE} a few separate models are built for different parts 
#'  of the model population data set (according to a value of \code{mask} parameter). If \code{FALSE}, one model 
#'  for the whole model population is built.
#' @param mask A list of vectors. The number of vectors in the list defines the number of splitting populations.
#'  Elements of a vector define the set of rules for selection of returns from the general population to sub-populations.
#'  Elements of vectors have to be written using the following templates: 
#' 	\itemize{
#'    \item "Bi" - select returns of customers who has filed the income tax return of a given type \emph{i} years ago 
#'      or this \emph{i}-years-ago return is known to be NIL;
#'    \item "no Bi" - select returns of customers who has not filed the income tax return of a given type \emph{i} years ago 
#'      and this \emph{i}-years-ago return is not known to be NIL;
#'    \item "any return" - select returns of customers who has filed at least one income tax return of a given type (it does not
#'      matter how many years ago it happened);
#'    \item "no returns" - select returns of customers who has not filed any income tax return of a given type.
#'	}
#'  If several rules needed to define a population, they should be listed within a vector separated by a comma.
#'  For example, the default \code{mask} value for the Right Return model \code{mask = list(c("B1", "B2", "B3"), 
#'  c("B1", "B2", "no B3"), c("B1", "no B2"))} means that the general population will be separated into three 
#'  sub-populations according to the following rules:
#'	\enumerate{
#'    \item Population #1: returns where the immediate last 3 years' (B1, B2, B3) income tax return values are known 
#'    \item Population #2: returns where the immediate last 2 years' (B1 and B2) income tax returns values are known, but B3 data is not available
#'    \item Population #3: returns where the immediate last year's (B1 period) income tax return value is known, but B2 data is not available
#'	}
#' @param timestampB0 A date. The current system date by default. The parameter was introduced to support the 
#'  reproducibility of the model's results. It is used in some data extraction scripts to restrict the selection only by
#'  records that were active records on the \code{timestampB0} date. \code{timestampB0} is used:
#'    \itemize{
#'      \item in the scripts for selection of returns for modelling and scoring (in conditions for B0 period)
#'      \item during the creation of several specific B0 covariates that define model targets values (FINALISATION_CODE_B0 and income tax 
#'      keypoints for B0 period)
#'    } 
#' @param ss A positive integer. The Random Forest algorithm's parameter. It is used to define the maximum size of samples to draw from the population
#'  during the model building (those samples are used for individual decision trees building).
#' @param ssMax A positive integer. The maximum size of the sub-populations.
#' @param nrows A number of rows left in the modelling and scoring populations during the test algorithm runs. This parameter is used just if 
#'  \code{projectStage == "TEST"}.
#' @param nTrees A positive integer. The Random Forest algorithm's parameter. It defines the number of random trees to grow.
#' @param mtry A positive integer. The Random Forest algorithm's parameter. Number of covariates randomly sampled for each separate decision tree building.
#'	If left empty, the default Random Forest value is used.
#' @param method A character string. It defines the method of balancing of the model population. Available methods:
#'  \itemize{
#'    \item \code{reduce_param} - balancing the (sub)population via reducing the number of elements from the majority class.
#'      The initial (sub)population is not changed, but samples selected for each decision tree building are balanced.
#'		The \code{sampsize} parameter of the Random Forest is used to provide described balanced sampling.
#'    \item \code{reduce_sampling} - balancing the (sub)population via reducing the number of elements from the majority class.
#'      Balancing is done for the modelling (sub)population itself. The balanced (sub)population is then used for the Random Forest model 
#'		construction.
#'    \item \code{oversampling} - balancing the (sub)population via oversampling the minority class. Balancing is done for the 
#'      model (sub)population itself. Balanced (sub)population is then used for the Random Forest model construction.
#'  }
#'  The default recommended method is \code{reduce_param}.
#' @param coeff A real number from 0 to 1 (default value is 0.5). The proportion of the minority class in the model population
#'  after balancing.
#' @param intervals A vector of cut-off probabilities. Tables in evaluation reports are created according to this parameter.
#' @param outputDir The path to the folder, where the output files (a \code{csv} file with the list of right
#'  returns and \code{ctl} file with technical information) should be placed. \bold{IMPORTANT: please check that the path is correct
#'  and up-to-date! The output files are used by other departments for a further Right Returns processes.
#'  Pay attention that the output directory can vary for different servers.}
#' @param outputPathIni A path name to a folder. This folder is used for saving logs, workspaces, and evaluation reports.
#' @param dropTables A logical. If it is equal to TRUE, all temporary tables created during the modelling will be dropped. 
#' @param createReport A logical. If it is equal to \code{TRUE} the evaluation report is created, otherwise
#'  the report creation step is omitted.
#' @param evalRepAfterScoring A logical. It shows should the evaluation report be created before the scoring step. By default it is
#'  equal to TRUE for the Right Returns model, because the RR evaluation report requires scoring results for calculation of the number
#'  of RR letters.
#'
#' @return If function's run is completed without errors, the following output is created:
#'  \itemize{
#'    \item In the \code{outputDir} folder:
#'    \itemize{
#'      \item The \code{csv} file with the list of the identified Right Returns. The columns order and the format of the data
#'        in each column must satisfy the prescribed requirements. Outputs of individual return types are joined in one file, 
#'        while separate files are created for each non-individual return type.
#'      \item The \code{ctl} file with technical information about the output file(s).
#'    }
#'    \item All other output of the \code{\link{FullModelling}} function.
#'  }
#'
#' If an error occurs during the function run for one return type, it goes to the next return type. 
#' Calculation for each return type is done using the separate \code{e} environment. When loading a saved workspace, all 
#'  variables appear in the global environment. To continue the package functions usage, all variables should be firstly assigned 
#'  to \code{e} environment using the following code \code{e <<- .GlobalEnv}.
#'
#' @examples
#' \dontrun{
#'   # Production run for individuals (the 1st selection):
#'   RunRightReturns(runType="Ind")
#'   # Production run for individuals (the 2nd selection):
#'   RunRightReturns(runType="Ind", runNo=2)
#'   # Production run for non-individuals
#'   RunRightReturns(runType="NonInd")
#'   # Test run (examples, parameters' values may vary)
#'   RunRightReturns(productionStage="TEST", runType="Ind", 
#'    conditionalSplit=FALSE, nTrees=200, dropTables=FALSE)
#'   RunRightReturns(productionStage="TEST", runType="NonInd", 
#'    nonIndReturnTypes=c("IR4", "IR6"), nrows=1000)
#' }
#'
#' @export
RunRightReturns <- function(
                          # Main parameters:  
                            projectStage="TEST", 
                            year=2017, 
  						              runType="Ind", # can be "Ind" or "NonInd"
							              indReturnTypes=c("IR3NR"),
                            #indReturnTypes=c("IR3", "IR3A", "IR3NR"),
                            allIndivTogether=FALSE,
                            nonIndReturnTypes=c("IR7"),
						                #nonIndReturnTypes=c("IR7", "IR9", "IR4", "IR6"),
                            runNo=10,
                            #lowRiskDef = TRUE,
  
                           # Data selection parameters:
                            covYearsBack=3,
                            considerRR = TRUE,
                            UNbyUserIsNill = FALSE,
                            conditionalSplit = FALSE,
                            mask = list(c("B1", "B2", "B3"), c("B1", "B2", "no B3"), c("B1", "no B2")),
                            timestampB0 = format(Sys.Date(), "%d/%m/%Y"),
                            nrows=200,
  
                          # Model parameters:
                            alg="R_RF", # R_RF, RSpark_RF
							              ss=20000,
                            ssMax=300000,
                            nTrees=100,
							              setMtry = FALSE, # positive numeric / TRUE to allow automatic editing / FALSE to use default values
                            method="reduce_param", # reduce_param
                            coeff=0.5,
							              modelPath="", #"C://Users/67eked/Desktop/Models/", #only local paths are supported...
  
                          # Reporting parameters:
                            createReport = FALSE,
                            evalRepAfterScoring = FALSE,
                            intervals=c(seq(0, 1, by=0.1)), #c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05)),
                            
                          # Output parameters:
                            #outputDir="E:\\FTP\\",
                            outputDir="\\\\CMEKMODDEV01\\e\\tmp\\",
                            #outputPathIni="E:\\Models\\Right Returns\\2016_Output\\",
                            outputPathIni=
                              "\\\\CMEKMODDEV01\\E\\Models\\500. Returns Model Class\\Right Returns\\Output\\",
                            dropTables=TRUE,
                            createView=FALSE
  
                          ){  
  
  tryCatch({
    returnDate <- as.numeric(paste0(year, "0331"))
	  yearRun <- format(Sys.Date(), "%Y")
    
  	# Individual or Non-individual select?
  	if (runType == "Ind") {
      if (allIndivTogether == TRUE & 'IR3' %in% indReturnTypes & 'IR3A' %in% indReturnTypes){
        returnTypes <- c(indReturnTypes[-which(indReturnTypes %in% c('IR3', 'IR3A'))], 'IR3All')
      } else {
        returnTypes <- indReturnTypes 
      }
      clientStatusList <- c('A', 'U')
    } else {
      returnTypes <- nonIndReturnTypes
      clientStatusList <- c()
    }
  	
  	# Run the model for each return type
  	for (i in 1:length(returnTypes)){
  	  returnName <- returnTypes[i]
  	  e <- new.env(parent=.GlobalEnv)
  	  e$status <- "INITIALISATION"
      e$clientStatusList <- clientStatusList
      e$returnName <- returnName
      AssignParam(env=e, currEnv=environment(), funct=RunRightReturns)
      
      # Set timestamps
      timestamp <- as.POSIXlt(eval(e$timestampB0), format="%d/%m/%Y")
      timestampB0 <- format(timestamp, "%d/%m/%Y")
      timestamp$year <- timestamp$year-1
      timestamp <- format(timestamp, "%d/%m/%Y")
      
      # Set the lists of arguments for "SelectObjects" function
      selectObjectsArgsMod <- list(yearSQL=e$year-1, yearBase=e$year, timestamp=timestamp, e=e)
      e$selectObjectsArgsMod <- selectObjectsArgsMod
      selectObjectsArgsScor <- list(yearSQL=e$year, yearBase=e$year, timestamp=timestampB0, e=e)
      e$selectObjectsArgsScor <- selectObjectsArgsScor
      
      # FULL MODELLING #
      FullModelling(model="RR", e=e)
      
  	  assign(paste0("irdNumbers", returnName), e$datScorRR, envir=environment())		
  	  rm(e)
  	}
     
  	if (runType == "Ind"){
  	  # For Individual select combine results
  	  irdNumbersNames <- paste0("irdNumbers", returnTypes)
  	  irdNumbersInd <- data.frame()
  	  for (i in returnTypes){
  		  if (exists(paste0("irdNumbers", i)))
          irdNumbersIR3 <- rbind(irdNumbersInd, eval(parse(text = paste0("irdNumbers", i))))
  	  }
  	  returnTypes <- "IR3"
  	}
  	
    # WRITE OUTPUT FILES #
  	for (i in returnTypes){
  	  # Prepare the output data frame with a proper data formatting
  	  if (exists(paste0("irdNumbers", i))){
        if (length(eval(parse(text = paste0("irdNumbers", i)))) > 0){
          #print(paste0("irdNumbers", i))
          irdNumbers <- eval(parse(text = paste0("irdNumbers", i)))
      	  rightReturns <- CreateRRDataFrame(irdNumbers=irdNumbers, returnDate=returnDate)
          	
            # Create the output Right Returns file
            fileName <- paste0(i, '_', year, '.csv')
            filePath <- paste0(outputDir, fileName)
          	
            #generating final output CSV file in the output folder
            write.csv(rightReturns, file = filePath, quote = FALSE, row.names = FALSE)
          	
            #generating control file
            fileSize <- file.info(filePath)$size
          
            textString <- paste0(fileName,
                             " FL/RG/RGBD2750/QUEUED/2014070/2 IRFPACK ",
                             fileSize,
                             " ASCII DATA 62")
          	
      	  controlFileName <- paste0(outputDir, "ftpupload.ctl")	
          WriteControlFile(controlFileName=controlFileName, textString=textString, fileName=fileName, returnName=i)
  	    }
  	  }
  	}
  },
  error = function(c){
    stop(c)
  })
}
  