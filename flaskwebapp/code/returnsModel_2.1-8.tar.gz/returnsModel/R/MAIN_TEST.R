
#rm(list = ls())
#packages <- c("randomForest","foreach","iterators","parallel","doParallel","knitr","stats","rmarkdown","ROCR",
#  "gridExtra","ggplot2")
#pl <- lapply(packages, library, character.only = TRUE, quietly = TRUE, verbose=FALSE)
#fileSources <- list.files("/poc/AZ/Kate/ReturnsModel_package/R", 
#  pattern="*.R$", full.names=TRUE, 
#  ignore.case=TRUE)
#sr <- sapply(fileSources, source, .GlobalEnv)


#---------------------------

#' @export
RunModellingAndScoringTest <- function(model="OR", returnName="IR6", projectStage="TEST", nrows=1000){

  e <<- .GlobalEnv
  e$log <- ""
  set.seed(101)
  #cl <- SetParallel(numCores=8)
  
  e$model <- model
  e$returnName <- returnName
  e$projectStage <- projectStage
  e$nrows <- nrows
  
  #model <- "OR"
  #returnName <- "IR6"
  #projectStage <- "TEST"   #TEST or PRODUCTION 
  
  e$stage <- "modelling"
  e$modRetName <- paste0(model, "_", returnName)
  e$purificationOnly <- FALSE
  
  e$year <- format(Sys.Date(), "%Y")
  e$yearsBack <- if (projectStage == "TEST") {2} else {7}
  e$covYearsBack <- 5
  e$considerRR <- FALSE
  e$UNbyUserIsNill <- TRUE
  e$conditionalSplit <- FALSE
  #e$mask <- list(c("B1", "B2", "B3"), c("B1", "B2", "no B3"), c("B1", "no B2"), c("no B1", "B2"), 
  #  c("no B1", "no B2", "any return"), c("no B1", "no B2", "no returns"))
  e$mask <- list(c("B1", "B2", "B3"), c("B1", "B2", "no B3")) 
  e$timestampB0 <- format(Sys.Date(), "%d/%m/%Y")
  e$clientStatusList <- c('A', 'U')
  
  e$targetFieldsShort <- list("OTHER_INCOME", "RESIDUAL_INCOME_TAX")  # main regression targets
  e$modelTargetsList <- c("PROB_RIT_LESS_200", "PROB_OTHER_INC_LESS_1000", "PROB_NIL_INC_ALLOCN_TO_BNFICIR")  # main classification targets
  e$DataSelect = list(
    function(dat){return(dat$RESIDUAL_INCOME_TAX_B0 <= 200)},                                  
    function(dat){return(dat$OTHER_INCOME_B0 <= 1000)},
    function(dat){return(dat$INC_ALLOCN_TO_BNFICIR_B0 == 0)}
  )
  participation <- c('INCOME TAX RETURN FIELDS')
  
  e$covFieldsShort <- list("INCOME_AFTER_EXPENSES", "OVERSEAS_TAX_CREDITS", "TAXABLE_INCOME", "TOTAL_LOSS_CARRIED_FW", 
    "TOTAL_TAX_CREDITS", "LOSS_CLAIMED", "LOSS_BROUGHT_FORWARD", "SHARE_OF_IMP_CREDITS", 
    "INC_ALLOCN_TO_BNFICIR", "INC_ALLOC_TO_TRUSTEE", "OVERSEAS_INCOME", "ESTATE_TRUST_EXS_CLIM")
  e$classificCovShort <- list()
  e$excludeCov <- c('S068_B0', 'S068_B1', 'S068_B2', 'S068_B3', 'S068_B4', 'S068_B5', 'ESTATE_TRUST_EXS_CLIM_B0', 
    'OVERSEAS_INCOME_B0', 'INC_ALLOC_TO_TRUSTEE_B0', 'INC_ALLOCN_TO_BNFICIR_B0', 'SHARE_OF_IMP_CREDITS_B0', 
    'LOSS_BROUGHT_FORWARD_B0', 'LOSS_CLAIMED_B0', 'TOTAL_TAX_CREDITS_B0', 'TOTAL_LOSS_CARRIED_FW_B0', 
    'TAXABLE_INCOME_B0', 'OVERSEAS_TAX_CREDITS_B0', 'INCOME_AFTER_EXPENSES_B0', 'RESIDUAL_INCOME_TAX_B0', 
    'OTHER_INCOME_B0', 'CLIENT_STATUS_B0', 'FINALISATION_CODE_B0', 'FINALISATION_CODE_B1', 
    'FINALISATION_CODE_B2', 'FINALISATION_CODE_B3', 'FINALISATION_CODE_B4', 'FINALISATION_CODE_B5', 
    'FINALISED_BY_B0', 'FINALISED_BY_B1', 'FINALISED_BY_B2', 'FINALISED_BY_B3', 'FINALISED_BY_B4', 
    'FINALISED_BY_B5')
  
  e$alg <- "R_RF"
  e$ssMax <- 20000
  e$ss <- 20000
  e$nTrees <- 100
  e$setMtry <- TRUE # positive numeric / TRUE to allow automatic editing / FALSE to use default values
  e$method <- "reduce_param"
  e$coeff <- 0.5
  e$intervals <- c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05))  #c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05)),   # c(seq(0, 1, by=0.1))
  #createReport <- TRUE
  #outputPathIni <- "/poc/AZ/Kate/Output/"
  
  e$dcon <- sergeant::drill_connection(host = "mapr-1")
  
  startM <- Sys.time()
  stepName <- "Load data"  
  
  #load("/poc/AZ/Collections Scenario/2_PoC_collections_scenario_full_data.RData")
  #e$dat <- datFull[, c(1:186)]
  #rm(datFull)
  
  #e$datBase <- ORSelectObjectsDrill()
  ORSelectObjectsDrill()
  
  e$dat <- as.data.frame(ExtractFeaturesValues())
  
  #e$dat <- GenerateValues()
  
  #if (e$projectStage == "TEST"){
  #  sam <- sample(c(1:dim(e$dat)[1]), size=e$nrows)
  #  e$dat <- e$dat[sam, ]
  #}
  
  e$log <- LogEdit(e$modRetName, stepName, e$log, startM)
  
  e$dat <- CleanValues(e$dat, e = e) 
  
  output <- ORCreateModelTargets(e$dat, e=e)
  AssignOutput(output, e)
  
  output <- SplitData(e$dat, rate=0.3, e=e)
  e$datFit <- output[["datFit"]]
  e$datHo <- output[["datHo"]]
  
  e$datList <- DoConditionalSplit(e$datFit, e=e)
  
  startM <- Sys.time()
  stepName <- "Prepare data for modelling/scoring"
  
  e$datMod <- PrepareData(datList=e$datList, eval=FALSE, e=e)
  
  e$log <- LogEdit(e$modRetName, stepName, e$log, startM)
  
  st <- Sys.time()
  e$modelFits <- BuildModel(e$datMod, modelPath="", e=e)
  Sys.time() - st
  
  #output <- DoEvaluation(datTemp=datHo, modelFits=modelFits, interimModelTargets=interimModelTargets, e=e)
  #AssignOutput(output, e)
  
  #output <- JoinSptittedResults(e=e)
  #evalMainRes <- output[["evalMainRes"]]
  
  # Scoring
  e$stage <- "scoring"
  
  #load("/poc/AZ/Collections Scenario/4_Poc_collections_scenario_full_data_for_prediction.RData")
  #e$datScor <- datScorFull
  #rm(datScorFull)
  
  e$datScor <- e$datHo[, c(1:76)]
  
  
  #e$datScor <- CleanValues(dat=e$datScor, e=e)
  
  output <- DoEvaluation(datTemp=e$datScor,  modelFits=e$modelFits, interimModelTargets=e$interimModelTargets, e=e)
  AssignOutput(output, e)
  
  output <- JoinSptittedResults(e=e)
  AssignOutput(output, e)
  
  e$outDat

}


####=====================================================


#' @export
RefreshModel <- function(model="OR", returnName="IR6", projectStage="TEST", nrows=1000, modelCatPath="/poc/AZ/Kate/"){
  
  e <<- .GlobalEnv
  e$log <- ""
  set.seed(101)
  cl <- SetParallel(numCores=8)
  
  e$dcon <- sergeant::drill_connection(host = "mapr-1")
  
  e$model <- model
  e$returnName <- returnName
  e$projectStage <- projectStage
  e$nrows <- nrows
  e$modelCatPath <- modelCatPath
  
  #model <- "OR"
  #returnName <- "IR6"
  #projectStage <- "TEST"   #TEST or PRODUCTION 
  
  e$stage <- "modelling"
  e$modRetName <- paste0(model, "_", returnName)
  e$purificationOnly <- FALSE
  
  e$year <- format(Sys.Date(), "%Y")
  e$yearsBack <- if (projectStage == "TEST") {2} else {7}
  e$covYearsBack <- 5
  e$considerRR <- FALSE
  e$UNbyUserIsNill <- TRUE
  e$conditionalSplit <- FALSE
  e$mask <- list(c("B1", "B2", "B3"), c("B1", "B2", "no B3"), c("B1", "no B2"), c("no B1", "B2"), 
    c("no B1", "no B2", "any return"), c("no B1", "no B2", "no returns"))
  e$timestampB0 <- format(Sys.Date(), "%d/%m/%Y")
  e$clientStatusList <- c('A', 'U')
  
  e$targetFieldsShort <- list("OTHER_INCOME", "RESIDUAL_INCOME_TAX")  # main regression targets
  e$modelTargetsList <- c("PROB_RIT_LESS_200", "PROB_OTHER_INC_LESS_1000", "PROB_NIL_INC_ALLOCN_TO_BNFICIR")  # main classification targets
  e$DataSelect = list(
    function(dat){return(dat$RESIDUAL_INCOME_TAX_B0 <= 200)},                                  
    function(dat){return(dat$OTHER_INCOME_B0 <= 1000)},
    function(dat){return(dat$INC_ALLOCN_TO_BNFICIR_B0 == 0)}
  )
  e$participation <- c('INCOME TAX RETURN FIELDS')
  
  e$covFieldsShort <- list("INCOME_AFTER_EXPENSES", "OVERSEAS_TAX_CREDITS", "TAXABLE_INCOME", "TOTAL_LOSS_CARRIED_FW", 
    "TOTAL_TAX_CREDITS", "LOSS_CLAIMED", "LOSS_BROUGHT_FORWARD", "SHARE_OF_IMP_CREDITS", 
    "INC_ALLOCN_TO_BNFICIR", "INC_ALLOC_TO_TRUSTEE", "OVERSEAS_INCOME", "ESTATE_TRUST_EXS_CLIM")
  e$classificCovShort <- list()
  e$excludeCov <- c('S068_B0', 'S068_B1', 'S068_B2', 'S068_B3', 'S068_B4', 'S068_B5', 'ESTATE_TRUST_EXS_CLIM_B0', 
    'OVERSEAS_INCOME_B0', 'INC_ALLOC_TO_TRUSTEE_B0', 'INC_ALLOCN_TO_BNFICIR_B0', 'SHARE_OF_IMP_CREDITS_B0', 
    'LOSS_BROUGHT_FORWARD_B0', 'LOSS_CLAIMED_B0', 'TOTAL_TAX_CREDITS_B0', 'TOTAL_LOSS_CARRIED_FW_B0', 
    'TAXABLE_INCOME_B0', 'OVERSEAS_TAX_CREDITS_B0', 'INCOME_AFTER_EXPENSES_B0', 'RESIDUAL_INCOME_TAX_B0', 
    'OTHER_INCOME_B0', 'CLIENT_STATUS_B0', 'FINALISATION_CODE_B0', 'FINALISATION_CODE_B1', 
    'FINALISATION_CODE_B2', 'FINALISATION_CODE_B3', 'FINALISATION_CODE_B4', 'FINALISATION_CODE_B5', 
    'FINALISED_BY_B0', 'FINALISED_BY_B1', 'FINALISED_BY_B2', 'FINALISED_BY_B3', 'FINALISED_BY_B4', 
    'FINALISED_BY_B5')
  
  e$alg <- "R_RF"
  e$ssMax <- 20000
  e$ss <- 20000
  e$nTrees <- 100
  e$setMtry <- TRUE # positive numeric / TRUE to allow automatic editing / FALSE to use default values
  e$method <- "reduce_param"
  e$coeff <- 0.5
  e$intervals <- c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05))  #c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05)),   # c(seq(0, 1, by=0.1))
  #createReport <- TRUE
  #outputPathIni <- "/poc/AZ/Kate/Output/"
  
  
  startM <- Sys.time()
  stepName <- "Load data"  
  
  #load("/poc/AZ/Collections Scenario/2_PoC_collections_scenario_full_data.RData")
  #e$dat <- datFull[, c(1:186)]
  #rm(datFull)
  
  ORSelectObjectsDrill()
  e$dat <- as.data.frame(ExtractFeaturesValues())
  
  e$dat <- CleanValues(e$dat, e = e) 
  
  output <- ORCreateModelTargets(e$dat, e=e)
  AssignOutput(output, e)
  
  output <- SplitData(e$dat, e=e)
  e$datFit <- output[["datFit"]]
  e$datHo <- output[["datHo"]]
  
  e$datList <- DoConditionalSplit(e$datFit, e=e)
  
  startM <- Sys.time()
  stepName <- "Prepare data for modelling/scoring"
  
  e$datMod <- PrepareData(datList=e$datList, eval=FALSE, e=e)
  
  e$log <- LogEdit(e$modRetName, stepName, e$log, startM)
  
  st <- Sys.time()
  e$modelFits <- BuildModel(e$datMod, modelPath="", e=e)
  Sys.time() - st
  
  #output <- DoEvaluation(datTemp=datHo, modelFits=modelFits, interimModelTargets=interimModelTargets, e=e)
  #AssignOutput(output, e)
  
  #output <- JoinSptittedResults(e=e)
  #evalMainRes <- output[["evalMainRes"]]
  
  output <- list("modelFits"=e$modelFits, "clientStatusList"=e$clientStatusList, "covFieldsShort"=e$covFieldsShort, "targetFieldsShort"=e$targetFieldsShort, 
    "classificCovShort"=e$classificCovShort, "modRetName"=e$modRetName, "covYearsBack"=e$covYearsBack, "considerRR"=e$considerRR, 
    "UNbyUserIsNill"=e$UNbyUserIsNill, "interimModelTargets"=e$interimModelTargets, "dat"=e$dat, "modelTargets"=e$modelTargets, 
    "modelTargetsList"=e$modelTargetsList, "conditionalSplit"=e$conditionalSplit, "mask"=e$mask, "participation"=e$participation, 
    "excludeCov"=e$excludeCov, "alg"=e$alg, "model"=e$model)
  
  output
  
  #imageName <- paste0(e$modelCatPath, e$modRetName,"_",  e$runDate, "_", e$stage,".RData") 
  
  #save(list=c("modelFits", 
  # "clientStatusList", "covFieldsShort", "targetFieldsShort", "classificCovShort", "modRetName", "covYearsBack", "considerRR", "UNbyUserIsNill",
  # "interimModelTargets", "dat", "modelTargets", "modelTargetsList", "conditionalSplit", "mask", "participation", "excludeCov", "alg",
  # "model"), file=imageName, envir=e)
  
  #imageName
  
  #modelFits
 
}

#-------------------

#rm(list=ls())

param <- function(){
  
  model="OR"
  returnName="IR6"
  runDate="2017-11-28"
  projectStage="TEST"
  nrows=1000
  modelCatPath="/poc/AZ/Kate/"
  irdNumbersForScoring=c()
  
}

#------------------

#' @export
DoScoring <- function(model="OR", returnName="IR6", modelRunDate="2017-11-28", projectStage="TEST", nrows=1000, irdNumbersForScoring="", e){
  
  # Scoring
  #e <<- .GlobalEnv
  e$log <- ""
  e$stage <- "scoring"
  
  e$model <- model
  e$returnName <- returnName
  e$runDate <- modelRunDate
  e$projectStage <- projectStage
  e$nrows <- nrows
  e$irdNumbersForScoring <- irdNumbersForScoring
  
  e$modRetName <- paste0(e$model, "_", e$returnName)
  
  #e$modelPath <- paste0(e$modelCatPath, e$modRetName,"_",  e$runDate, "_modelling.RData")
  #load(e$modelPath, envir=e)
  
  cl <- SetParallel(numCores=8)
  e$dcon <- sergeant::drill_connection(host = "mapr-1")
  
  #load("/poc/AZ/Collections Scenario/4_Poc_collections_scenario_full_data_for_prediction.RData", envir=e)
  #e$datScor <- e$datScorFull
  #rm(datScorFull, envir=e)
  
  ORSelectObjectsDrillScoring()
  e$datScor <- as.data.frame(ExtractFeaturesValues())
  
  e$datScor <- CleanValues(dat=e$datScor, e=e)
  
  output <- DoEvaluation(datTemp=e$datScor,  modelFits=e$modelFits, interimModelTargets=e$interimModelTargets, ssMax=0, e=e)
  AssignOutput(output, e)
  
  output <- JoinSptittedResults(modelId=1, runId=1, e=e)
  AssignOutput(output, e)
  
  e$outDat
  
}