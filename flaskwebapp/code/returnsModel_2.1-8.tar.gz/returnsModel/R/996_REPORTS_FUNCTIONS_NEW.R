#' @export
CreateOverallClassificChart <- function(i, j, k=1, target, evalRes=e$evalRes, evalMainRes=e$evalMainRes,
                                        modelTargetsList=e$modelTargetsList, targetFieldsShort=e$targetFieldsShort){
  
  if (target %in% modelTargetsList){
  
    evalDataSet <- evalRes[[i]][[j]][[k]]
    predVal <- evalDataSet[, which(names(evalDataSet) %in% c("TRUE", "POS", "NIL"))]
    realVal <- evalDataSet[, 1]
    
    names(evalDataSet)[1] <- "real_val"
    evalDataSet <- evalDataSet[!is.na(evalDataSet$real_val), ]
    evalDataSet$real_val_num <- 0
    evalDataSet[evalDataSet$real_val %in% c("NIL", "POS", "TRUE"), "real_val_num"] <- 1
    
    labels <- names(evalDataSet)
    n1 <- which(labels %in% c('POS', 'NIL', 'TRUE'))
    n2 <- CalcIndex(n1 - 1) + 1
    
    # prepare data from plot3
    df <- evalDataSet[, c(1, n1)]
    names(df) <- c("realVal", "predVal")
    
    if (levels(df$realVal)[1] %in% c("TRUE", "NIL", "POS")){
      col <- c("#328298", "#A68435")
    } else {
      col <- c("#A68435", "#328298") 
    }
    
    if (dim(evalDataSet)[1] < 1000) {
      alpha1 <- 0.3
      alpha2 <- 0.5
    } else {
      alpha1 <- 0.02
      alpha2 <- 0.1
    }
    
    cutOff <- 0.5
    
    lvls <- levels(realVal)
    ind2 <- which(levels(realVal) %in% c("POS", "NIL", "TRUE"))
    ind1 <- CalcIndex(ind2)
    ord <- c(lvls[ind1], lvls[ind2])
    
    test <- ROCR::prediction(predictions=predVal, labels=realVal, label.ordering = ord)
    rocAuc <- ROCR::performance(test, "auc")
    auc <- paste0("AUC=", round(rocAuc@y.values[[1]], digits=2))
    
    assign(paste0("plot", i),
           ggplot(data=df, aes(x=predVal, y=realVal)) +  
             geom_jitter(aes(color=realVal), alpha=0.4, size=0.7) +
             geom_vline(xintercept=cutOff, color='#A64535', alpha=0.5) + 
             labs(title=paste0('Pop.#', i, ' (', auc,')')) + 
             PlotsTheme() + 
             scale_colour_manual(values = col) +
             xlim(0, 1), envir=.GlobalEnv)
    
    #assign(paste0("plotText", i),
    #ggplot() +
    #  #geom_polygon(aes(x=X, y=Y), data=data.frame(X=c(0, 1, 1, 0),Y=c(0, 0, 0, 0)), fill='white', inherit.aes=FALSE) +
    #  annotate('text', x=0.2, y=0.9, label=auc, size=3) +
    #  xlim(0, 1) +
    #  ylim(0, 1) +
    #  PlotsTheme3(), envir=.GlobalEnv)
  
  }
  
  if (target %in% targetFieldsShort){
    
    evalDataSet <- evalMainRes[[i]][[j]]
    names(evalDataSet) <- c("real_value", "pred_value")
    predVal <- evalDataSet[, 2]
    realVal <- evalDataSet[, 1]
    
    # Predictive performance plot
    qMinReal <- quantile(realVal, 0.01)
    qMaxReal <- quantile(realVal, 0.99)
    qMinPred <- quantile(predVal, 0.01)
    qMaxPred <- quantile(predVal, 0.99)
    qMin <- min(qMinReal, qMinPred)
    qMax <- max(qMaxReal, qMaxPred)
    
    mse <- mean((realVal - predVal)^2)
    rSq <- round(1 - mse / var(realVal), 2)
    rSq <- paste0("Rsq=", rSq)
    
    assign(paste0("plot", i),
    ggplot(evalDataSet, aes(x=real_value, y=pred_value)) +
      geom_point(col='#328298', alpha=0.3, size=0.7) +
      geom_abline(intersect=0, slope=1, col='#A64535', alpha=0.7) +
      PlotsTheme() +
      labs(title=paste0('Pop.#', i, ' (', rSq,')')) + 
      coord_cartesian(xlim=c(min(0, qMin), max(0, qMax)), ylim=c(min(0, qMin), max(0, qMax))), envir=.GlobalEnv)
    
    
  }
}


#--------------------------------

#' @export
PrintOverallChart <- function(target, modelTargets=e$modelTargets, evalRes=e$evalRes, evalMainRes=e$evalMainRes,
                              modelTargetsList=e$modelTargetsList, 
                              targetFieldsShort=e$targetFieldsShort){
  options(warn=-1)
  
  j <- which(modelTargets == target)
  
  #target <- modelTargets[j]
  #options(repr.plot.width = 11, repr.plot.height = 0.6)
  #plot <- ggplot() + annotate('text', x=0.5, y=0, label=target, size=4) + PlotsTheme3()
  #print(plot)
  print(target)
  
  n <- length(evalRes)
  
  for (i in c(1:n)){CreateOverallClassificChart(i, j, target=target, evalRes=evalRes, evalMainRes=evalMainRes, modelTargetsList=modelTargetsList, 
                                                targetFieldsShort=targetFieldsShort)}
  options(repr.plot.width = 11, repr.plot.height = 1.8)
  
  if (n == 6){
    gridExtra::grid.arrange(plot1, plot2, plot3, plot4, plot5, plot6, ncol=6)
  }
  if (n == 1){
    gridExtra::grid.arrange(plot1, ncol=6)
  }
  
  options(warn=0)
}

#----------------------------------


CreateDetailedReport <- 
  #function(dat, modelFits, i=0, j=0, k=0, evalDataSet, filenameMod, outputPath, rfConfMatrix=FALSE, covarImpPlot, intTargets, intervals, covarImp, alg, e){
  function(populationNo=1, mainTarget="OTHER_INCOME", interimTarget="OTHER_INCOME_POS", dat=e$dat, modelFits=e$modelFits, evalRes=e$evalRes, 
           intervals=e$intervals, modelTargets=e$modelTargets, interimModelTargets=e$interimModelTargets, e){
  
  i <- populationNo
  j <- which(modelTargets == mainTarget)
  intTargets <- ChoseInterimModels(modelTarget=mainTarget, interimModelTargets=interimModelTargets, numORtext="text")
  k <- which(intTargets == interimTarget)
    
  evalDataSet <- evalRes[[i]][[j]][[k]]  
  #dir.create(outputPath, showWarnings=FALSE)
  #filePath <- paste0(outputPath, filenameMod, ".rmd")
  #file.create(filePath)
  #sink(file=filePath, type = c("output"))
  
  #e$reportDataSet[[filenameMod]] <- evalDataSet
  
  interimTarget <- interimModelTargets[k]
  print(interimTarget)
  
  #print("Variable importance plot")
  randomForest::varImpPlot(modelFits[[i]][[j]][[k]], n.var=15, cex=0.5, main=" ")

  if (is.factor(dat[, interimTarget])){
     
    predVal <- evalDataSet[, which(names(evalDataSet) %in% c("TRUE", "POS", "NIL"))]
    realVal <- evalDataSet[, 1]  
    
    CalcPerformMeasures(alg, modelFits[[i]][[j]][[k]], testRes=evalDataSet, trainRes=data.frame(), trainPerf=FALSE)
    
    # RF model confusion matrix
    #print("Confusion matrix (cutOff=0.5)")
    #options(repr.plot.width = 7, repr.plot.height = 4)
    cm <- modelFits[[i]][[j]][[k]]$confusion
    print(cm)
    
    print("Classificaton performance")
    tab <- CreateClassifPerformTable(predVal=predVal, realVal=realVal, intervals=intervals)
    print(tab)
   

    #----------------------------------
    # prepare data for plot1 and plot2
    names(evalDataSet)[1] <- "real_val"
    evalDataSet <- evalDataSet[!is.na(evalDataSet$real_val), ]
    evalDataSet$real_val_num <- 0
    evalDataSet[evalDataSet$real_val %in% c("NIL", "POS", "TRUE"), "real_val_num"] <- 1
    
    labels <- names(evalDataSet)
    n1 <- which(labels %in% c('POS', 'NIL', 'TRUE'))
    n2 <- CalcIndex(n1 - 1) + 1
    
    # prepare data from plot3
    df <- evalDataSet[, c(1, n1)]
    names(df) <- c("realVal", "predVal")
    
    if (levels(df$realVal)[1] %in% c("TRUE", "NIL", "POS")){
      col <- c("#328298", "#A68435")
    } else {
      col <- c("#A68435", "#328298")
    }
    
    if (dim(evalDataSet)[1] < 1000) {
      alpha1 <- 0.3
      alpha2 <- 0.5
    } else {
      alpha1 <- 0.02
      alpha2 <- 0.1
    }
    
    num <- which(names(evalDataSet) == labels[n1])
    
    plot1 <- 
      ggplot(evalDataSet, aes(x=evalDataSet[, num], y=real_val_num)) +
      geom_point(alpha = alpha1, size=1.5, col = 'blue') +
      geom_abline(intercept=0, slope=1, color = '#A64535', size = 0.7) +
      geom_smooth(size = 1, col = '#328298') +
      PlotsTheme() + 
      ggtitle('Probability estimate accuracy') +
      xlab('CutOff') + ylab('Proportion') +
      coord_cartesian(xlim = c(-0.01, 1.01), ylim= c(-0.01, 1.01))
    
    cutOff <- 0.5
    tab <- as.data.frame(tab)
    intervals <- eval(intervals)
    tab$cutOff <- intervals[2:length(intervals)]
    
    f1 <- paste0("Cumulative % of ", labels[n2]," values")
    f2 <- paste0("Cumulative % of ", labels[n1]," values")
    num1 <- which(names(tab) == f1)
    num2 <- which(names(tab) == f2)
    
    plot2 <-
      ggplot(tab) +
      geom_area(aes(x=cutOff, y=tab[, num1]), fill='#FFE4A4', alpha=0.5, col='white') +
      geom_area(aes(x=cutOff, y=tab[, num2]), fill='#328298', alpha=0.5, col='white') +
      PlotsTheme() +
      ggtitle('Cumulative percent') +
      xlab('CutOff') + ylab('Part') 
    
    plot3 <- 
      ggplot(data=df, aes(x=predVal, y=realVal)) +  
      geom_jitter(aes(color=realVal), alpha=alpha2) + 
      geom_vline(xintercept=cutOff, color='#A64535', alpha=0.6) + 
      labs(title=paste0('Threshold at ', cutOff)) + 
      PlotsTheme() + 
      scale_colour_manual(values = col)
    
    options(repr.plot.width = 11, repr.plot.height = 3.5)
    gridExtra::grid.arrange(plot3, plot2, plot1, ncol=3)
    
    
    
    # ROC curves and performance rates
    predVal <- evalDataSet[, which(names(evalDataSet) %in% c("TRUE", "POS", "NIL"))]
    realVal <- evalDataSet[, 1]  
    tab2 <- CreateClassifPerformTable2(predVal=predVal, realVal=realVal, intervals=intervals)
    print("Classification performance measures") 
    print(tab2)
    
    lvls <- levels(realVal)
    ind2 <- which(levels(realVal) %in% c("POS", "NIL", "TRUE"))
    ind1 <- CalcIndex(ind2)
    ord <- c(lvls[ind1], lvls[ind2])
    
    # create the object of the "prediction" type. Make sure that the order of target labels is correct
    test <- ROCR::prediction(predictions=predVal, labels=realVal, label.ordering = ord)
    
    # ROC curve (TP vs FP rates)
    v <- c(seq(0, 0.3, 0.1), 0.5, 0.7, seq(0.8, 1, by=0.1))
    rocPerf <- ROCR::performance(test, "tpr", "fpr")
    rocAuc <- ROCR::performance(test, "auc")
    auc <- paste0("AUC = ", round(rocAuc@y.values[[1]], digits=2))
    print(auc)
    
  }
  
  
  if (is.numeric(dat[, interimTarget])){
    
    evalDataSet <- as.data.frame(evalDataSet)
    names(evalDataSet) <- c("real_value", "pred_value")
    evalDataSet$res_val <- evalDataSet$pred_value - evalDataSet$real_value
    evalDataSet <- evalDataSet[!is.na(evalDataSet$real_value), ]
    
    # Predictive performance table
    predVal <- evalDataSet[, "pred_value"]
    realVal <- evalDataSet[, "real_value"] 
    resVal <- evalDataSet[, "res_val"]
    
    print("Predictive performance")
    CalcPerformMeasures(alg, modelFits[[i]][[j]][[k]], testRes=evalDataSet, trainRes=data.frame(), trainPerf=FALSE)
    
    tmp <- format(round(cbind(summary(realVal)[1:6], summary(predVal), summary(resVal)[1:6]),0), big.mark=",")
    rownames(tmp) <- names(summary(predVal))
    tab <- matrix(tmp, nrow=dim(tmp)[1], ncol=3, dimnames=list(rownames(tmp), c("Real values", "Estimated values", "Residuals")))
    print(tab)
    
    # Predictive performance plot
    qMinReal <- quantile(realVal, 0.01)
    qMaxReal <- quantile(realVal, 0.99)
    qMinPred <- quantile(predVal, 0.01)
    qMaxPred <- quantile(predVal, 0.99)
    qMin <- min(qMinReal, qMinPred)
    qMax <- max(qMaxReal, qMaxPred)
    
    qMinResid <- quantile(resVal, 0.01)
    qMaxResid <- quantile(resVal, 0.99)
    qResid <- max(abs(qMinResid), abs(qMaxResid))
    
    
      plot1 <- 
        ggplot(evalDataSet) +
        geom_density(aes(x=real_value), fill='#FFD4A4', col='white', alpha=1) +
        geom_density(aes(x=pred_value), fill='#328298', col='white', alpha=0.4) +
        PlotsTheme() +
        xlim(qMin, qMax) +
        ggtitle('Densities of real and predicted values ') +
        xlab('')
        
        plot2 <- 
        ggplot(evalDataSet, aes(x=real_value, y=pred_value)) +
        geom_point(col='#328298', alpha=0.3, size=2.5) +
        geom_abline(intersect=0, slope=1, col='#A64535', alpha=0.7, size=0.7) +
        PlotsTheme() +
        #xlim(qMin, qMax) +
        #ylim(qMin, qMax) +
        ggtitle('Predicted vs real values') +
        coord_cartesian(xlim=c(min(0, qMin), max(0, qMax)), ylim=c(min(0, qMin), max(0, qMax)))
        
        plot3 <- 
        ggplot(evalDataSet, aes(x=res_val)) +
        geom_histogram(fill='#99D8EA', col='white', alpha=1) +
        PlotsTheme() +
        #coord_cartesian(xlim=c(qMin, qMax)) +
        ggtitle('Histogram of residuals') +
        xlim(-1 * qResid, qResid)
        
        gridExtra::grid.arrange(plot1, plot2, plot3, ncol=2, nrow=2)

    
  }
  
}

