##########------OUTSTANDING RETURNS VALUE AND OUTSTANDING RETURNS PURIFICATION MODEL--------############
#' Run the Outstanding returns value model and (or) the Returns Purification model
#' 
#' \code{RunOutstandingReturns} function is designed for evaluation of values of currently outstanding income tax returns
#'  (Outstanding Returns value model) and for selection of outstanding returns 
#'  with low value (Returns Purification model). Using the \code{RunOutstandingReturns} function,
#'  these models can be run together or separately.
#' 
#' The function has a big number of parameters. The most of them have a preset default value, which will work good in the case
#'  of standard model recalculation. However, it is important to check the following parameters values before each model run:
#' \enumerate{
#'  \item \code{returnName} - set it equal to one of return types ("IR3", "IR3A" "IR3NR", "IR4", "IR6", or "IR7"). To
#'   run the amalgamated IR3 and IR3A model, set the \code{returnName} parameter is equal to "IR3ALL".
#'  \item \code{outputPathIni} -  a full path to a folder, in which the modelling results will be saved (a log file, workspaces, 
#'    and evaluation reports).
#' }
#' Other parameters may be changed by experienced users to adjust the rules for targets and covariates values creation (e.g. \code{covYearsBack},
#'  \code{considerRR}, etc.) or set a different level of the model complexity (e.g. \code{nTrees}, \code{mtry}, etc.). See \strong{Arguments} 
#'  sections for more details. Also remember that parameters which are responsible for targets and covariates definitions in different models and 
#'  for different return types can be set in separate files in the \emph{data} folder.
#'
#' @param returnName A character string. A type of return: IR3, IR3A, IR3ALL (amalgamated model for IR3 and IR3A), IR3NR, IR4, IR6, IR7, IR9.
#' @param projectStage A character string. If it is equal to \code{"TEST"} then initial datasets are reduced to the 
#'  \code{nrows} size to reduce the calculation time. If it's equal to \code{"PRODUCTION"} then the full datasets are used. Also,
#'  in some cases at the TEST project stage, tables instead of global temporary tables are created in the database.
#' @param purificationOnly A logical. If \code{TRUE}, only purification targets are created (\code{modelTargetsList} and \code{DataSelect}
#'  parameters in a corresponded file with model parameters must not be empty in this case). If \code{FALSE} outstanding returns value
#'  targets are created along with the purification targets (if any).
#' @param year A year. Defines which year will be considered as the most recent tax year during the modelling. The current year by default.
#' @param covYearsBack A positive integer. It defines how many years we are looking back during covariates creation. E.g.,
#'  if \code{covYearsBack = 3}, all types of covariates will be created to describe the state of an entity three, two,
#'  and one year ago (and, for some covariate types, during the current year too). The minimum recommended value is \code{3},
#'  the maximum recommended value is \code{5}.
#' @param considerRR A logical. If \code{TRUE}, returns identified as Right Returns during previous years are treated as 
#'  NIL returns for the purposes of data selection and cleaning. If \code{FALSE}, those returns are considered as returns
#'  with unknown value. The default value for the Right Returns model is TRUE, for the Outstanding Returns model is FALSE.
#'	Previous years Right Returns are identified by a finalisation code ('UN') and a finalisation user ('SYSRR'). Additionally,
#'	for IR6 and IR9 return types, returns that were finalised with issue of a S068 letter in or before 2013 tax year 
#'	are also considered as Right Returns for corresponded financial years.
#' @param UNbyUserIsNill A logical. If \code{TRUE}, returns that were finalised as UN by IR's staff user (FINALISED_BY 
#'  field's value is a user's identification number) are treated as NIL returns. If \code{FALSE}, those returns are 
#'  considered as returns with unknown value. The default value for the Right Returns model is \code{FALSE},
#'	for the Outstanding Returns model is \code{TRUE}.
#' @param conditionalSplit A logical. If \code{TRUE} a few separate models are built for different parts 
#'  of the model population data set (according to a value of \code{mask} parameter). If \code{FALSE}, one model 
#'  for the whole model population is built.
#' @param mask A list of vectors. The number of vectors in the list defines the number of splitting populations.
#'  Elements of a vector define the set of rules for selection of returns from the general population to sub-populations.
#'  Elements of vectors have to be written using the following templates: 
#' 	\itemize{
#'    \item "Bi" - select returns of customers who has filed the income tax return of a given type \emph{i} years ago 
#'      or this \emph{i}-years-ago return is known to be NIL;
#'    \item "no Bi" - select returns of customers who has not filed the income tax return of a given type \emph{i} years ago 
#'      and this \emph{i}-years-ago return is not known to be NIL;
#'    \item "any return" - select returns of customers who has filed at least one income tax return of a given type (it does not
#'      matter how many years ago it happened);
#'    \item "no returns" - select returns of customers who has not filed any income tax return of a given type.
#'	}
#'  If several rules needed to define a population, they should be listed within a vector separated by a comma.
#'  For example, the default \code{mask} value for the Right Return model \code{mask = list(c("B1", "B2", "B3"), 
#'  c("B1", "B2", "no B3"), c("B1", "no B2"))} means that the general population will be separated into three 
#'  sub-populations according to the following rules:
#'	\enumerate{
#'    \item Population #1: returns where the immediate last 3 years' (B1, B2, B3) income tax return values are known 
#'    \item Population #2: returns where the immediate last 2 years' (B1 and B2) income tax returns values are known, but B3 data is not available
#'    \item Population #3: returns where the immediate last year's (B1 period) income tax return value is known, but B2 data is not available
#'	}
#' @param timestampB0 A date. The current system date by default. The parameter was introduced to support the 
#'  reproducibility of the model's results. It is used in some data extraction scripts to restrict the selection only by
#'  records that were active records on the \code{timestampB0} date. \code{timestampB0} is used:
#'    \itemize{
#'      \item in the scripts for selection of returns for modelling and scoring (in conditions for B0 period)
#'      \item during the creation of several specific B0 covariates that define model targets values (FINALISATION_CODE_B0 and income tax 
#'      keypoints for B0 period)
#'    } 
#' @param clientStatusList A vector of clients statuses. Only clients with those statuses participate in the modelling and selected for scoring.
#' @param ss A positive integer. The Random Forest algorithm's parameter. It is used to define the maximum size of samples to draw from the population
#'  during the model building (those samples are used for individual decision trees building).
#' @param ssMax A positive integer. The maximum size of the sub-populations.
#' @param nrows A number of rows left in the modelling and scoring populations during the test algorithm runs. This parameter is used just if 
#'  \code{projectStage == "TEST"}.
#' @param nTrees A positive integer. The Random Forest algorithm's parameter. It defines the number of random trees to grow.
#' @param mtry A positive integer. The Random Forest algorithm's parameter. Number of covariates randomly sampled for each separate decision tree building.
#'	If left empty, the default Random Forest value is used.
#' @param method A character string. It defines the method of balancing of the model population. Available methods:
#'  \itemize{
#'    \item \code{reduce_param} - balancing the (sub)population via reducing the number of elements from the majority class.
#'      The initial (sub)population is not changed, but samples selected for each decision tree building are balanced.
#'		The \code{sampsize} parameter of the Random Forest is used to provide described balanced sampling.
#'    \item \code{reduce_sampling} - balancing the (sub)population via reducing the number of elements from the majority class.
#'      Balancing is done for the modelling (sub)population itself. The balanced (sub)population is then used for the Random Forest model 
#'		construction.
#'    \item \code{oversampling} - balancing the (sub)population via oversampling the minority class. Balancing is done for the 
#'      model (sub)population itself. Balanced (sub)population is then used for the Random Forest model construction.
#'  }
#'  The default recommended method is \code{reduce_param}.
#' @param coeff A real number from 0 to 1 (default value is 0.5). The proportion of the minority class in the model population
#'  after balancing.
#' @param createExcelEvalRep A logical. If \code{TRUE}, the evaluation report in \emph{xlsm} format is created. It contains 
#'  informaton about the model performance at different cut-off levels of the model targets.
#' @param intervals A vector of cut-off probabilities. Tables in evaluation reports are created according to this parameter.
#' @param outputPathIni A path name to a folder. This folder is used for saving logs, workspaces, and evaluation reports.
#' @param dropTables A logical. If it is equal to TRUE, all temporary tables created during the modelling will be dropped. 
#' @param createView A logical. If it is eqaul to \code{TRUE}, an output DB view is automatically created. Otherwise, this step
#'  is omitted.
#' @param createReport A logical. If it is equal to \code{TRUE} the evaluation report is created, otherwise
#'  the report creation step is omitted.
#' @param yearsBack An integer. It shows how old can a return be to be selected for modeling. For instance, if \code{yearsBack=7} 
#'  and the most recent return period date is '31/03/2016', the earlies returns participating in the modelling will be with the return 
#'  period date is equal to '31/03/2009' (7 years back).
#' @param evalRepAfterScoring A logical. It shows should the evaluation report be created before the scoring step. By default it is
#'  equal to TRUE for the Right Returns model, because the RR evaluation report requires scoring results for calculation of the number
#'  of RR letters.
#'
#' @return If function's run is completed without errors, it's output consists of the output of the \code{\link{FullModelling}} function.
#'  If an error occurs during the function run, the function stops, writes an error in the log, updates the LOG table with the status 
#'  is equal to \code{"ERROR"}, stops all connections and returns all environment options to the initial settings.
#'
#' When loading a saved workspace, all variables appear in the global environment. Thus, to continue the package 
#'  functions usage, all variables should be firstly assigned to \code{e} environment using the following code \code{e <<- .GlobalEnv}.
#'
#' @examples
#' \dontrun{
#'    # in the majority of cases only two parameters should be specified:
#'    RunOutstandingReturns(returnName="IR3", 
#'      outputPath="C:/Users/67eked/Documents/R")
#'    # some other parameters can be setted if necessary:
#'    RunOutstandingReturns(returnName="IR7",
#'      outputPath="C:/Users/67eked/Documents/R", ss=25000, yearsBack=5, 
#'      runReport=FALSE)}
#' @export
RunOutstandingReturns <- function(
                  # Main parameters:  
                    returnName = "IR6", 
                    projectStage = "TEST",   #TEST or PRODUCTION 
                    purificationOnly = FALSE,
  
                  # Data selection parameters:
                    year = format(Sys.Date(), "%Y"),
                    yearsBack = if (projectStage == "TEST") {2} else {7},
                    covYearsBack = 5,
                    considerRR = FALSE,
                    UNbyUserIsNill = TRUE,
                    conditionalSplit = TRUE,
                    #mask = list(c("B1", "B2", "B3"), c("no B1", "B2"), c("no B1", "no B2", "any return")),
                    mask = list(c("B1", "B2", "B3"), c("B1", "B2", "no B3"), c("B1", "no B2"), c("no B1", "B2"), c("no B1", "no B2", "any return"), c("no B1", "no B2", "no returns")),
                    timestampB0 = format(Sys.Date(), "%d/%m/%Y"), #format(Sys.Date(), "%d/%m/%Y"), #format(Sys.Date() - 218, "%d/%m/%Y"), 
                    clientStatusList = c('A', 'U'),
                    nrows = 500,
                  
                  # Model parameters:
                    alg = "R_RF", # "RSpark_RF", "R_RF"  
                    ssMax = 20000,
                    ss = 20000,
                    nTrees = 10,
                    setMtry = TRUE, # positive numeric / TRUE to allow automatic editing / FALSE to use default values
                    method = "reduce_param", #"reduce_param"
                    coeff = 0.5,
                    modelPath = "", #"C://Users/67eked/Desktop/Models/", #only local paths are supported...
                   
                  # Parallel processing:
                    numCores = 20,
                   
                  # Reporting parameters:
                    createReport = TRUE,
                    evalRepAfterScoring = FALSE,
                    createExcelEvalRep = TRUE,
                    intervals = c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05)),   #c(seq(0, 0.4, by=0.1), seq(0.45, 1, by=0.05)),   # c(seq(0, 1, by=0.1))
  
                  # Output parameters:
                    outputPathIni=
                      "\\\\CMEKMODDEV01\\E\\Models\\500. Returns Model Class\\Outstanding Returns\\Output\\", 
                    createView = TRUE,
                    dropTables = FALSE
                  ){
  
  # envelop the function body in 'tryCatch' function to handling errors
  #tryCatch({
  
    e <- new.env(parent=.GlobalEnv)
    e$status <- "INITIALISATION"
  	AssignParam(env=e, currEnv=environment(), funct=RunOutstandingReturns)
    selectObjectsArgsMod <- list(e=e)
    e$selectObjectsArgsMod <- selectObjectsArgsMod
    selectObjectsArgsScor <- list(e=e)
    e$selectObjectsArgsScor <- selectObjectsArgsScor
    #set.seed(100)
    
	
	  FullModelling(model="OR", e=e)
  
}  
   



 
    
    
    
#   },
#   # if stop():
#   error = function(c) {
#     #add an error text in the log
#     assign("log", paste0(e$log, SaveLogTime(), ": ", steps[e$step], "\n\n\nERROR: ", c), 
#            envir= e)
#     writeLines(e$log, paste0(e$outputPath, "\\log.txt"))    #write log in txt file
#     status <- "ERROR"
#     assign("status", "ERROR", envir=e)
#     # if connections to the database were opened, update the corresponding row in the LOG table, close all connections
#     if (inherits(e$conn1, "DBIConnection")) { 
#       dbGetQuery(e$conn1, "Rollback")
#       UpdateLogTable(status, conn1=e$conn1, dbLogTable=e$dbLogTable, runId=e$runId, 
#                        numRecords="NULL", log=e$log, imageName="NULL")
#       dbDisconnect(e$conn)
#       dbDisconnect(e$conn1)
#       #dbDisconnect(conn2)
#     }
#     c <- paste0(c, "Modelling step: ", steps[e$step])     #add the name of modelling step in the error text
#     # return environment options to the initial state
#     if (step > 0)
#       SetTimeZones(status, oldORASDTZ=e$oldTZs[[1]], oldTZ=e$oldTZs[[2]])
#     if (step >= 11)
#       knitr::opts_chunk$set(error=e$oldErrorOpt)
#     closeAllConnections()
#     stop(c)
#   })  

