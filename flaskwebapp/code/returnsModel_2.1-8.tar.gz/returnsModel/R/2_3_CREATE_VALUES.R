##########------CREATE COVARIATES VALUE------############
#' Create covariates values
#' 
#' \code{CreateValues} generates covariates values (which are used to create and predict targets values).
#' 
#' This function is run within the \code{\link{RunModelling}} function to create covariates values for returns from 
#' the base table and form the final population, and within the \code{\link{RunScoring}} function to create covariates 
#' values for returns selected for scoring. This function also can be run separately. 
#' 
#' The list of covariates created by the algorithm is defined by covariates groups pointed in the \code{participation}
#'  vector. Please see comments in the code for more details about covariates from certain groups.
#'  
#' For the purposes of currently implemented models (Outstanding Returns, Returns Purification, Right Returns models),
#'  covariates from \code{FINALISATION CODE}, \code{INCOME TAX RETURN FIELDS}, and (in some cases) \code{S068 LETTERS} groups 
#'  must be created, because further algorithms of model targets creation, data cleaning, population splitting depend on covariates
#'  from these two groups.
#' 
#' @inheritParams FullModelling
#' @inheritParams MakeDBConnections
#' @inheritParams RunModelling
#' @inheritParams PrepareFieldsNames
#' @inheritParams SetModelParameters
#' @param baseTable A name of the DB base table, which is used to store list of returns for the modelling / scoring population creation.
#' @param covFields A vector containing SQL chunks for income keypoints values creation (\code{nvl(...) as ...}).
#' @param targetFields A vector containing SQL chunks for income keypoints values creation (\code{nvl(...) as ...}).
#' @param targetFieldsShort A list of vectors with short names of income keypoints participating in the model targets creation.
#' @param covFieldsShort Short names for keypoints participating in income covariates creation.
#' @param fullCreation A logical. If it is equal to TRUE, the whole process of covariates creation is done. If it is equal to
#'  FALSE (it is possible at the TEST project stage if all temporal tables have already been created and filled with data),
#'  only assignment of the prepared data to the corresponded variable is done.
#' @param rpdTextBack A vector of SQL chunks for conditions on the return period date fields for different years 
#'  (the size of a vector depends on the \code{covYearsBack} parameter value).
#' @param aggCovars A vector with names of covariates from the "AGGREGATED INCOME TAX FIELDS" group.
#' @param aggCovarsText A list of SQL code chunks for creation of covariates from the "AGGREGATED INCOME TAX FIELDS" group.
#' @param timeDiffers A list of SQL code chunks for the creation of an auxiliary table with possible time differences between 
#'  the base return period dates and covariates' return period dates.   
#'  
#' @return \code{dat} / \code{datScor} A dataframe. The model building population (covariates only) or the scoring population.
#' @return \code{groupCovNames} A list. The length of the list is equal to the number of covariates groups participating in the modelling.
#'  Each element in this list contains a vector with names of covariates (without period, e.g. "finalisation_code", not "finalisation_code_b0") 
#'  from a particular covariates group.
#'  
#' @examples
#'  \dontrun{
#'    CreateValues(returnName="IR4", modRetName="OR_IR4", fullCreation=TRUE)
#'  }
#'                    
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
#' @export
CreateValues <- function(conn=e$conn, returnName=e$returnName, baseTable=e$baseTable, covFields=e$covFields, targetFields=e$targetFields,
                          targetFieldsShort=e$targetFieldsShort, covFieldsShort=e$covFieldsShort, modRetName=e$modRetName, 
                          participation=e$participation, stage=e$stage, projectStage=e$projectStage, fullCreation, 
                          timestampB0=eval(e$timestampB0), rpdTextBack=e$rpdTextBack, covYearsBack=e$covYearsBack, aggCovars=e$aggCovars, 
                          aggCovarsText=e$aggCovarsText, timeDiffers=e$timeDiffers, log=e$log, e){
  
  startM <- Sys.time()
  stepName <- "Create targets and covariates values"
  
  group <- c()
  sqlCode = list()
  tableNames = list()
  sqlUpdCode = list()
  groupCovNames = list()
  #timestampB0 <- format(Sys.Date(), "%d/%m/s%Y")
  #timestampB0 <- paste0(format(Sys.Date(),"%d/%m/"), as.numeric(format(Sys.Date(), "%Y"))-1)
  timestampB0 <- paste0(" to_date('", timestampB0,"', 'dd/mm/yyyy') ")
  
  
  
  #-------------------------------------------------------------------------------------
  
    # GROUP "ENTITY CLASS"
    #groupCovNames[["ENTITY CLASS"]] <- c("entity_class_0", "entity_class_1", "entity_class_2", "entity_class_3")
  groupCovNames[["ENTITY CLASS"]] <- c("entity_class_sc_tsB0", "entity_class_sc_tsB1")
  
    tableName <- toupper(paste0(modRetName, "_entity_class"))
    tableNames[["ENTITY CLASS"]][1] <- tableName
    
    sqlCode[["ENTITY CLASS"]][1] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
        select 
		  base.ird_number,
		  base.return_period_date as return_period_date_base,
		  base.return_period_date as return_period_date_covariates,
		  0 as time_differ,
		  c.entity_class as entity_class_sc_tsB0,
		  c1.entity_class as entity_class_sc_tsB1
		from
		  ", baseTable," base
		  left join customers c on
		    c.ird_number=base.ird_number
			  and c.location_number=1
			  and c.date_applied < ", timestampB0," 
			  and (c.date_ceased is null or c.date_ceased > ", timestampB0,")
		  left join customers c1 on
		    c1.ird_number=base.ird_number
			  and c1.location_number=1
			  and c1.date_applied < add_months(", timestampB0,", -12)
			  and (c1.date_ceased is null or c1.date_ceased > add_months(", timestampB0,", -12))")
  
  
  #-----------------------------------------------------------------------------------
  
  # GROUP "FINALISATION CODE"
  
  # Covariates of this group don't directly participate in the model, but they are used for cleaning of missing income tax keypoints values
  # (particular combinations of values of fields "FINALISATION_CODE" and "FINALISED_BY" can help to identify nil returns).
  # For the model building population: covariates are created for B0, B1, B2, etc. periods (we should know B0 finalisation codes 
  # to know the correct real return value).
  # For the scoring population: covariates are created for B1, B2, etc. periods.
  #
  # Covariates for B1, B2, etc. periods are created taking into account "base.timestamp" values. It guarantees that the model building'
  # population does not contain data that is usually not available in the scoring population. The logic of creation of "base.timestamp"
  # values depends on the model type and can be explored in SelectObjects functions for different models.
  # At the scoring step "base.timestamp" is equal to "timestampB0" value (the sys. date), so that it only supports the
  # reproducibility of the model. B1, B2, etc. covariates are used in the data cleaning procedure to purify some null keypoints values
  # as nil values.
  # 
  # Accordingly, "finalisation_code_B0" and "finalised_by_B0" covariates help to define the value of keypoints for B0 period 
  # (real value of returns) in the modelling population (B0 covariates of this group are not created for the scoring population at all). 
  # As a consequence, these covariates influence which returns are selected for modelling and how are they distributed 
  # among sub-populations). That's why "finalisation_code_B0" and "finalised_by_B0" fields are created using "timestampB0", not "base.timestamp".
  # We want real values of returns in the modelling populations to be as accurate as possible, therefore we want to use the most recent information,
  # and provide reproducibility too. "timestampB0" (the system date) provides required properties to our data.
  
  groupCovNames[["FINALISATION CODE"]] <- c("finalisation_code", "finalised_by")
  
  tableName <- toupper(paste0(modRetName, "_policing_temp"))
  tableNames[["FINALISATION CODE"]][2] <- tableName
  
  sqlCode[["FINALISATION CODE"]][2] <- paste0("
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      SELECT * FROM
        ( ",
        if (stage == "modelling") {
		    paste0(" SELECT 
          base.ird_number, 
          base.return_period_date as return_period_date_base,
          pp.return_period_date as return_period_date_covariates,
          round((base.return_period_date - pp.return_period_date)/365, 0) AS TIME_DIFFER,
          pp.finalisation_code,
          pp.finalised_by,
          pp.date_applied
        FROM 
          ", baseTable," base
          JOIN policing_profiles pp
            ON base.ird_number = pp.ird_number
        WHERE 
          pp.RETURN_TYPE ", if (toupper(returnName) == 'IR3ALL') {"in ('IR3', 'IR3A') "} else {paste0("='", toupper(returnName),"' ")}, "AND
          pp.RETURN_PERIOD_DATE = base.return_period_date AND
          pp.date_applied < ", timestampB0," AND
          (pp.date_ceased > ", timestampB0," OR pp.DATE_CEASED IS NULL)
        
        union all ")},

        "SELECT 
          base.ird_number, 
          base.return_period_date as return_period_date_base,
          pp.return_period_date as return_period_date_covariates,
          round((base.return_period_date - pp.return_period_date)/365, 0) AS TIME_DIFFER,
          pp.finalisation_code,
          pp.finalised_by,
          pp.date_applied
        FROM 
          ", baseTable," base
          JOIN policing_profiles pp
            ON base.ird_number = pp.ird_number
        WHERE 
          pp.RETURN_TYPE ", if (toupper(returnName) == 'IR3ALL') {"in ('IR3', 'IR3A') "} else {paste0("='", toupper(returnName),"' ")}, "AND
          pp.RETURN_PERIOD_DATE IN (", paste0(rpdTextBack, collapse=", "),") AND 
          pp.date_applied < base.timestamp AND
          (pp.date_ceased > base.timestamp OR pp.DATE_CEASED IS NULL))")
  
  
  # Remove duplicates selecting the most recent available records
  tableName <- toupper(paste0(modRetName, "_policing"))
  tableNames[["FINALISATION CODE"]][1] <- tableName
  
  sqlCode[["FINALISATION CODE"]][1] <- paste0("
    create global temporary table ", tableName," on commit preserve rows as
      select distinct * from  
        (select
          t.*,
          Max(t.date_applied) over (partition by t.ird_number, t.return_period_date_base, t.time_differ) as max_date_applied
        from 
          ", modRetName,"_POLICING_temp t)
      where
        date_applied=max_date_applied
  ")
  
  #-----------------------------------------------------------------------------------

  # GROUP "INCOME TAX RETURN FIELDS"
  
  # As for "FINALISATION CODE" group, covariates from "INCOME TAX RETURN FIELDS" group are created for B0, B1, B2, etc. periods at the modelling stage
  # and for B1, B2, etc. periods at the scoring stage.
  # Thus, the same logic with timestamping is used:
  # - Modelling (B0 period): use "timestampB0" to obtain the most recent real values of returns at the B0 period for modelling and evaluation;
  # - Modelling (B1, B2, etc. periods): use "base.timestamp" to left in the modelling population only data which is usually available during the scoring;
  # - Scoring (B1, B2, etc. periods): use "base.timestamp", which is equal to timestampB0 (the sys.date), to support the reproducibility.
  
  groupCovNames[["INCOME TAX RETURN FIELDS"]] <- c(targetFieldsShort, covFieldsShort)
  
  if (stage == "modelling"){
  
    # create B0 values (at the modelling stage only)
    tableName <- toupper(paste0(modRetName,"_inc_temp1"))
    tableNames[["INCOME TAX RETURN FIELDS"]][3] <- tableName
    
    sqlCode[["INCOME TAX RETURN FIELDS"]][3] <- paste0("
    
          CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
          				select * 
          				from        
          				  (select 
                		  base.ird_number,
                			base.return_period_date as return_period_date_base, 
                			base.timestamp,
                			ir.return_period_date as RETURN_PERIOD_DATE_COVARIATES, 
          					  round((base.return_period_date - ir.return_period_date)/365, 0) AS TIME_DIFFER, ",
          					  paste0(targetFields, collapse=" "),
          					  paste0(covFields, collapse=" "),
          					  "ir.return_version_no, 
                			MAX(ir.return_version_no) OVER (PARTITION BY base.IRD_NUMBER, base.return_period_date, ir.return_period_date) MAX_RETURN_VER_NO	
                		from ",
                      baseTable, " base
                			join returns_keypoints_", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"ir3"} else {returnName}," ir on
                        base.ird_number = ir.ird_number
                      join returns ret on 
                        ret.ird_number = ir.ird_number 
                        and ret.return_period_date = ir.return_period_date 
                        and ret.return_version_no = ir.return_version_no
                    where 
        			        ir.return_period_date = base.return_period_date 
                      and ret.return_type = '", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"IR3"} else {toupper(returnName)},"'
        				      and ret.date_processed < ", timestampB0,")
  				        where return_version_no = MAX_RETURN_VER_NO")
  }
  
  # create B1, B2, etc. values
  tableName <- toupper(paste0(modRetName,"_inc_temp2"))
  tableNames[["INCOME TAX RETURN FIELDS"]][2] <- tableName
    
  sqlCode[["INCOME TAX RETURN FIELDS"]][2] <- paste0("
    
          CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
              select * 
      				from        
          			(select 
          			  base.ird_number,
          				base.return_period_date as return_period_date_base, 
          				base.timestamp,
          				ir.return_period_date as RETURN_PERIOD_DATE_COVARIATES, 
      					  round((base.return_period_date - ir.return_period_date)/365, 0) AS TIME_DIFFER, ",
      					  paste0(targetFields, collapse=" "),
      					  paste0(covFields, collapse=" "),
      					  "ir.return_version_no, 
          				MAX(ir.return_version_no) OVER (PARTITION BY base.IRD_NUMBER, base.return_period_date, ir.return_period_date) MAX_RETURN_VER_NO	
          			from ",
                  baseTable, " base
          				join returns_keypoints_", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"ir3"} else {returnName}," ir on
                    base.ird_number = ir.ird_number
                  join returns ret on 
                    ret.ird_number = ir.ird_number 
                    and ret.return_period_date = ir.return_period_date 
                    and ret.return_version_no = ir.return_version_no
                where 
          			  ir.return_period_date in (", paste0(rpdTextBack, collapse=", "),") 
                  and ret.return_type = '", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"IR3"} else {toupper(returnName)}, "'
          				and ret.date_processed < base.timestamp)
      				where return_version_no = MAX_RETURN_VER_NO
  	")
  
  # join B0 and B1, B2, etc. data
  tableName <- toupper(paste0(modRetName,"_inc"))
  tableNames[["INCOME TAX RETURN FIELDS"]][1] <- tableName
    
  sqlCode[["INCOME TAX RETURN FIELDS"]][1] <- paste0("
    
    create global temporary table ", tableName," on commit preserve rows as
      select * from ", modRetName,"_inc_temp2",
      if (stage == "modelling"){
        paste0(" union all
      select * from ", modRetName,"_inc_temp1")
      }
  )
  
  sqlUpdCode[["INCOME TAX RETURN FIELDS"]][1] <-  paste0("truncate table  ", modRetName,"_inc_temp2")
  sqlUpdCode[["INCOME TAX RETURN FIELDS"]][2] <-  paste0("drop table  ", modRetName,"_inc_temp2 purge")
  
  if (stage == "modelling") {
    sqlUpdCode[["INCOME TAX RETURN FIELDS"]][3] <-  paste0("truncate table  ", modRetName,"_inc_temp1")
    sqlUpdCode[["INCOME TAX RETURN FIELDS"]][4] <-  paste0("drop table  ", modRetName,"_inc_temp1 purge")
  }

  
  #-----------------------------------------------------------------------------------
  
  # GROUP "S068 LETTERS"
  
  # Covariates from this group don't directly participate in the model, they can be used for cleaning of some missing income tax keypoints values
  # in IR6 and IR9 models. In and before 2013 tax year, IR6 and IR9 returns identified as Right Returns weren't coded as UN by SYSRR. Thus, it is
  # not enough for these periods and return types just to check finalisation codes and users in the policing profiles. Information about issued
  # S068 letters should be checked in the CORRESPONDENCE_OUTBOUND table instead.
  # So, if "considerRR" parameter is TRUE, S068 covariates can be used to purify some null IR6 and IR9 returns as nil returns.
  # 
  # As it was pointed above, these covariates do nor directly participate in the model, but in some cases help to distinguish nill returns from null 
  # returns. That's why the logic of timestamping for this scripts is the same with policing_profiles and income keypoints timestamping:
  #  - Modelling (B0 period): use "timestampB0" to obtain the most recent information about returns at the B0 period for modelling and evaluation;
  #  - Modelling (B1, B2, etc. periods): use "base.timestamp" to left in the modelling population only data which is usually available during the scoring;
  #  - Scoring (B1, B2, etc. periods): use "base.timestamp", which is equal to timestampB0 (the system date), to support the reproducibility.
  
  groupCovNames[["S068 LETTERS"]] <- c("S068")
  
  tableName <- toupper(paste0(modRetName,"_s068_temp1"))
  tableNames[["S068 LETTERS"]][3] <- tableName
  
  sqlCode[["S068 LETTERS"]][3] <- paste0("
  
        CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
          SELECT 
            base.ird_number,
            base.return_period_date AS return_period_date_base,
            co.date_processed AS return_period_date_covariates,
            floor(months_between(base.return_period_date, co.date_processed) / 12) AS TIME_DIFFER,
            --round((base.return_period_date - co.date_processed)/365, 0) AS TIME_DIFFER,
            c.entity_type,
            c.date_applied,
            c.date_ceased,
            'Y' as S068
          FROM
            CORRESPONDENCE_OUTBOUND co
            JOIN ", baseTable," base ON
              base.ird_number = co.ird_number
              AND base.return_period_date <= to_date('31/03/2013', 'dd/mm/yyyy')
            JOIN customers c ON
              c.ird_number = co.ird_number
          WHERE
            co.tax_type = 'INC'
            AND co.document_reference_nbr = 'S068'
            --and location_number = 1 -- always 1 for INC
            --and correspondence_type_code = 'S' -- 'S' Stock Letter - is always S for S068
            --and subject_code = 108 -- always 108 for S068
            AND co.date_processed BETWEEN 
              round(add_months(base.return_period_date, -12), 'month') 
              AND base.return_period_date
            AND co.date_processed < ", timestampB0,"
            AND co.date_processed >= c.date_applied
            AND (co.date_processed < c.date_ceased OR c.date_ceased IS NULL)
            AND c.location_number = 1
            and c.entity_type = ", if (toupper(returnName)=='IR6') {"'T'"} else {if (toupper(returnName)=='IR9') {"'S'"}}
  	) 
  
  
  tableName <- toupper(paste0(modRetName,"_s068_temp2"))
  tableNames[["S068 LETTERS"]][2] <- tableName
  
  sqlCode[["S068 LETTERS"]][2] <- paste0("
  
        CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
          SELECT 
            base.ird_number,
            base.return_period_date AS return_period_date_base,
            co.date_processed AS return_period_date_covariates,
            floor(months_between(base.return_period_date, co.date_processed) / 12) AS TIME_DIFFER,
            --round((base.return_period_date - co.date_processed)/365, 0) AS TIME_DIFFER,
            c.entity_type,
            c.date_applied,
            c.date_ceased,
            'Y' as S068
          FROM
            CORRESPONDENCE_OUTBOUND co
            JOIN ", baseTable," base ON
              base.ird_number = co.ird_number
            JOIN customers c ON
              c.ird_number = co.ird_number
          WHERE
            co.tax_type = 'INC'
            AND co.document_reference_nbr = 'S068'
            --and location_number = 1 -- always 1 for INC
            --and correspondence_type_code = 'S' -- 'S' Stock Letter - is always S for S068
            --and subject_code = 108 -- always 108 for S068
            AND co.date_processed BETWEEN 
              round(add_months(base.return_period_date, -", 12*covYearsBack,"), 'month') 
              AND to_date('31/03/2013', 'dd/mm/yyyy')
            AND co.date_processed NOT BETWEEN
              round(add_months(base.return_period_date, -12), 'month') 
              AND base.return_period_date
            AND co.date_processed < base.timestamp
            AND co.date_processed >= c.date_applied
            AND (co.date_processed < c.date_ceased OR c.date_ceased IS NULL)
            AND c.location_number = 1
            and c.entity_type = ", if (toupper(returnName)=='IR6') {"'T'"} else {if (toupper(returnName)=='IR9') {"'S'"}}
  	) 
  
  # join B0 and B1, B2, etc. data
  tableName <- toupper(paste0(modRetName,"_s068"))
  tableNames[["S068 LETTERS"]][1] <- tableName
    
  sqlCode[["S068 LETTERS"]][1] <- paste0("
    
    create global temporary table ", tableName," on commit preserve rows as
      select * from ", modRetName,"_s068_temp2",
      if (stage == "modelling"){
        paste0(" union all
      select * from ", modRetName,"_s068_temp1")
      }
  )
  

  #-----------------------------------------------------------------------------------

  
  # GROUP "AGGREGATED INCOME TAX FIELDS"
  # Aggregated covariates take into account keypoints values for all return periods prior to the base return period (B0 period).
  # However, these covariates are created with the "_B0" suffix just allow the usage of other package's functions
  
  groupCovNames[["AGGREGATED INCOME TAX FIELDS"]] <- c(aggCovars, "years_since_filed", "num_rets_filed")
   
  tableName <- toupper(paste0(modRetName,"_inc_all"))
  tableNames[["AGGREGATED INCOME TAX FIELDS"]][2] <- tableName
    
  sqlCode[["AGGREGATED INCOME TAX FIELDS"]][2] <- paste0("
    
          CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
              select * 
      				from        
          			(select 
          			  base.ird_number,
          				base.return_period_date as return_period_date_base, 
          				base.timestamp,
          				ir.return_period_date as RETURN_PERIOD_DATE_COVARIATES, 
      					   ",
      					  paste0(targetFields, collapse=" "),
      					  paste0(covFields, collapse=" "),
      					  "ir.return_version_no, 
          				MAX(ir.return_version_no) OVER (PARTITION BY base.IRD_NUMBER, base.return_period_date, ir.return_period_date) MAX_RETURN_VER_NO	
          			from ",
                  baseTable, " base
          				join returns_keypoints_", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"ir3"} else {returnName}," ir on
                    base.ird_number = ir.ird_number
                  join returns ret on 
                    ret.ird_number = ir.ird_number 
                    and ret.return_period_date = ir.return_period_date 
                    and ret.return_version_no = ir.return_version_no
                where 
          			  ir.return_period_date < base.return_period_date
                  and ret.return_type = '", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"IR3"} else {toupper(returnName)}, "'
          				and ret.date_processed < base.timestamp)
      				where return_version_no = MAX_RETURN_VER_NO
  	")
  
  tableName <- toupper(paste0(modRetName,"_AGG_INC"))
  tableNames[["AGGREGATED INCOME TAX FIELDS"]][1] <- tableName
    
  sqlCode[["AGGREGATED INCOME TAX FIELDS"]][1] <- paste0("
    
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
      (select 
        ird_number,
        RETURN_PERIOD_DATE_BASE,
        0 as TIME_DIFFER,
        round(min((RETURN_PERIOD_DATE_BASE-RETURN_PERIOD_DATE_COVARIATES)/365)) years_since_filed,
        count(*) num_rets_filed",
        paste0(aggCovarsText,collapse=" "),
      " from ", modRetName,"_INC_ALL
      group by 
        ird_number,
        RETURN_PERIOD_DATE_BASE)"
  )

  
  #-----------------------------------------------------------------------------------
  
  # GROUP "TAX REGISTRATIONS"
  
  # Check is (was) an entity GST registered during B0, B1, B2, etc. periods.
  # Select only records that were active on the base.timestamp date.
  
  groupCovNames[["TAX REGISTRATIONS"]] <- c("gst_reg")
  
  tableName <- toupper(paste0(modRetName, "_tax_registrations"))
  tableNames[["TAX REGISTRATIONS"]] <- tableName
  
  # Select all record about exploring entities' GST registration that were active on the base.timestamp date.
  # For each period (B0, B1, B2, etc.) the dependence between treg_date_start, treg_date_end, and return_period_date_base will be different.
  # Thus, to keep the query short, we firstly create a CROSS JOIN between the base table and all possible time differences.
  # Then, for each return_period_date_base and time_diff we left only records that characterize an entity's GST registration "time_diff"
  # years ago from the base return period.
  sqlCode[["TAX REGISTRATIONS"]] <- paste0("
    create global temporary table ", tableName," on commit preserve rows as
      WITH q1 AS
        (SELECT
          base.ird_number,
          base.return_period_date AS return_period_date_base,
          base.timestamp,
          new.time_differ,
          b.date_applied,
          b.treg_date_start,
          b.treg_date_end
        FROM 
          ", baseTable," base
          CROSS JOIN
            (", paste0(timeDiffers, collapse=" UNION "),") NEW
          JOIN TAX_REGISTRATIONS b
            ON base.ird_number = b.ird_number    
        WHERE 
          b.tax_type ='GST'
          and b.date_applied <= base.timestamp
          and (b.date_ceased > base.timestamp or b.date_ceased is null))
      

      SELECT distinct
        ird_number,
        return_period_date_base,
        time_differ,
        1 as gst_reg
      from
        q1
      where
        nvl(treg_date_end, q1.timestamp) >= round(add_months(return_period_date_base, -12*(time_differ+1)), 'month')   
        AND treg_date_start <= add_months(return_period_date_base, -12*time_differ)

  ")                              
  
  #-----------------------------------------------------------------------------------
  
  # GROUP "TAX ASSESSED AND PAID"
  
  # Covariates are created for B0, B1, B2, etc. periods.
  # Only records that were processed before the base.timestamp date are selected.
  
  groupCovNames[["TAX ASSESSED AND PAID"]] <- c("provisional_tax_assessed", "payments_made")
  
  tableName <- toupper(paste0(modRetName, "_tr_temp"))
  tableNames[["TAX ASSESSED AND PAID"]][2] <- tableName
  
  # Select all records related to the provisional tax assessments (transaction_code='1100') and payments made (transaction_code in ('8100', '8105'))
  # Rank records by their sequence number
  sqlCode[["TAX ASSESSED AND PAID"]][2] <- paste0("
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
  	  SELECT 
        base.ird_number,
        base.return_period_date AS return_period_date_base,
        tr.return_period_date AS return_period_date_covariates,
        round((base.return_period_date - tr.return_period_date)/365, 0) AS TIME_DIFFER,
        --0 AS time_differ,
        base.TIMESTAMP,
        tr.transaction_code,
        tr.date_processed,
        tr.transaction_status_code,
        tr.seq_no,
        RANK () OVER (PARTITION BY base.ird_number, base.return_period_date, tr.return_period_date, tr.transaction_code ORDER BY tr.transaction_status_code ASC, tr.seq_no DESC) AS DATE_PROCESSED_RANK,
        --RANK () OVER (PARTITION BY base.ird_number, base.return_period_date, tr.return_period_date, tr.transaction_code, tr.transaction_status_code ORDER BY tr.seq_no DESC) AS DATE_PROCESSED_RANK_A,
        tr.amount
      FROM 
        ", baseTable," base 
        JOIN transactions tr ON
          base.ird_number = tr.ird_number
      WHERE
        tr.tax_type='INC' AND
        tr.transaction_code IN ('1100', '8100', '8105') AND
        tr.return_period_date IN (", paste0(rpdTextBack, collapse=", "),", base.return_period_date) AND
        tr.date_processed < base.TIMESTAMP
	")
  
  
  tableName <- toupper(paste0(modRetName, "_tr"))
  tableNames[["TAX ASSESSED AND PAID"]][1] <- tableName
  
  # Aggregate values for provisional_tax_assessed and payments_made.
  # For payments_made only records with transaction_status_code='A' should be used to increase the accuracy. 
  # To avoid double counting, select only records with the rank by the sequence number is equal to 1 (the last sequence number).
  sqlCode[["TAX ASSESSED AND PAID"]][1] <- paste0("
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      SELECT
        ird_number,
        return_period_date_base,
        time_differ,
        sum(CASE WHEN transaction_code='1100' AND date_processed_rank=1 THEN amount ELSE 0 END) AS provisional_tax_assessed,
        sum(CASE WHEN transaction_code IN ('8100', '8105') AND transaction_status_code='A' THEN amount ELSE 0 END) AS payments_made
      FROM
        ", modRetName, "_tr_temp
      group by
        ird_number,
        return_period_date_base,
        time_differ
	")
  
  #-----------------------------------------------------------------------------------
  
  # GROUP "GST RETURN EXTRACT"
   groupCovNames[["GST RETURN EXTRACT"]] <- c("ir101_tot_inc_less_tot_exps", "gst_to_pay_refund", "nbr_of_gst_returns")
  
  # Create GST keypoints covariates for B0, B1, B2, etc. periods.
  
  # The following facts were taken into account in the script:
  # - As far as GST filing frequency can vary for different entities, annualisation procedure is used to calculate annual keypoints values. 
  #   This procedure takes into account a filing frequency and aggregates values using different weight coefficients for different return periods. 
  # - It is important to remember that filing frequency can be different for different locations within the same IRD number.
  # - GST rate has been changed since 01/10/2010. Therefore, different tax fraction coefficients should be used before and after 01/10/2010 while 
  #   calculating total income less total expenses values.
  
  # step 1.
  # Join baseTable with IR101 keypoints table and with RETURNS (to apply the timestamping on date_processed).  
  # Select data that are required for B0, B1, B2, etc. covariates creation.
  # Leave data with maximum return_version_no only.
  
  tableName <- toupper(paste0(modRetName, "_GST_ANN_TEMP2"))
  tableNames[["GST RETURN EXTRACT"]][3] <- tableName
  
  sqlCode[["GST RETURN EXTRACT"]][3] <- paste0("

    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      select * from
    	(select 
		    base.ird_number,
  		  base.return_period_date as return_period_date_base, 
  		  base.timestamp,
  		  ir101.return_period_date as return_period_date_ir101,
  		  ir101.return_version_no, 
  		  ir101.location_number,
  		  MAX(ir101.return_version_no) OVER (PARTITION BY ir101.ird_number, ir101.location_number, ir101.return_period_date) MAX_RETURN_VER_NO,
  	    NVL(ir101.TOTAL_SALES_AND_INCOME_1201,0) as TOTAL_SALES_AND_INCOME,
  		  NVL(ir101.ZERO_RATED_SUPPLIES_1202,0) as ZERO_RATED_SUPPLIES,
  		  NVL(ir101.ADJUSTMENTS_1206,0) as ADJUSTMENTS,
  		  NVL(ir101.TOTAL_PURCHASES_EXPENSES_1208,0) as TOTAL_PURCHASES_EXPENSES,
  		  NVL(ir101.CREDIT_ADJUSTMENTS_1210,0) as CREDIT_ADJUSTMENTS,
  		  NVL(ir101.GST_TO_PAY_REFUND_1212,0) as GST_TO_PAY_REFUND
  		from ",
          baseTable, " base
  		    join RETURNS_KEYPOINTS_IR101 ir101 on 
              base.ird_number = ir101.ird_number
            join returns ret on 
              ret.ird_number = ir101.ird_number and 
              ret.location_number=ir101.location_number and
              ret.return_period_date = ir101.return_period_date and 
              ret.return_version_no = ir101.return_version_no
        where 
  		    ir101.return_period_date between round(add_months(base.return_period_date,-", 12*(covYearsBack+1),"), 'month') 
                                            and add_months(base.return_period_date, 5) and
          --ir101.return_status='A' and
          ret.return_type = 'IR101' and
  		    ret.date_processed < base.timestamp)
      where
  	    return_version_no = MAX_RETURN_VER_NO
  ")
  
  
  # Step 2.
  # Join previous step's result with RETURN_LODGEMENTS to find a filing frequency.
  # Select RETURN_LODGEMENTS table's records that were active on the base.timestamp date.
  # Calculate PROP1 and PROP2 for further GST annualisation.
  
  tableName <- toupper(paste0(modRetName,"_GST_ANN_TEMP"))
  tableNames[["GST RETURN EXTRACT"]][2] <- tableName
  
  sqlCode[["GST RETURN EXTRACT"]][2] <- paste0("
                    
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      select distinct
		    a.ird_number,
  		  a.return_period_date_base,
        a.return_period_date_ir101 as RETURN_PERIOD_DATE_COV,
        a.location_number,
        lodge.filing_frequency,
        -- Take into account changes in GST calculation before and after 01/10/2010:
        CASE 
          WHEN a.return_period_date_ir101<to_date('01/10/2010', 'dd/mm/yyyy') 
          THEN (a.TOTAL_SALES_AND_INCOME + a.ZERO_RATED_SUPPLIES + a.ADJUSTMENTS * 9 + a.TOTAL_PURCHASES_EXPENSES + a.CREDIT_ADJUSTMENTS * 9) 
          ELSE (a.TOTAL_SALES_AND_INCOME + a.ZERO_RATED_SUPPLIES + a.ADJUSTMENTS * 23/3 + a.TOTAL_PURCHASES_EXPENSES + a.CREDIT_ADJUSTMENTS * 23/3)
        END as IR101_TOT_INC_LESS_TOT_EXPS,
        a.GST_TO_PAY_REFUND,
        CASE
          WHEN (substr(lodge.filing_frequency,1,1)='M' and extract(month from a.return_period_date_ir101)>=4) THEN 0
          WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir101)>=5) THEN 0
          WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir101)=4) THEN 0.5
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)>=9) THEN 0
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=8) THEN 1/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=7) THEN 2/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=6) THEN 3/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=5) THEN 4/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=4) THEN 5/6
          ELSE 1
        END as PROP1,
        CASE
          WHEN (substr(lodge.filing_frequency,1,1)='M' and extract(month from a.return_period_date_ir101)>=4) THEN 1
          WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir101)>=5) THEN 1
          WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir101)=4) THEN 0.5
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)>=9) THEN 1
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=8) THEN 5/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=7) THEN 4/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=6) THEN 3/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=5) THEN 2/6
          WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir101)=4) THEN 1/6
          ELSE 0
        END as PROP2
      FROM        
        ", modRetName,"_GST_ANN_TEMP2 a
        join RETURN_LODGEMENTS lodge on
          a.ird_number = lodge.ird_number and 
          a.location_number=lodge.location_number and 
          a.return_period_date_ir101 = lodge.return_period_date
      WHERE 
        lodge.return_type='IR101'
        and lodge.filing_frequency in ('M','SA','SB','SC','SD','SE','SF','TA','TB', 'Y')
        and lodge.date_applied <= a.timestamp
        and (lodge.date_ceased > a.timestamp or lodge.date_ceased is null)")
  
  
  # Step 3.
  # Apply PROP1 and PROP2 to covariates values. If applicable, split covariates value into the two years, with modifying dates 
  # from format 'dd/mm/yy' to format '31/03/yy' and '31/03/(yy+1)'.
  # Union results (UNION ALL) and remove dates outside the range of years we are interested in (see WHERE conditions).
  # Then, aggregate data using appropriate method (SUM, COUNT etc.)
  
  tableName <- toupper(paste0(modRetName, "_GST"))
  tableNames[["GST RETURN EXTRACT"]][1] <- tableName
  
  sqlCode[["GST RETURN EXTRACT"]][1] <- paste0("
  
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      (select
        a.*,
        round((a.return_period_date_base - a.return_period_date_covariates)/365, 0) AS TIME_DIFFER,
        b.NBR_OF_GST_RETURNS
      from  
          (select
            ird_number,
            return_period_date_base,
            RETURN_PERIOD_DATE_COVARIATES,
            round(sum(IR101_TOT_INC_LESS_TOT_EXPS),2) as IR101_TOT_INC_LESS_TOT_EXPS,
            round(sum(GST_TO_PAY_REFUND),2) as GST_TO_PAY_REFUND
          from
            (select 
              ird_number,
              return_period_date_base,
              to_date('31/03'||extract(year from return_period_date_cov), 'dd/mm/yyyy') as RETURN_PERIOD_DATE_COVARIATES,
              IR101_TOT_INC_LESS_TOT_EXPS*PROP1 as IR101_TOT_INC_LESS_TOT_EXPS,
              GST_TO_PAY_REFUND*PROP1 as GST_TO_PAY_REFUND
            from ", modRetName, "_GST_ANN_TEMP
			
            union all
			
            select 
              ird_number,
              return_period_date_base,
              to_date('31/03'||(extract(year from return_period_date_cov)+1), 'dd/mm/yyyy') as RETURN_PERIOD_DATE_COVARIATES,
              IR101_TOT_INC_LESS_TOT_EXPS*PROP2 as IR101_TOT_INC_LESS_TOT_EXPS,
              GST_TO_PAY_REFUND*PROP2 as GST_TO_PAY_REFUND
            from ", modRetName, "_GST_ANN_TEMP)
          group by
            ird_number,
            return_period_date_base,
            RETURN_PERIOD_DATE_COVARIATES) a
			
        left join
		
          (select 
            ird_number,
            return_period_date_base,
            RETURN_PERIOD_DATE_COVARIATES,
            count(1) as NBR_OF_GST_RETURNS
          from
            (select distinct
              ird_number,
              return_period_date_base,
              return_period_date_cov,
              -- To avoid a duplication in the number of returns, proportions are rounded to binary values (0 or 1).
              -- Also, just for NBR_OF_GST_RETURNS calculation, assume that returns with 'T' frequency filed in April are always returns 
              -- for a new tax year (i.e. if PROP1=PROP2=0.5, then PROP1 is rounded to 0 and PROP2 is rounded to 1).
              CASE 
                WHEN round(prop1-0.001,0)=1 
                THEN to_date('31/03'||extract(year from return_period_date_cov), 'dd/mm/yyyy') 
                ELSE to_date('31/03'||(extract(year from return_period_date_cov)+1), 'dd/mm/yyyy') 
              END as RETURN_PERIOD_DATE_COVARIATES
            from ", modRetName, "_GST_ANN_TEMP) 
          group by
            ird_number,
            return_period_date_base,
            RETURN_PERIOD_DATE_COVARIATES) b 
        on
          a.ird_number=b.ird_number and 
          a.return_period_date_base=b.return_period_date_base and 
          a.RETURN_PERIOD_DATE_COVARIATES=b.RETURN_PERIOD_DATE_COVARIATES
      where 
        a.RETURN_PERIOD_DATE_COVARIATES between add_months(a.return_period_date_base,-", 12*covYearsBack,") and a.return_period_date_base
        and (b.NBR_OF_GST_RETURNS is not null or a.IR101_TOT_INC_LESS_TOT_EXPS<>0))
  ")  
    
  # clean results
  sqlUpdCode[["GST RETURN EXTRACT"]][1] <-  paste0("update ", tableName," set NBR_OF_GST_RETURNS=12 where NBR_OF_GST_RETURNS=13")
  sqlUpdCode[["GST RETURN EXTRACT"]][2] <- paste0("update ", tableName," set NBR_OF_GST_RETURNS=1 where NBR_OF_GST_RETURNS is null")
  
  #-----------------------------------------------------------------------------------
    
  # GROUP "ANNUALISED EMPLOYMENT DATA"
  
  groupCovNames[["ANNUALISED EMPLOYMENT DATA"]] <- c("NBR_OF_PAYE_RETURNS", "AVG_Employees", "Sum_Gross_Earnings", "sum_PAYE_Deductions")
  
  # Create PAYE keypoints covariates for B0, B1, B2, etc. periods.
  # The annualisation procedure is the same as for GST keypoints covariates.
  
  # step 1.
  #Join baseTable with IR101 keypoints table and with RETURNS (to apply timestamping on date_processed field)
  
  tableName <- toupper(paste0(modRetName, "_NO_EMP_TEMP2"))
  tableNames[["ANNUALISED EMPLOYMENT DATA"]][3] <- tableName
  
  sqlCode[["ANNUALISED EMPLOYMENT DATA"]][3] <- paste0("

    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      (select * from
  	    (select 
  		  base.ird_number,
  		  base.return_period_date as return_period_date_base, 
  		  base.timestamp,
  		  ir348.return_period_date as return_period_date_ir348,
  		  ir348.return_version_no, 
  		  ir348.LOCATION_NUMBER,
  		  MAX(ir348.return_version_no) OVER (PARTITION BY ir348.IRD_NUMBER, ir348.LOCATION_NUMBER, ir348.return_period_date) MAX_RETURN_VER_NO,
  		  NVL(ir348.TOTAL_EMPLOYEES_1404, 0) as TOTAL_EMPLOYEES,
  		  NVL(ir348.GROSS_EARNINGS_407,0) as GROSS_EARNINGS,
  		  NVL(ir348.PAYE_DEDUCTIONS_801, 0) as PAYE_DEDUCTIONS
  		from ",
  		  baseTable, " base
  			join RETURNS_KEYPOINTS_IR348 ir348 on 
			  base.ird_number = ir348.ird_number
  			join returns ret on 
              ret.ird_number = ir348.ird_number and 
              ret.location_number=ir348.location_number and 
              ret.return_period_date = ir348.return_period_date and 
              ret.return_version_no = ir348.return_version_no
  		where 
  		  base.ird_number not in (48142397, 70507935, 70724286, 70933500, 81880867)
  		  --not in ACCIDENT COMPENSATION CORPORATION (CLAIMANTS COMPENSATION); 
        -- MINISTRY OF SOCIAL DEVELOPMENT- PENSIONS; 
        -- MINISTRY OF SOCIAL DEVELOPMENT- STUDENT ALLOWANCE;
  		  -- MINISTRY OF SOCIAL DEVELOPMENT- BENEFITS; 
        -- IRD PAID PARENTAL LEAVE
  		  and ir348.return_period_date between round(add_months(base.return_period_date,-", 12*(covYearsBack+1),"), 'month') and add_months(base.return_period_date,5)
          --and ir348.return_status='A'
  		  and ret.return_type = 'IR348'
  		  and ret.date_processed < base.timestamp)
      where
  	    return_version_no = MAX_RETURN_VER_NO)
  ")
  
  
  # Step 2.
  
  tableName <- toupper(paste0(modRetName, "_NO_EMP_TEMP"))
  tableNames[["ANNUALISED EMPLOYMENT DATA"]][2] <- tableName
  
  sqlCode[["ANNUALISED EMPLOYMENT DATA"]][2] <- paste0("
                    
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      select distinct
  		a.ird_number,
  		a.return_period_date_base,
  		a.return_period_date_ir348 as RETURN_PERIOD_DATE_COV,
  		a.location_number,
  		lodge.filing_frequency,
  		a.TOTAL_EMPLOYEES,
  		a.GROSS_EARNINGS,
  		a.PAYE_DEDUCTIONS,
  		CASE
  		  WHEN (substr(lodge.filing_frequency,1,1)='M' and extract(month from a.return_period_date_ir348)>=4) THEN 0
  		  WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir348)>=5) THEN 0
  		  WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir348)=4) THEN 0.5
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)>=9) THEN 0
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=8) THEN 1/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=7) THEN 2/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=6) THEN 3/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=5) THEN 4/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=4) THEN 5/6
  		  ELSE 1
  		END as PROP1,
  		CASE
  		  WHEN (substr(lodge.filing_frequency,1,1)='M' and extract(month from a.return_period_date_ir348)>=4) THEN 1
  		  WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir348)>=5) THEN 1
  		  WHEN (substr(lodge.filing_frequency,1,1)='T' and extract(month from a.return_period_date_ir348)=4) THEN 0.5
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)>=9) THEN 1
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=8) THEN 5/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=7) THEN 4/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=6) THEN 3/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=5) THEN 2/6
  		  WHEN (substr(lodge.filing_frequency,1,1)='S' and extract(month from a.return_period_date_ir348)=4) THEN 1/6
  		  ELSE 0
  		END as PROP2
      from        
  	    ", modRetName, "_NO_EMP_TEMP2 a
  		join RETURN_LODGEMENTS lodge on 
          a.ird_number = lodge.ird_number and 
          a.location_number=lodge.location_number and 
          a.return_period_date_ir348 = lodge.return_period_date
  	  where 
  		lodge.return_type='IR348'
  		and lodge.filing_frequency in ('M','SA','SB','SC','SD','SE','SF','TA','TB', 'D', 'Y')
        and lodge.date_applied <= a.timestamp
        and (lodge.date_ceased > a.timestamp or lodge.date_ceased is null)
  ")
  
  
  # Step 3.
  # This query is more comprehensive compare with the same step of GST annualisation. The reason is different orders of aggregation 
  # that are required to receive correct values of AVG_EMPLOYEES and NBR_OF_PAYE_RETURNS.
  # To calculate correct AVG_EMPLOYEES values we have to use data in division of locations, but already aggregated by the same 
  # return_period_date_cov.
  # To calculate correct NBR_OF_PAYE_RETURNS values we have to use data in division of return_period_date_cov, but already aggregated 
  # by locations.
  
  tableName <- toupper(paste0(modRetName, "_NO_EMP"))
  tableNames[["ANNUALISED EMPLOYMENT DATA"]][1] <- tableName
  
  sqlCode[["ANNUALISED EMPLOYMENT DATA"]][1] <- paste0("
  
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
    	select 
  			a.*,
        round((a.return_period_date_base - a.return_period_date_covariates)/365, 0) AS TIME_DIFFER,
  			b.NBR_OF_PAYE_RETURNS
  		from
  		  (select
  			  ird_number,
  			  return_period_date_base,    
  			  RETURN_PERIOD_DATE_COVARIATES,
  			  ceil(sum(AVG_EMPLOYEES)) AS AVG_EMPLOYEES,  -- Calculate an average value for each ird_number as a sum of an average number of employees 
                                                      --for all locations of that ird_number.
  			  round(SUM(GROSS_EARNINGS),2) AS SUM_GROSS_EARNINGS, 
  			  round(SUM(PAYE_DEDUCTIONS),2) AS SUM_PAYE_DEDUCTIONS
  		  from  
  			  -- Apply PROP1 and PROP2 to GROSS_EARNINGS, PAYE_DEDUCTIONS and AVG_EMPLOYEES covariates.
  			  -- Use slightly different logic for AVG_EMPLOYEES: round proportions to the smallest integer greater than or equal to an initial 
          -- proportion value.
  			  -- So that receive covariates values with location_number division.
  			  -- Union results for a current and next tax year.
    			  (select 
    				  ird_number,
    				  return_period_date_base,
    				  to_date('31/03'||extract(year from return_period_date_cov), 'dd/mm/yyyy') as RETURN_PERIOD_DATE_COVARIATES,
    				  location_number,
    				  avg(TOTAL_EMPLOYEES*ceil(PROP1)) as AVG_EMPLOYEES,
    				  sum(GROSS_EARNINGS*PROP1) as GROSS_EARNINGS,
    				  sum(PAYE_DEDUCTIONS*PROP1) as PAYE_DEDUCTIONS
    			  from ", modRetName, "_NO_EMP_TEMP
    			  group by 
    				  ird_number, 
    				  return_period_date_base,
    				  to_date('31/03'||extract(year from return_period_date_cov), 'dd/mm/yyyy'),
    				  location_number
    			  union all
    			  select 
    				  ird_number,
    				  return_period_date_base,
    				  to_date('31/03'||(extract(year from return_period_date_cov)+1), 'dd/mm/yyyy') as RETURN_PERIOD_DATE_COVARIATES,
    				  location_number,
    				  avg(TOTAL_EMPLOYEES*ceil(PROP2)) as AVG_EMPLOYEES,
    				  sum(GROSS_EARNINGS*PROP2) as GROSS_EARNINGS,
    				  sum(PAYE_DEDUCTIONS*PROP2) as PAYE_DEDUCTIONS
    			  from ", modRetName, "_NO_EMP_TEMP
    			  group by
    				  ird_number, 
    				  return_period_date_base,
    				  to_date('31/03'||(extract(year from return_period_date_cov)+1), 'dd/mm/yyyy'),
    				  location_number)
    		  where 
            RETURN_PERIOD_DATE_COVARIATES between add_months(return_period_date_base,-", 12*covYearsBack,") and return_period_date_base
    		  group by 
    			  ird_number,
    			  return_period_date_base,    
    			  RETURN_PERIOD_DATE_COVARIATES) a
  		  -- join the results of GROSS_EARNINGS, PAYE_DEDUCTIONS and AVG_EMPLOYEES calculation with the results of NBR_OF_PAYE_RETURNS calculation.
  		  left join
  		    (select 
  			    ird_number,
  			    return_period_date_base,
  			    RETURN_PERIOD_DATE_COVARIATES,
  			    count(1) as NBR_OF_PAYE_RETURNS
  		    from
  			    (select distinct
  				    ird_number,
  				    return_period_date_base,
  				    return_period_date_cov,
  				    CASE 
  					    WHEN round(prop1-0.001,0)=1 
  					    THEN to_date('31/03'||extract(year from return_period_date_cov), 'dd/mm/yyyy') 
  					    ELSE to_date('31/03'||(extract(year from return_period_date_cov)+1), 'dd/mm/yyyy') 
  				    END as RETURN_PERIOD_DATE_COVARIATES
  			    from ", modRetName, "_NO_EMP_TEMP)
  		    where
  			    RETURN_PERIOD_DATE_COVARIATES between add_months(return_period_date_base,-", 12*covYearsBack,") and return_period_date_base
  		    group by
  			    ird_number,
  			    return_period_date_base,
  			    RETURN_PERIOD_DATE_COVARIATES) b
  		  on 
          a.ird_number=b.ird_number and 
          a.return_period_date_base=b.return_period_date_base and 
          a.RETURN_PERIOD_DATE_COVARIATES=b.RETURN_PERIOD_DATE_COVARIATES
  		where
  			b.NBR_OF_PAYE_RETURNS is not null 
  ")  
  
  # clean results
  sqlUpdCode[["ANNUALISED EMPLOYMENT DATA"]] <- paste0("update ", tableName," set NBR_OF_PAYE_RETURNS=12 where NBR_OF_PAYE_RETURNS=13") 
  
  #------------------------------------------------------------------------------------------  
  
  # GROUP "EMS SCHEDULE INFORMATION"
  groupCovNames[["EMS SCHEDULE INFORMATION"]] <- c("ems_pensions",
                                                    "ems_rate_pensions",
                                                    "ems_student_allowance",
                                                    "ems_rate_stud_allow",
                                                    "ems_benefits",
                                                    "ems_rate_benefits",
                                                    "ems_wages_w",
                                                    "ems_wages_p",
                                                    "ems_rate_w",
                                                    "ems_rate_p")
  
  tableName <- toupper(paste0(modRetName,"_ems"))
  tableNames[["EMS SCHEDULE INFORMATION"]] <- tableName
  
  sqlCode[["EMS SCHEDULE INFORMATION"]] <- paste0("
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      --70507935 - 'MINISTRY OF SOCIAL DEVELOPMENT- PENSIONS'
      --70724286 - 'MINISTRY OF SOCIAL DEVELOPMENT- STUDENT ALLOWANCE'
      --70933500 - 'MINISTRY OF SOCIAL DEVELOPMENT- BENEFITS'
      
      SELECT 
        ird_number,
        return_period_date_base,
        add_months(return_period_date_base, time_differ*(-12)) AS return_period_date_covariates,
        time_differ,
        
        SUM(ems_pensions) AS ems_pensions,
        SUM(ems_credits_pensions) AS ems_credits_pensions, 
        case when SUM(ems_pensions) <> 0 then SUM(ems_credits_pensions)/SUM(ems_pensions)*100 else 0 end as ems_rate_pensions,
        
        SUM(ems_student_allowance) AS ems_student_allowance,
        SUM(ems_credits_stud_allow) AS ems_credits_stud_allow, 
        case when SUM(ems_student_allowance) <> 0 then SUM(ems_credits_stud_allow)/SUM(ems_student_allowance)*100 else 0 end as ems_rate_stud_allow,
        
        SUM(ems_benefits) AS ems_benefits,
        SUM(ems_credits_benefits) AS ems_credits_benefits, 
        case when SUM(ems_benefits) <> 0 then SUM(ems_credits_benefits)/SUM(ems_benefits)*100 else 0 end as ems_rate_benefits,
        
        SUM(ems_wages_w) AS ems_wages_w,
        SUM(ems_credits_w) AS ems_credits_w, 
        case when SUM(ems_wages_w) <> 0 then SUM(ems_credits_w)/SUM(ems_wages_w)*100 else 0 end as ems_rate_w,
        
        SUM(ems_wages_p) AS ems_wages_p,
        SUM(ems_credits_p) AS ems_credits_p,
        case when SUM(ems_wages_p) <> 0 then SUM(ems_credits_p)/SUM(ems_wages_p)*100 else 0 end as ems_rate_p,

        SUM(ems_wages) AS ems_wages,
        SUM(ems_credits) AS ems_credits,
        case when SUM(ems_wages) <> 0 then SUM(ems_credits)/SUM(ems_wages)*100 else 0 end as ems_rate
        
      FROM
        (SELECT
          base.ird_number,
          base.return_period_date AS return_period_date_base,
          --floor((base.return_period_date - b.return_period_date)/365) AS time_differ,
          floor(months_between(base.return_period_date, b.return_period_date) / 12) AS TIME_DIFFER,
          
          SUM(CASE WHEN b.employer_ird_number=70507935 THEN NVL(b.gross_earnings_amount, 0) END) AS ems_pensions,
          SUM(CASE WHEN b.employer_ird_number=70507935 THEN NVL(b.paye_deductions_amount, 0) END) AS ems_credits_pensions, 
          
          SUM(CASE WHEN b.employer_ird_number=70724286 THEN NVL(b.gross_earnings_amount, 0) END) AS ems_student_allowance,
          SUM(CASE WHEN b.employer_ird_number=70724286 THEN NVL(b.paye_deductions_amount, 0) END) AS ems_credits_stud_allow, 
          
          SUM(CASE WHEN b.employer_ird_number=70933500 THEN NVL(b.gross_earnings_amount, 0) END) AS ems_benefits,
          SUM(CASE WHEN b.employer_ird_number=70933500 THEN NVL(b.paye_deductions_amount, 0) END) AS ems_credits_benefits, 
          
          SUM(CASE WHEN (b.employer_ird_number NOT IN (70507935, 70724286, 70933500) AND b.withholding_type_code='W') THEN NVL(b.gross_earnings_amount, 0) END) AS ems_wages_w,
          SUM(CASE WHEN (b.employer_ird_number NOT IN (70507935, 70724286, 70933500) AND b.withholding_type_code='W') THEN NVL(b.paye_deductions_amount, 0) END) AS ems_credits_w, 
          
          SUM(CASE WHEN (b.employer_ird_number NOT IN (70507935, 70724286, 70933500) AND b.withholding_type_code='P') THEN NVL(b.gross_earnings_amount, 0) END) AS ems_wages_p,
          SUM(CASE WHEN (b.employer_ird_number NOT IN (70507935, 70724286, 70933500) AND b.withholding_type_code='P') THEN NVL(b.paye_deductions_amount, 0) END) AS ems_credits_p,

          SUM(CASE WHEN b.employer_ird_number NOT IN (70507935, 70724286, 70933500) THEN NVL(b.gross_earnings_amount, 0) END) AS ems_wages,
          SUM(CASE WHEN b.employer_ird_number NOT IN (70507935, 70724286, 70933500) THEN NVL(b.paye_deductions_amount, 0) END) AS ems_credits
          
        FROM 
          ", baseTable," base
          JOIN employee_paye_summaries b
            ON base.ird_number = b.employee_ird_number
        WHERE 
          b.RETURN_PERIOD_DATE BETWEEN round(add_months(base.return_period_date,-", 12*(covYearsBack+1),"), 'month') and base.return_period_date
          and b.date_processed < base.timestamp
        GROUP BY 
          base.ird_number,
          base.return_period_date,
          b.return_period_date,
          floor((base.return_period_date - b.return_period_date)/365))
      GROUP BY
        ird_number,
        return_period_date_base,
        add_months(return_period_date_base, time_differ*(-12)),
        time_differ
  ")
  
    
  #------------------------------------------------------------------------------------------  
  
  # GROUP "TAX AGENTS"
  groupCovNames[["TAX AGENTS"]] <- c("is_agent_client", "has_changed_agent", "became_agent_client", "ended_relat_with_agents")
  
  tableName <- toupper(paste0(modRetName, "_agents"))
  tableNames[["TAX AGENTS"]] <- tableName
  
  # exclude these agents (PTSI):
  # 99608773      NZ TAX REFUNDS LIMITED  
  # 99297627      MY TAX LIMITED  
  # 100025558     TAXREFUNDS.CO.NZ LIMITED  
  # 101934519     MYTAX.CO.NZ LIMITED  
  # 80744692      MY TAX BACK NZ LIMITED  
  # 98941363      MY REFUND LIMITED  
  # 95483208      SIMPLE AS REFUNDS LIMITED
  
  # "ended_relat_with_agents" covariates catch only situations when an entity ended the relationships with tax agents and haven't started them
  # until the timestamp date. Note: these covariates also don't catch the situation when an entity has finished all relationships with tax agents to
  # became a client of PTSI (see exclusion list of "agents"). "has_changed_agent" covariate also isn't equal to 1 if an entity changed a tax 
  # agent to PTSI.
  
  # Note about a query's structure: As it was done for the GST tax registration covariates, to keep the query shorter, firstly, we build
  # a cross join of the base table with all possible time differences (0, 1 year, 2 years, etc.) between base return period and covariates' return 
  # periods. Then, using different WHERE conditions, we leave only combinations of base return periods and covariates return periods that are comply
  # with certain requirements.
  
  sqlCode[["TAX AGENTS"]] <- paste0("
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      WITH q1 AS
        (SELECT 
          base.ird_number,
          base.return_period_date AS return_period_date_base,
          new.time_differ,
          cl.agent_ird_number,
          cl.agent_location_number,
          cl.date_applied, 
          cl.date_ceased,
          cl.date_start,
          cl.date_end
        FROM
          ", baseTable," base
          CROSS JOIN
            (", paste0(timeDiffers, collapse=" UNION "),") NEW
          JOIN dss.CLIENT_AGENTS_VIEW cl
            ON base.ird_number = cl.ird_number
        WHERE
          cl.tax_type ='INC'
          AND cl.agent_ird_number not in (99608773, 99297627, 100025558, 101934519, 80744692, 98941363, 95483208)
          AND cl.date_applied < base.TIMESTAMP
        ORDER BY
          base.ird_number,
          new.time_differ,
          cl.date_applied,
          cl.date_start)
          
      SELECT 
        a1.ird_number,
        a1.return_period_date_base,
        a1.time_differ,
        --a2.agents_number_this_year,
        --a3.agents_number_last_year,
        --a1.agents_number_two_years,
        --a2.refused_agent_this_year,
        CASE
          WHEN a2.agents_number_this_year IS NOT NULL THEN 1 ELSE 0 
        END AS is_agent_client,
        CASE
            WHEN a1.agents_number_two_years > 1 THEN 1 ELSE 0 
        END AS has_changed_agent,
        CASE
          WHEN (a3.agents_number_last_year IS NULL AND a2.agents_number_this_year IS NOT NULL) THEN 1 ELSE 0 
        END AS became_agent_client,
        CASE
          WHEN (a2.agents_number_this_year IS NOT NULL AND a2.refused_agent_this_year>0) THEN 1 ELSE 0 
        END AS ended_relat_with_agents
      FROM
        (SELECT 
          ird_number,
          return_period_date_base,
          time_differ,
          COUNT(DISTINCT agent_ird_number||'_'||agent_location_number) AS agents_number_two_years
        FROM
          q1
        WHERE
          date_start < add_months(return_period_date_base, -12*(time_differ)) 
          AND (date_end > round(add_months(return_period_date_base,-12*(time_differ+2)), 'month') OR date_end IS NULL)
          AND (date_ceased > round(add_months(return_period_date_base,-12*(time_differ+2)), 'month') OR date_ceased IS NULL)
        GROUP BY
          ird_number,
          return_period_date_base,
          time_differ) a1
        
        LEFT JOIN
        
        (SELECT 
          ird_number,
          return_period_date_base,
          time_differ,
          count(DISTINCT agent_ird_number||'_'||agent_location_number) AS agents_number_this_year,
          count(CASE WHEN (date_ceased IS NULL AND date_end IS NOT NULL) THEN 1 END) AS refused_agent_this_year
        FROM
          q1
        WHERE
          date_start < add_months(return_period_date_base, -12*time_differ) 
          AND (date_end > round(add_months(return_period_date_base,-12*(time_differ+1)), 'month') OR date_end IS NULL)
          AND (date_ceased > round(add_months(return_period_date_base,-12*(time_differ+1)), 'month') OR date_ceased IS NULL)
        GROUP BY
          ird_number,
          return_period_date_base,
          time_differ) a2
        
          ON a1.ird_number=a2.ird_number AND a1.return_period_date_base=a2.return_period_date_base AND a1.time_differ=a2.time_differ 
        
        LEFT JOIN
        
        (SELECT 
          ird_number,
          return_period_date_base,
          time_differ,
          COUNT(DISTINCT agent_ird_number||'_'||agent_location_number) AS agents_number_last_year
        FROM
          q1
        WHERE
          date_start < add_months(return_period_date_base, -12*(time_differ+1)) 
          AND (date_end > round(add_months(return_period_date_base,-12*(time_differ+2)), 'month') OR date_end IS NULL)
          AND (date_ceased > round(add_months(return_period_date_base,-12*(time_differ+2)), 'month') OR date_ceased IS NULL)
        GROUP BY
          ird_number,
          return_period_date_base,
          time_differ) a3
      
          ON a1.ird_number=a3.ird_number AND a1.return_period_date_base=a3.return_period_date_base AND a1.time_differ=a3.time_differ
  ")
  
  #-----------------------------------------------------------------------------------
  
  # JUST TEST - I tried to calculate the time_diff taking into account the balance date for a certain customer (from CLIENT_INC_INDICATORS).
  # GROUP "EMS SCHEDULE INFORMATION TEST"
  groupCovNames[["EMS SCHEDULE INFORMATION TEST"]] <- c("ems_wages_t", "ems_credits_t", "ems_fstc_t", "ems_non_liable_earnings_t")
  
  tableName <- toupper(paste0(modRetName,"_ems_test"))
  tableNames[["EMS SCHEDULE INFORMATION TEST"]] <- tableName
  
  sqlCode[["EMS SCHEDULE INFORMATION TEST"]] <- paste0("
    CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
      SELECT 
        ird_number,
        return_period_date_base,
        add_months(return_period_date_base, time_differ*(-12)) AS return_period_date_covariates,
        time_differ,
        SUM(ems_wages) AS ems_wages_t,
        SUM(ems_credits) AS ems_credits_t, 
        SUM(ems_fstc) AS ems_fstc_t,
        SUM(ems_non_liable_earnings) as ems_non_liable_earnings_t
      FROM
        (SELECT
          base.ird_number,
          base.return_period_date AS return_period_date_base,
          floor((to_date(substr(cl.balance_date,-2,2)||'/'||substr(cl.balance_date,LENGTH(430)-2,1)||'/'|| EXTRACT(YEAR FROM base.return_period_date), 'dd/mm/yyyy') - b.return_period_date)/365) 
            as time_differ,
          SUM(NVL(b.gross_earnings_amount, 0)) AS ems_wages,
          SUM(NVL(b.paye_deductions_amount, 0)) AS ems_credits, 
          SUM(NVL(b.fstc_amount, 0)) AS ems_fstc,
          SUM(NVL(b.earnings_not_liable_amount, 0)) as ems_non_liable_earnings 
        FROM 
          ", baseTable," base
          JOIN employee_paye_summaries b
            ON base.ird_number = b.employee_ird_number
          JOIN CLIENT_INC_INDICATORS cl ON
            cl.ird_number = base.ird_number
            and cl.return_period_date=base.return_period_date
        WHERE 
          cl.tax_type='INC'
          AND cl.return_type='IR3'
          AND b.RETURN_PERIOD_DATE BETWEEN round(add_months(base.return_period_date,-48), 'month') AND add_months(base.return_period_date, 9) ",
          if (stage == "modelling"){
            "and b.date_processed < base.timestamp"
          },
       " GROUP BY 
          base.ird_number,
          base.return_period_date,
          floor((to_date(substr(cl.balance_date,-2,2)||'/'||substr(cl.balance_date,LENGTH(430)-2,1)||'/'|| EXTRACT(YEAR FROM base.return_period_date), 'dd/mm/yyyy') - b.return_period_date)/365))
      GROUP BY
        ird_number,
        return_period_date_base,
        add_months(return_period_date_base, time_differ*(-12)),
        time_differ
  ")
  
  #-------------------------------------------------------------------------------------
  
    # GROUP "CLIENT STATUS"
    groupCovNames[["CLIENT STATUS"]] <- c("client_status")
  
    tableName <- toupper(paste0(modRetName, "_cus"))
    tableNames[["CLIENT STATUS"]] <- tableName
    
    sqlCode[["CLIENT STATUS"]] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
      	(select 
    			base.ird_number,
    			base.return_period_date as return_period_date_base,
          base.return_period_date as return_period_date_covariates,
          0 AS TIME_DIFFER,
    			c.client_status
    		from 
    			customers c 
    			join ", baseTable, " base on 
            c.ird_number = base.ird_number 
    		where
    			c.location_number=1
    			and c.date_applied <= base.timestamp and (c.date_ceased > base.timestamp or c.date_ceased is null))
    ")
  
#-------------------------------------------------------------------------------------
  
    # GROUP "INFORMATION ABOUT CUSTOMERS"
    groupCovNames[["INFORMATION ABOUT CUSTOMERS"]] <- c("entity_class", "entity_age")
  
    tableName <- toupper(paste0(modRetName, "_info_temp"))
    tableNames[["INFORMATION ABOUT CUSTOMERS"]][4] <- tableName
    
    sqlCode[["INFORMATION ABOUT CUSTOMERS"]][4] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
      	select distinct 
    		  * 
    		from  
    		  (select
    			ird_number,
    			return_period_date,
    			case 
    			  when max_date_applied is null
    			  then min_date_applied
    			  else 
    				case
    				  when date_applied=max_date_applied
    				  then customer_start_date
    				end
    			end as customer_start_date
    		  from
    			(select
    			  base.ird_number,
    			  base.return_period_date,
    			  nvl(c.org_commencement_date, c.date_of_birth) as customer_start_date,
    			  c.date_applied,
    			  min(c.date_applied) over (partition by base.ird_number, base.return_period_date) as min_date_applied,
    			  max(c1.date_applied) over (partition by base.ird_number, base.return_period_date) as max_date_applied
    			from
    			  ", baseTable," base
    			  join customers c on
    				c.ird_number = base.ird_number 
    				and c.location_number=1
    			  left join customers c1 on
    				base.ird_number=c1.ird_number
    				and c1.location_number=1
    				and c1.date_applied=c.date_applied
    				and nvl(c1.org_commencement_date, c1.date_of_birth) is not null
    			where
    			  c.date_applied <= base.timestamp))
    		where 
    		  customer_start_date is not null
    		order by
    		  ird_number,
    		  return_period_date
    ")
	
	  tableName <- toupper(paste0(modRetName, "_info_temp2"))
    tableNames[["INFORMATION ABOUT CUSTOMERS"]][3] <- tableName
    
    sqlCode[["INFORMATION ABOUT CUSTOMERS"]][3] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
    		select
    			base.ird_number,
    			base.return_period_date,
    			base.timestamp,
    			c.entity_class,
    			c.client_status,
    			c.date_applied,
    			c.date_ceased,
          case
            when c.client_status in ('C', 'D', 'S', 'B', 'M')
            then 0
            else 1
          end as is_active
    		from
    			", baseTable," base
    			join customers c on
    			  c.ird_number = base.ird_number 
    			   and c.location_number=1
    			   and c.date_applied <= base.timestamp")


    tableName <- toupper(paste0(modRetName, "_info_temp3"))
    tableNames[["INFORMATION ABOUT CUSTOMERS"]][2] <- tableName
    
    temp <- toupper(paste0(modRetName, "_info_temp2"))
  
    sqlCode[["INFORMATION ABOUT CUSTOMERS"]][2] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
    		select
      	  ird_number,
    		  return_period_date,
    		  entity_class,
    		  case
            when is_active = 1
            then timestamp
            else min_date_inactive
    		  end as customer_end_date
    		from  
    		  (select distinct
    			  ird_number,
    			  return_period_date,
            timestamp,
    			  entity_class,
    		  	is_active,
    			  min(date_applied_Inactive) over (partition by ird_number, return_period_date) as min_date_inactive
    		  from
    			  (select
    			    c.ird_number,
    			    c.return_period_date,
              c.timestamp,
    			    c.entity_class,
    			    c.is_active,
    			    c1.date_applied as date_applied_Inactive,
    			    max(c2.date_applied) over (partition by c.ird_number, c.return_period_date) as max_date_active
    			  from
    			    ", temp," c
    			    left join ", temp," c1 on
    				    c1.ird_number=c.ird_number
    				    and c1.return_period_date=c.return_period_date
    				    and c1.is_active = 0
    			    left join ", temp," c2 on
    				    c2.ird_number=c.ird_number
    				    and c2.return_period_date=c.return_period_date
    				    and c2.is_active = 1
    			  where
    			    c.date_ceased > c.timestamp 
    			    or c.date_ceased is null)
    		  where
    			  date_applied_Inactive > max_date_active 
    			  or max_date_active is null
    			  or is_active = 1)
    ")
	
	  tableName <- toupper(paste0(modRetName, "_info"))
    tableNames[["INFORMATION ABOUT CUSTOMERS"]][1] <- tableName
    
    sqlCode[["INFORMATION ABOUT CUSTOMERS"]][1] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS 
      	select
    		  t1.ird_number,
    		  t1.return_period_date as return_period_date_base,
    		  t1.return_period_date as return_period_date_covariates,
    		  0 AS TIME_DIFFER,
    		  t2.entity_class,
    		  case
            when t1.customer_start_date=to_date('01/01/1990', 'dd/mm/yyyy')
            then 99999
            else round(months_between(t2.customer_end_date, t1.customer_start_date)/12, 1)
          end as entity_age
    		from ",
    		  paste0(modRetName, "_info_temp"), " t1
    		  join ", paste0(modRetName, "_info_temp3")," t2 on
    		    t1.ird_number=t2.ird_number
    			and t1.return_period_date=t2.return_period_date
    ")
	
  
#-------------------------------------------------------------------------------------

  
    # GROUP "INBOUND INFO ABOUT CESSATION"
    #groupCovNames[["INBOUND INFO ABOUT CESSATION"]] <- c("company_or_business_stop", "company_dissolved", "company_cessation", 
    #                                                      "business_cessation")
    
    # Was an entity ceased during a tax year?
  
    groupCovNames[["INBOUND INFO ABOUT CESSATION"]] <- c("company_or_business_stop")
  
    tableName <- toupper(paste0(modRetName, "_inb"))
    tableNames[["INBOUND INFO ABOUT CESSATION"]] <- tableName
    
    sqlCode[["INBOUND INFO ABOUT CESSATION"]] <- paste0("
      -- 630 Company dissolved 
      -- 830 Cessations 
      -- 871 Bussiness Cessation Forms 
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
        SELECT
          ird_number,
          return_period_date_base,
          TIME_DIFFER,
          MAX(company_or_business_stop) AS company_or_business_stop
          --,
          --MAX(company_dissolved) AS company_dissolved,
          --MAX(company_cessation) AS company_cessation,
          --MAX(business_cessation) AS business_cessation
        FROM
          (SELECT
            base.ird_number,
            base.return_period_date AS return_period_date_base,
            --round((base.return_period_date - co.date_received)/365, 0) AS TIME_DIFFER,
            floor(months_between(base.return_period_date, co.date_received) / 12) AS TIME_DIFFER,
            1 AS company_or_business_stop
            --,
            --CASE WHEN co.subject_code=630 THEN 1 ELSE 0 END AS company_dissolved,
            --CASE WHEN co.subject_code=830 THEN 1 ELSE 0 END AS company_cessation,
            --CASE WHEN co.subject_code=871 THEN 1 ELSE 0 END AS business_cessation
          FROM
            dss.correspondence_inbound_view co
            JOIN ", baseTable," base ON
              base.ird_number=co.ird_number
          WHERE
            co.subject_code IN (630, 830, 871)
            --AND co.tax_type in ('GST', 'INC', 'PAY')
            AND co.tax_type in ('INC', 'PAY')
            AND co.deleted_indicator='N'
            AND co.date_received BETWEEN 
              round(add_months(base.return_period_date, -", 12*(covYearsBack+1),"), 'month') AND
              base.return_period_date
            AND co.date_received < base.timestamp)
        GROUP BY
          ird_number,
          return_period_date_base,
          TIME_DIFFER
    ")

#-------------------------------------------------------------------------------------
  
    # GROUP "REFERENCES STATUS"
  
    # For individual entities
    # Is an individual is (was) a director / shareholder / partner in a partnerships / beneficiary of a trust during particular period of time?
    # If yes, what was the client status of a related entity (Active or Not)?
  
    groupCovNames[["REFERENCES STATUS"]] <- c("is_director",
                                              "is_partner",
                                              "is_shareholder",
                                              "is_beneficiary",
                                              "ref_status_dir",
                                              "ref_status_ptr",
                                              "ref_status_shr",
                                              "ref_status_ben")
    # step 1
    tableName <- toupper(paste0(modRetName, "_ref_temp2"))
    tableNames[["REFERENCES STATUS"]][3] <- tableName
    
    sqlCode[["REFERENCES STATUS"]][3] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
          SELECT 
            base.ird_number,
            base.return_period_date AS return_period_date_base,
            base.timestamp,
            add_months(base.return_period_date, -12*new.time_differ) as return_period_date_covariates,
            new.time_differ,
            cr.reference_type,
            cr.ird_number_to,
            cr.date_applied,
            cr.date_ceased
          FROM
            ", baseTable," base
            CROSS JOIN
              (", paste0(timeDiffers, collapse=" UNION "),") new
            JOIN dss.cross_references_view cr
              ON base.ird_number = cr.ird_number_from
          WHERE
            cr.reference_type IN ('DIR', 'PTR', 'SHR', 'BEN')
            AND cr.date_applied < add_months(base.return_period_date, -12*new.time_differ)
            AND cr.date_applied < base.timestamp
            AND (cr.date_ceased > round(add_months(base.return_period_date,-12*(NEW.time_differ+1)), 'month')
              OR cr.date_ceased IS NULL)
      ")
        
  
    # step 2
    tableName <- toupper(paste0(modRetName, "_ref_temp"))
    tableNames[["REFERENCES STATUS"]][2] <- tableName

    sqlCode[["REFERENCES STATUS"]][2] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
        SELECT
          *
        FROM
          (SELECT
            q1.ird_number,
            q1.return_period_date_base,
            q1.timestamp,
            q1.return_period_date_covariates,
            q1.time_differ,
            q1.ird_number_to,
            q1.reference_type,
            c.client_status,
            MAX(c.date_applied) OVER (PARTITION BY q1.ird_number, q1.time_differ, q1.ird_number_to, q1.reference_type) AS MAX_date,
            c.date_applied,
            c.date_ceased
          FROM ",
            modRetName, "_ref_temp2 q1
            JOIN customers c ON
              q1.ird_number_to=c.ird_number
          WHERE
            (c.date_applied < round(add_months(q1.return_period_date_covariates, -12), 'month')
            AND (c.date_ceased > round(add_months(q1.return_period_date_covariates, -12), 'month')
              OR c.date_ceased IS NULL))
            OR (c.date_applied >= round(add_months(q1.return_period_date_covariates, -12), 'month')
              AND c.date_applied < q1.return_period_date_covariates
              AND c.date_applied < q1.timestamp)
          )
        WHERE
          date_applied=max_date
        ORDER BY
          ird_number,
          time_differ,
          ird_number_to,
          reference_type
    ")
  
  
    # step 3
    tableName <- toupper(paste0(modRetName, "_ref"))
    tableNames[["REFERENCES STATUS"]][1] <- tableName
    
    sqlCode[["REFERENCES STATUS"]][1] <- paste0("
      --A  24158	Active
      --B	4	Bankrupt
      --C	6242	Ceased
      --D	20	Deceased
      --L	197	Liq'dation
      --M	199	Amaltgd Co
      --R	15	Rec'ship
      --S	7420	Struck Off
      --V	4	VOL ADMIN
                
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
        SELECT 
          ird_number,
          return_period_date_base,
          time_differ,
          MAX(CASE WHEN reference_type='DIR' THEN 1 ELSE 0 END) AS is_director,
          MAX(CASE WHEN reference_type='PTR' THEN 1 ELSE 0 END) AS is_partner,
          MAX(CASE WHEN reference_type='SHR' THEN 1 ELSE 0 END) AS is_shareholder,
          MAX(CASE WHEN reference_type='BEN' THEN 1 ELSE 0 END) AS is_beneficiary,
          MIN(CASE WHEN reference_type='DIR' THEN 
                CASE WHEN client_status <> 'A' THEN 'Not Active' ELSE 'Active' END
              END) AS ref_status_dir,
          MIN(CASE WHEN reference_type='PTR' THEN 
                CASE WHEN client_status <> 'A' THEN 'Not Active' ELSE 'Active' END
              END) AS ref_status_ptr,
          MIN(CASE WHEN reference_type='SHR' THEN 
                CASE WHEN client_status <> 'A' THEN 'Not Active' ELSE 'Active' END
              END) AS ref_status_shr,
          MIN(CASE WHEN reference_type='BEN' THEN 
                CASE WHEN client_status <> 'A' THEN 'Not Active' ELSE 'Active' END
              END) AS ref_status_ben
        FROM
          ", modRetName,"_ref_temp
        GROUP BY
          ird_number,
          return_period_date_base,
          time_differ
    ")
  
  #-------------------------------------------------------------------------------------
  
    # GROUP "REFERENCES STATUS IR6"
  
    groupCovNames[["REFERENCES STATUS IR6"]] <- c("is_deceased")
    # step 1
    tableName <- toupper(paste0(modRetName, "_ref_ir6_temp"))
    tableNames[["REFERENCES STATUS IR6"]][2] <- tableName
    
    sqlCode[["REFERENCES STATUS IR6"]][2] <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
          SELECT 
            base.ird_number,
            base.return_period_date AS return_period_date_base,
            base.timestamp,
            add_months(base.return_period_date, -12*new.time_differ) as return_period_date_covariates,
            new.time_differ,
            cr.reference_type,
            cr.ird_number_to,
            cr.date_applied,
            cr.date_ceased
          FROM
            ", baseTable," base
            CROSS JOIN
              (", paste0(timeDiffers, collapse=" UNION "),") new
            JOIN dss.cross_references_view cr
              ON base.ird_number = cr.ird_number_from
          WHERE
            cr.reference_type = 'DEC'
            AND cr.date_applied < add_months(base.return_period_date, -12 * new.time_differ)
            AND cr.date_applied < base.timestamp
            AND (
              (cr.date_ceased > round(add_months(base.return_period_date, -12 * (NEW.time_differ + 1)), 'month')
              AND cr.date_ceased > base.timestamp)
              OR cr.date_ceased IS NULL
            )
      ")
        
  
    # step 2
    tableName <- toupper(paste0(modRetName, "_IR6_ref"))
    tableNames[["REFERENCES STATUS IR6"]][1] <- tableName
    
    sqlCode[["REFERENCES STATUS IR6"]][1] <- paste0("
  
                
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
        SELECT 
          ird_number,
          return_period_date_base,
          time_differ,
          MAX(CASE WHEN reference_type='DEC' THEN 1 ELSE 0 END) AS is_deceased
        FROM
          ", modRetName,"_ref_ir6_temp
        GROUP BY
          ird_number,
          return_period_date_base,
          time_differ
    ")
  
# 
# 
#     tableName <- toupper(paste0(modRetName, "_ref_ir6_max"))
#     tableNames[["REFERENCES STATUS IR6"]][2] <- tableName
#     
#     sqlCode[["REFERENCES STATUS IR6"]][2] <- paste0("
#       CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
#           SELECT 
#             base.ird_number,
#             base.return_period_date AS return_period_date_base,
#             --base.timestamp,
#             --base.return_period_date as return_period_date_covariates,
#             0 as time_differ,
#             max(case
#               when cr.reference_type='DEC'
#               then 1
#               else 0
#             end) as max_is_deceased
#           FROM
#             ", baseTable," base
#             JOIN dss.cross_references_view cr
#               ON base.ird_number = cr.ird_number_from
#           WHERE
#             cr.date_applied < base.timestamp
#             AND (cr.date_ceased > base.timestamp OR cr.date_ceased IS NULL)
#           GROUP BY
#             base.ird_number,
#             base.return_period_date,
#             0
#       ")
#   
#   
#     tableName <- toupper(paste0(modRetName, "_IR6_ref_final"))
#     tableNames[["REFERENCES STATUS IR6"]][1] <- tableName
#     
#     sqlCode[["REFERENCES STATUS IR6"]][1] <- paste0("
#   
#                 
#       CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
#         SELECT 
#           t1.ird_number,
#           t1.return_period_date_base,
#           t1.time_differ,
#           t1.is_deceased,
#           t2.max_is_deceased
#         FROM
#           ", modRetName,"_ir6_ref t1
#           left join ", modRetName,"_ref_ir6_max t2 on
#             t1.ird_number=t2.ird_number
#             and t1.return_period_date_base=t2.return_period_date_base
#             and t1.time_differ=t2.time_differ
#     ")

#-------------------------------------------------------------------------------------

  
  if (fullCreation){
  
    # Create temporary tables according to sql scripts only for groups of covariates from "participation" vector
    foreach (group = participation) %do% {
      for (j in length(sqlCode[[group]]):1)
        CreateTable(conn, sqlCode[[group]][j], tableNames[[group]][j])
      j <- 1
      while (j <= length(sqlUpdCode[[group]])){
        dbGetQuery(conn, sqlUpdCode[[group]][j])
        j <- j+1
      }
    }
  
    ########## population ##############
    
    tableName <- toupper(paste0(modRetName,"_population"))
    
    popColumns <- foreach (group = participation) %do% 
      paste0(groupCovNames[[group]], collapse=", ")
    
    popTables <- foreach (group = participation[-1]) %do%
      paste0(" FULL JOIN ", tableNames[[group]][1], " using (ird_number, return_period_date_base, TIME_DIFFER)")
    
      
    sqlCodePop <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
    		SELECT 
    			ird_number,
    			return_period_date_base,
    			TIME_DIFFER, ",
          paste(popColumns, collapse=", "),
    	  " FROM ",
          tableNames[[participation[1]]][1], paste0(popTables, collapse=" "))
      
    CreateTable(conn, sqlCodePop, tableName)
  
  
    ### final population #####
    excl <- c("IRD_NUMBER", "RETURN_PERIOD_DATE_BASE", "RETURN_PERIOD_DATE_COVARIATES", "TIME_DIFFER")
    fieldsList <- dbListFields(conn, paste0(toupper(modRetName), "_POPULATION"))
    fieldsList <- fieldsList[-which(fieldsList %in% excl)]
    
    finalPopNames <- foreach (i = 0:covYearsBack) %do% 
      paste0("a", i,".", fieldsList, " as ", fieldsList, "_b", i)
    
    fieldsNames <- c()
    for (i in 1:(covYearsBack + 1)){
      fieldsNames <- paste(fieldsNames, paste0(finalPopNames[[i]], collapse=", "), sep=", ")
    }
    
    gstDiff <- c()
    for (i in 1:covYearsBack){ 
      gstDiff <- paste0(gstDiff, paste0(", a0.GST_TO_PAY_REFUND - a", i,".GST_TO_PAY_REFUND as GST_TO_PAY_REFUND_b0b", i, ", a0.ir101_tot_inc_less_tot_exps - a", i,".ir101_tot_inc_less_tot_exps as IR101_INC_LESS_EXPS_b0b", i))
    }
    
    payeDiff <- c()
    for (i in 1:covYearsBack){ 
      payeDiff <- paste0(payeDiff, paste0(", a0.SUM_GROSS_EARNINGS - a", i,".SUM_GROSS_EARNINGS as SUM_GROSS_EARNINGS_b0b", i,", a0.SUM_PAYE_DEDUCTIONS - a", i,".SUM_PAYE_DEDUCTIONS as SUM_PAYE_DEDUCTIONS_b0b", i))
    }
    
    joinText <- c()
    for (i in 0:covYearsBack){
      joinText <- paste0(joinText, "left join 
            			(select *
          				from ", modRetName,"_population
          				where TIME_DIFFER=", i,") a", i,"
          				on (base.ird_number = a", i,".ird_number and base.return_period_date = a", i,".return_period_date_base) ")
    }
    
    tableName <- toupper(paste0(modRetName, "_final_pop_", stage))
      
    sqlCodePop <- paste0(
      if (projectStage == "TEST"){
        paste0("CREATE /*global temporary*/ TABLE ", tableName," /*on commit preserve rows*/ AS")
      } else {
        paste0("CREATE global temporary TABLE ", tableName," on commit preserve rows AS")
      },
      " select 
      		base.ird_number,
    			base.return_period_date as return_period_date_base,
    			base.return_type ",
    					
    	    fieldsNames,
    		      	
          if ("GST RETURN EXTRACT" %in% participation) {
      			gstDiff
          },
    
          if ("ANNUALISED EMPLOYMENT DATA" %in% participation) {
      			payeDiff
          },
    		
			" from ",
					baseTable, " base ",
					
  				joinText
    
      )
    
    CreateTable(conn, sqlCodePop, tableName)
  }
  
  tableName <- toupper(paste0(modRetName, "_final_pop_", stage)) 
 
  res <- dbGetQuery(conn, paste0("SELECT 1 FROM ", tableName," GROUP BY ird_number, return_period_date_base HAVING count(1)>1"))
  if (dim(res)[1] != 0){stop("Duplications in the model population set")}

  name <- paste0("dat", if (stage == "scoring") {"Scor"})
  output <- list("groupCovNames"=groupCovNames)
  output[[name]] <- dbGetQuery(conn, paste0("select * from ", modRetName,"_final_pop_", stage))
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  output
}  
