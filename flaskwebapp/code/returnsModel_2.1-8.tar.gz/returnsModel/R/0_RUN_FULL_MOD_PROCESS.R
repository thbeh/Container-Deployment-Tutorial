
##########------MODELLING AND SCORING FOR RETURNS MODELS (for the certain return type)--------############
#' Run all modelling and scoring steps for a certain return model and return type
#'  
#' \code{FullModelling} runs a model building, scoring, creation of evaluation reports, and the output publishing.
#'  This function is universal for all implemented within the package income tax return models and different return types.
#' 
#' The function consists of the following steps:
#' \itemize{
#'  \item Set parameters (\code{\link{SetModelParameters}})
#'  \item Make connections to the database (\code{\link{MakeDBConnections}}) and create the model log (\code{\link{CreateDBLog}})
#'  \item Create the population and build the model (\code{\link{RunModelling}})
#'  \item Create evaluation reports (\code{\link{ORCreateEvaluationReport}}, \code{\link{RRCreateEvaluationReport}})
#'  \item Select objects for scoring and predict values (\code{\link{RunScoring}})
#'  \item Filter results using the set of business rules if required in the model (\code{\link{RRDoFiltering}})
#'  \item Save the output data (\code{\link{SavingResults}})
#' }
#' 
#' @param returnName A character string. A type of return: IR3, IR3A, IR3ALL (amalgamated model for IR3 and IR3A), IR3NR, IR4, IR6, IR7, IR9.
#' @param model A model name.
#' @param e An environment created to keep all parameters' values and interim model output.
#' @param projectStage A character string. If it is equal to \code{"TEST"} then initial datasets are reduced to the 
#'  \code{nrows} size to reduce the calculation time. If it's equal to \code{"PRODUCTION"} then the full datasets are used. Also,
#'  in some cases at the TEST project stage, tables instead of global temporary tables are created in the database.
#' @param timestampB0 timestampB0 A date. The current system date by default. The parameter was introduced to support the 
#'  reproducibility of the model's results. It is used in some data extraction scripts to restrict the selection only by
#'  records that were active records on the \code{timestampB0} date. \code{timestampB0} is used:
#'    \itemize{
#'      \item in the scripts for selection of returns for modelling and scoring (in conditions for B0 period)
#'      \item during the creation of several specific B0 covariates that define model targets values (FINALISATION_CODE_B0 and income tax 
#'      keypoints for B0 period)
#'    } 
#' @param covYearsBack A positive integer. It defines how many years we are looking back during covariates creation. E.g.,
#'  if \code{covYearsBack = 3}, all types of covariates will be created to describe the state of an entity three, two,
#'  and one year ago (and, for some covariate types, during the current year too). The minimum recommended value is \code{3},
#'  the maximum recommended value is \code{5}.
#' @param ss A positive integer. The Random Forest algorithm's parameter. It is used to define the maximum size of samples to draw from the population
#'  during the model building (those samples are used for individual decision trees building).
#' @param nTrees A positive integer. The Random Forest algorithm's parameter. It defines the number of random trees to grow.
#' @param method A character string. It defines the method of balancing of the model population. Available methods:
#'  \itemize{
#'    \item \code{reduce_param} - balancing the (sub)population via reducing the number of elements from the majority class.
#'      The initial (sub)population is not changed, but samples selected for each decision tree building are balanced.
#'		The \code{sampsize} parameter of the Random Forest is used to provide described balanced sampling.
#'    \item \code{reduce_sampling} - balancing the (sub)population via reducing the number of elements from the majority class.
#'      Balancing is done for the modelling (sub)population itself. The balanced (sub)population is then used for the Random Forest model 
#'		construction.
#'    \item \code{oversampling} - balancing the (sub)population via oversampling the minority class. Balancing is done for the 
#'      model (sub)population itself. Balanced (sub)population is then used for the Random Forest model construction.
#'  }
#'  The default recommended method is \code{reduce_param}.
#' @param coeff A real number from 0 to 1 (default value is 0.5). The proportion of the minority class in the model population
#'  after balancing.
#' @param mtry A positive integer. The Random Forest algorithm's parameter. Number of covariates randomly sampled for each separate decision tree building.
#'	If left empty, the default Random Forest value is used.
#' @param mask A list of vectors. The number of vectors in the list defines the number of splitting populations.
#'  Elements of a vector define the set of rules for selection of returns from the general population to sub-populations.
#'  Elements of vectors have to be written using the following templates: 
#' 	\itemize{
#'    \item "Bi" - select returns of customers who has filed the income tax return of a given type \emph{i} years ago 
#'      or this \emph{i}-years-ago return is known to be NIL;
#'    \item "no Bi" - select returns of customers who has not filed the income tax return of a given type \emph{i} years ago 
#'      and this \emph{i}-years-ago return is not known to be NIL;
#'    \item "any return" - select returns of customers who has filed at least one income tax return of a given type (it does not
#'      matter how many years ago it happened);
#'    \item "no returns" - select returns of customers who has not filed any income tax return of a given type.
#'	}
#'  If several rules needed to define a population, they should be listed within a vector separated by a comma.
#'  For example, the default \code{mask} value for the Right Return model \code{mask = list(c("B1", "B2", "B3"), 
#'  c("B1", "B2", "no B3"), c("B1", "no B2"))} means that the general population will be separated into three 
#'  sub-populations according to the following rules:
#'	\enumerate{
#'    \item Population #1: returns where the immediate last 3 years' (B1, B2, B3) income tax return values are known 
#'    \item Population #2: returns where the immediate last 2 years' (B1 and B2) income tax returns values are known, but B3 data is not available
#'    \item Population #3: returns where the immediate last year's (B1 period) income tax return value is known, but B2 data is not available
#'	}
#' @param conditionalSplit A logical. If \code{TRUE} a few separate models are built for different parts 
#'  of the model population data set (according to a value of \code{mask} parameter). If \code{FALSE}, one model 
#'  for the whole model population is built.
#' @param intervals A vector of cut-off probabilities. Tables in evaluation reports are created according to this parameter.
#' @param clientStatusList A vector of clients statuses. Only clients with those statuses participate in the modelling and selected for scoring.
#' @param nrows A number of rows left in the modelling and scoring populations during the test algorithm runs. This parameter is used just if 
#'  \code{projectStage == "TEST"}.
#' @param ssMax A positive integer. The maximum size of the sub-populations.
#' @param dropTables A logical. If it is equal to TRUE, all temporary tables created during the modelling will be dropped. 
#' @param considerRR A logical. If \code{TRUE}, returns identified as Right Returns during previous years are treated as 
#'  NIL returns for the purposes of data selection and cleaning. If \code{FALSE}, those returns are considered as returns
#'  with unknown value. The default value for the Right Returns model is TRUE, for the Outstanding Returns model is FALSE.
#'	Previous years Right Returns are identified by a finalisation code ('UN') and a finalisation user ('SYSRR'). Additionally,
#'	for IR6 and IR9 return types, returns that were finalised with issue of a S068 letter in or before 2013 tax year 
#'	are also considered as Right Returns for corresponded financial years.
#' @param UNbyUserIsNill A logical. If \code{TRUE}, returns that were finalised as UN by IR's staff user (FINALISED_BY 
#'  field's value is a user's identification number) are treated as NIL returns. If \code{FALSE}, those returns are 
#'  considered as returns with unknown value. The default value for the Right Returns model is \code{FALSE},
#'	for the Outstanding Returns model is \code{TRUE}.
#' @param outputPathIni A path name to a folder. This folder is used for saving logs, workspaces, and evaluation reports.
#' @param selectObjectsArgsMod A list of parameters with their values. This list consists of different elements depending on
#'  the model type (Right Returns, Outstanding Returns, etc.) This list should include all parameters and their values that are 
#'  used in the \code{SelectObjects} function for the current model type at the modelling stage.
#' @param selectObjectsArgsScor A list of parameters with their values. This list consists of different elements depending on
#'  the model type (Right Returns, Outstanding Returns, etc.) This list should include all parameters and their values that are 
#'  used in the \code{SelectObjects} function for the current model type at the scoring stage.   
#' @param purificationOnly A logical. The parameter is used only in the Outstanding Returns model. If \code{TRUE}, only purification 
#'  targets are created (\code{modelTargetsList} and \code{DataSelect} parameters in a corresponded file with model parameters must 
#'  not be empty in this case). If \code{FALSE} outstanding returns value targets are created along with the purification targets (if any).
#' @param createExcelEvalRep A logical. The parameter is used only in the Outstanding Returns model. If \code{TRUE}, the evaluation report 
#'  in \emph{xlsm} format is created. It contains informaton about the model performance at different cut-off levels of the model targets.
#' @param year A year (numeric). A meaning depends on a particular model.
#' @param yearsBack An integer. The parameter is used in the Outstanding Returns modle only. It shows how old can a return
#'  be to be selected for modeling. For instance, if \code{yearsBack=7} and the most recent return period date is '31/03/2016',
#'  the earlies returns participating in the modelling will be with the return period date is equal to '31/03/2009' (7 years back).
#' @param runDate The current date in the "Y-m-d" format.       
#' @param createReport A logical. If it is equal to \code{TRUE} the evaluation report is created, otherwise
#'  the report creation step is omitted.
#' @param runNo A number of selection. The parameter is used in the Right Returns model only. Before 2016, there were two main selection 
#'  for the Individual Right Returns select (the 1st usually took place in the middle of March, the 2nd - in the beginning of April). 
#'  During the 2nd run, the output is cleaned from Right Returns that already were caught during the 1st run. There is onlty one (1st) run for 
#'  the Non-individual select.  
#' @param createView A logical. If it is eqaul to \code{TRUE}, an output DB view is automatically created. Otherwise, this step
#'  is omitted. The parameter is used in the Outstanding Returns model only.
#'                                               
#' @return If \code{FullModelling} function is completed without errors, the following output is also created:
#'  \itemize{
#'    \item A row in the LOG database table of the Modelling schema with status is equal to \code{"COMPLETE"}
#'    \item The model output data in the output database table and a view with the output data
#'    \item A log file (log.txt)
#'    \item R workspaces for the modelling and scoring stages (*.RData files)
#'    \item Evaluation reports  
#'  }
#' @return \code{e} - environment with all results of the modelling stage.
#' @return \code{irdNumbers} A data set with IRD numbers that where identified as possible Right Returns for the certain return type 
#'  (for the Right REturns model only).
#'  If an error occurs during the function run, the function writes an error in a log, updates the 
#'    MODEL_RUN_LOG table with the status is equal to \code{"ERROR"}, returns all 
#'    environment options (time zone, knitr options) to the initial settings, removes \code{e} environment,
#'    and then returns to the top level (\code{\link{RunRightReturns}}) to start the process for the next return type.
#'
#' @examples
#' \dontrun{
#'   # Run the modelling and scoring processes for the IR3 return type 
#'   # (all parameters should be presented in e environment)
#'   RRFullModelling(returnName="IR3", e=e)
#' }
#'  
#' @export
FullModelling <- function(model, returnName=e$returnName, numCores=e$numCores, selectObjectsArgsMod=e$selectObjectsArgsMod, selectObjectsArgsScor=e$selectObjectsArgsScor, 
                          purificationOnly=e$purificationOnly, createExcelEvalRep=e$createExcelEvalRep, clientStatusList=e$clientStatusList, 
                          year=e$year, yearsBack=e$yearsBack, covYearsBack=e$covYearsBack, considerRR=e$considerRR, UNbyUserIsNill=e$UNbyUserIsNill,
                          conditionalSplit=e$conditionalSplit, mask=e$mask, timestampB0=e$timestampB0, outputPathIni=e$outputPathIni,
                          ss=e$ss, ssMax=e$ssMax, nrows=e$nrows, nTrees=e$nTrees, setMtry=e$setMtry, method=e$method, coeff=e$coeff, runDate=e$runDate, 
                          createReport=e$createReport, intervals=e$intervals, runNo=e$runNo, dropTables=e$dropTables, createView=e$createView, 
                          projectStage=e$projectStage, evalRepAfterScoring=e$evalRepAfterScoring, alg=e$alg, modelPath=e$modelPath, e){
  
  tryCatch({
    #------SET PARAMETERS------#
    output <- SetModelParameters(model=model, e=e)
    AssignOutput(output, e)
        
    #-----CONNECT TO DRILL-----#
    e$dcon <- sergeant::drill_connection(host = "mapr-1")
    
    #------MAKE DB CONNECTIONS------#
    #output <- MakeDBConnections(e=e)
    #AssignOutput(output, e)
    #output <- CreateDBLog(e=e)
    #AssignOutput(output, e)
    
    #------SET PARALLEL PROCESSING / MAKE SPARK CONNECTION------#
    if (alg == "R_RF" & conditionalSplit){
      e$cl <- SetParallel(numCores=numCores, e=e)
    }
    
    # if (alg == "RSpark_RF"){
    #   e$sc <- MakeSparkConnection(e=e)
    # }
	 
    ###########################	     
    ###------MODELLING------###
    RunModelling(e=e)
    
    #------CREATE EVALUATION REPORT------#
    # Different functions are used for different models (because of the differences in the set of required reports).
    # That's why we do a flexible call of the function, providing the name of the function as a string and a list of function's parameters.
    if (createReport & !evalRepAfterScoring)
      do.call(paste0(model, "CreateEvaluationReport"), list(e=e))
    
    SaveImage(e=e)  
     
  	#########################	   
    ###------SCORING------###  
    RunScoring(e=e) 

    # Do filtering
    if (exists(paste0(model, "DoFiltering"))){
      #e$irdNumbers <- 
      output <- do.call(paste0(model, "DoFiltering"), list(e=e))
      AssignOutput(output, e)
      
      e$outDat[, "IS_FILTERED_OUT"] <- FALSE
      e$outDat[!(e$outDat[, "IRD_NUMBER"] %in% e$datScorFiltered[, "IRD_NUMBER"]), "IS_FILTERED_OUT"] <- TRUE
      
      e$outDat[, "IS_RIGHT_RETURN"] <- FALSE
      e$outDat[e$outDat[,"IRD_NUMBER"] %in% e$datScorRR[,"IRD_NUMBER"], "IS_RIGHT_RETURN"] <- TRUE
    }
      
    # Create evaluation reports for the RR model
    if (createReport & evalRepAfterScoring)
      do.call(paste0(model, "CreateEvaluationReport"), list(e=e))    
    
    
 		# Evaluation report (only for the OR & RP models)
    if (exists(paste0(model, "CreateEvalExcelReport"))){
      if (createExcelEvalRep){
        do.call(paste0(model, "CreateEvalExcelReport"), list(purificationOnly=purificationOnly, DataSelect=e$DataSelect, 
                                                            outputPath=e$outputPath, returnName=returnName, evalMainRes=e$evalMainResModelling, 
                                                            modelTargets=e$modelTargets, datList=e$datList, outDat=e$outDat, complemTargets=e$complemTargets,
                                                            estTh=e$estTh, prsTh=e$prsTh, thVal=e$thVal, shortNames=e$shortNames))
      }
    }
  
    
    ##############################	  
    ###------SAVE RESULTS------### 
    #SavingResults(outDat = if (sum(names(e$outDat) == "IS_FILTERED_OUT") != 0) {e$outDat[,-which(names(e$outDat) == 'IS_FILTERED_OUT')]} else {e$outDat}, e=e)
    SavingResults(outDat=e$outDat, e=e)
    
  },
  error = function(c){
    #add an error text in the log
    e$log <- paste0(e$log, SaveLogTime(), ": \n\nERROR: ", c)
    #write log in txt file
    writeLines(e$log, paste0(e$outputPath, "\\log_", e$returnName,".txt"))
    e$status <- "ERROR"
    SaveImage(e=e)
    # if connections to the database were opened, update the corresponding row in the LOG table, close all connections
    if (inherits(e$conn1, "DBIConnection")) { 
      dbGetQuery(e$conn1, "Rollback")
      UpdateLogTable(status=e$status, conn1=e$conn1, dbLogTable=e$dbLogTable, runId=e$runId, numRecords="NULL", log=e$log, imageName="NULL")
      dbDisconnect(e$conn)
      dbDisconnect(e$conn1)
      dbDisconnect(e$conn2)
    }
    # return environment options to the initial state
    if (e$status != "INITIALISATION"){
      SetTimeZones(e$status, oldORASDTZ=e$oldTZs[[1]], oldTZ=e$oldTZs[[2]])
	    parallel::stopCluster(e$cl)
	  }
    # close open file connections (if any)
    i <- 0
    i1 <- 1
    while (i1 > i) {
      tryCatch(
        {
          sink()
          i1 <- i1 + 1
        },
        warning = function(w){}
      )
      i <- i + 1
    }
    print(paste0("Error (", e$returnName," model): ", c))
    rm(e)
    return()
  }
  )
}
