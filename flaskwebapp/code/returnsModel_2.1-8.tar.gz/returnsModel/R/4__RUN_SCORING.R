
##########------SCORING------############
#' Prepare data for scoring and calculate the predictions 
#' 
#' \code{RunScoring} creates the scoring population and calculates predictions for interim and main targets.
#' 
#' This function includes the following main modelling steps:
#' \itemize{
#'  \item Prepare fields names (\code{\link{PrepareFieldsNames}} function)
#'  \item Select objects for scoring (\code{\link{RRSelectObjects}}, \code{\link{ORSelectObjects}} functions)
#'  \item Create covariates values (\code{\link{CreateValues}} function)
#'  \item Clean values (\code{\link{CleanValues}} function)
#'  \item Predict interim targets values (\code{\link{DoEvaluation}} function)
#'  \item Combine the interim values predictions and calculate main targets predictions (\code{\link{JoinSptittedResults}} function)
#' }
#' 
#' All function listed above are also used at the modelling stage, but with different parameters values.
#' The \code{RunScoring} function can be used in different returns models and for different return types.
#' 
#' @inheritParams BuildModel
#' @inheritParams DoEvaluation
#' @inheritParams FullModelling
#' @inheritParams CreateValues
#' @inheritParams MakeDBConnections
#' @inheritParams RunModelling
#' @inheritParams JoinSptittedResults
#' @inheritParams SetModelParameters
#'
#' @return The output of this function consists of the outputs of the functions listed in the \strong{Details} section.
#' 
#' @examples
#' \dontrun{
#'    RunScoring(e=e)
#' }
#' @export
RunScoring <- function(dat=e$dat, modelFits=e$modelFits, modelTargets=e$modelTargets, projectStage=e$projectStage, model=e$model, mask=e$mask, 
                      groupCovNames=e$groupCovNames, selectObjectsArgsScor=e$selectObjectsArgsScor, classificCovShort=e$classificCovShort,
                      clientStatusList=e$clientStatusList, nrows=e$nrows, conn=e$conn, modRetName=e$modRetName, covYearsBack=e$covYearsBack, 
                      returnName=e$returnName, timestampB0=e$timestampB0, covFields=e$covFields, targetFields=e$targetFields, ssMax=e$ssMax,
                      conditionalSplit=e$conditionalSplit, interimModelTargets=e$interimModeltargets, modelTargetsList=e$modelTargetsList,
                      targetFieldsShort=e$targetFieldsShort, covFieldsShort=e$covFieldsShort, participation=e$participation, rpdTextBack=e$rpdTextBack,
                      aggCovars=e$aggCovars, aggCovarsText=e$aggCovarsText, timeDiffers=e$timeDiffers, modelId=e$modelId, runId=e$runId, datList=e$datList,
                      log=e$log, e){  
    
  #------PREPARE FIELDS NAMES------#
  output <- PrepareFieldsNames(stage = "scoring", e=e)
  AssignOutput(output, e)
  
  
  #------SELECT OBJECTS FOR SCORING------#
  if (!(projectStage == "TEST" & dbExistsTable(conn, toupper(e$baseTable)))){
    do.call(paste0(toupper(model), "SelectObjectsNew"), selectObjectsArgsScor)
  } else {
    if (dim(dbGetQuery(conn, paste0("select * from ", e$baseTable)))[1] == 0)
      do.call(paste0(toupper(model), "SelectObjectsNew"), selectObjectsArgsScor)
  }
  # Delete some rows if it is a testing stage to reduce calculation time
  if (projectStage == "TEST"){
    startM <- Sys.time()
    stepName <- "Reduce the number of rows"
    ReduceRows(nrows=nrows, tableN=e$baseTable, conn=conn)
    e$log <- LogEdit(e$modRetName, stepName, e$log, startM)
  }
  
  
  #------CREATE VALUES------#
  fullCreation <- TRUE
  if (projectStage == "TEST" & dbExistsTable(conn, toupper(paste0(modRetName, "_FINAL_POP_", e$stage)))){
    if (dim(dbGetQuery(conn, paste0("select * from ", paste0(modRetName, "_FINAL_POP_", e$stage))))[1] != 0){
      fullCreation <- FALSE
    } 
  }
  output <- CreateValues(fullCreation=fullCreation, e=e)
  AssignOutput(output, e)
  if (length(dim(e$datScor)) == 0) stop("The scoring population is empty")
  
  
  #------CLEAN VALUES------#
  e$datScor <- CleanValues(dat=e$datScor, clientStatusList=eval(clientStatusList), e=e)
  

  #------PREPARE MODEL OUTPUT------#
  gc()
  output <- DoEvaluation(datTemp=e$datScor, e=e)
  AssignOutput(output, e)
  gc()
  output <- JoinSptittedResults(e=e)
  AssignOutput(output, e)
  
}
