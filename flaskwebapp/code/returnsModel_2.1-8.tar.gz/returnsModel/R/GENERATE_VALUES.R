

GenerateValues <- function(datBase=e$datBase){
  
  fea_nam<-c("INCOME_AFTER_EXPENSES_101",
    "OVERSEAS_TAX_CREDITS_107",
    "RESIDUAL_INCOME_TAX_108",
    "TAXABLE_INCOME_109",
    "TOTAL_LOSS_CARRIED_FWD_114",
    "TOTAL_TAX_CREDITS_115",
    "LOSS_CLAIMED_133",
    "LOSS_BROUGHT_FORWARD_136",
    "SHARE_OF_IMP_CREDITS_705",
    "INC_ALLOCN_TO_BENEFICIARY_714",
    "INC_ALLOC_TO_TRUSTEE_716",
    "OVERSEAS_INCOME_828",
    "OTHER_INCOME" ,
    "ESTATE_TRUST_EXS_CLAIM_100200"       )
  
  # Specify the features required (up to 15)
  feature_list<-c("RESIDUAL_INCOME_TAX_B0", "OTHER_INCOME_B0", "INC_ALLOCN_TO_BNFICIR_B0",
    paste0(fea_nam,"_B1"),paste0(fea_nam,"_B2"),paste0(fea_nam,"_B3"),paste0(fea_nam,"_B4"),paste0(fea_nam,"_B5"))
  
  n <- dim(datBase)[1]
  
  
  
  f <- function(x){
    rnorm(n, mean=0, sd=10000)
  }
  
  temp <- sapply(X=feature_list, FUN=f)
  
  dat <- cbind(datBase, temp)
  
  dat <- dat[, -which(names(dat) %in% c("AS_AT", "LOCATION_NUMBER"))]

  names(dat)[which(names(dat) == "RETURN_PERIOD_DATE")] <- "RETURN_PERIOD_DATE_BASE"
  
  dat[dat[, "INC_ALLOCN_TO_BNFICIR_B0"] < 0, "INC_ALLOCN_TO_BNFICIR_B0"] <- 
    -1 * dat[dat[, "INC_ALLOCN_TO_BNFICIR_B0"] < 0, "INC_ALLOCN_TO_BNFICIR_B0"]
  
  
  n <- 0.5 * n
  
  set.seed(11)
  r <- runif(n) > 0.5 
  
  dat[r, c("RESIDUAL_INCOME_TAX_B0", "OTHER_INCOME_B0", "INC_ALLOCN_TO_BNFICIR_B0")] <- 0
  
  dat
  
}




