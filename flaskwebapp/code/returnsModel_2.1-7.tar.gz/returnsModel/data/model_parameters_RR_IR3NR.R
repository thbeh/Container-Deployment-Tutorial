
# MODEL PARAMETERS FOR IR3NR RETURN TYPE 
# THESE PARAMETERS VALUES ARE ALLOWED TO BE CHANGED BY EXPERIENCED USERS

#### ----------------------- (1) TARGERS -------------------------- ####

# --- Outstanding returns values targets --- #

# A vector of targets keypoints 
targetList <- c("INCOME_AFTER_EXPENSES_101", "RESIDUAL_INCOME_TAX_108", "TOTAL_EXPENSES_CLAIMED_100026")
# Targets transformations (if any)
targetTransf = list()


# --- Low-value definition targets --- #

# Target(s) name(s)
modelTargetsList <- c()

# Low-value targets formulas
DataSelect = list()


#### ----------------------- (2) COVARIATES -------------------------####

# Groups of covariates
participation <- c(
		"FINALISATION CODE",           #do not delete!
		"INCOME TAX RETURN FIELDS",    #do not delete!
		"CLIENT STATUS",			   #do not delete!
		"TAX ASSESSED AND PAID",
		"TAX REGISTRATIONS", 
		"GST RETURN EXTRACT", 
		"ANNUALISED EMPLOYMENT DATA", 
		"EMS SCHEDULE INFORMATION",
		"TAX AGENTS",
		"INBOUND INFO ABOUT CESSATION")
		
# A vector of keypoints, which will be considered in the model as covariates of the "INCOME TAX RETURN FIELDS" group.
# Note: Lists of covariates for other covariates groups are hard-coded and can be changed only on request.
covList <- c("INCOME_AFTER_EXPENSES_101",
			"RESIDUAL_INCOME_TAX_108",
			"TOTAL_LOSS_CARRIED_FWD_114",
			"LOSS_CLAIMED_133",
			"LOSS_BROUGHT_FORWARD_136",
			"GROSS_EARNINGS_407",
			"NET_PROFIT_702",
			"TAX_ON_TAXABLE_INCOME_721",
			"OTHER_TAX_DEDUCTIONS_801",
			"TOTAL_ESTATE_TRUST_INCOME_806",
			"TOTAL_TAX_PAID_BY_TRUSTEES_807",
			"TOTAL_PARTNERSHIP_INCOME_808",
			"NET_RENTS_826",
			"OTHER_INCOME_827",
			"TOTAL_PARTNERSHIP_TAX_CRS_858",
			"TOTAL_EXPENSES_CLAIMED_100026",
			"WORK_IN_NZ_INDICATOR_100249",
			"TOTAL_REBATES_100255",
			"TOTAL_ACTIVE_LTC_INCOME_100792")

# Classification income keypoints covariates
classificCov <- c("WORK_IN_NZ_INDICATOR_100249")	

# Covariates transformations (if any)
covTransf = list()


#### ----------------------- (3) CUTOFF COEFF  -------------------------####
cutOffCoeff <- 0.85

