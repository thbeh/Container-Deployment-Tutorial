
##########------SELECT OBJECTS FOR OUTSTANDING RETURNS MODELLING AND SCORING------############
#'  Select returns for Outstanding Returns value modelling and scoring
#'  
#' \code{ORSelectObjects} creates the DB table with returns that will be part of the model building population
#'  (at the modelling stage) or the DB table with currently outstanding returns for which the scoring will be done (at the
#'  scoring stage).
#'  
#' At the modelling stage, the function selects returns for the model building population creation.
#' The procedure consists of two steps: 
#' \enumerate{
#'  \item Select all returns of the giving return type that \bold{\emph{(A)}} were outstanding (within the giving time frame), 
#'  \bold{AND \emph{(B)}} were subsequently filed or finalised as NILs.
#'  To simplify queries and reduce queries execution time, the condition \emph{(B)} was presented as the set of possible restrictions on the 
#'  \code{FINALISATION_CODE} and \code{FINALISED_BY} fields. Therefore, the condition (B) can be transformed to the following rules:
#'    \itemize{
#'      \item \code{FINALISATION_CODE = 'RL'}. Initially, we \bold{assume} that in this case returns were filed. However, not all returns that were 
#'        finalised with the 'RL' code have actually been filed. If the return was finalised as 'RL', but has not been filed, this return will 
#'        be eventually deleted from the modelling population during the population cleaning procedure (\code{\link{CleanValues}}).
#'      \item \code{FINALISATION_CODE = 'NR'} and the return was finalised not later than 5 years after it's due date.
#'        We assume that those returns really have nil value.
#'      \item \code{FINALISATION_CODE = 'UN'} and the return was finalised by a staff member after some review (\code{FINALISED_BY < 'A'}). 
#'        We assume that those returns really have nil value. However, they are selected only if \code{UNbyUserIsNill} is equal to TRUE.
#'       \item \code{FINALISATION_CODE = 'UN'} and the return was finalised as a result of the Right Returns process (\code{FINALISED_BY = 'SYSRR'}). 
#'        We assume that those returns really have nil value. However, they are selected only if \code{considerRR} is equal to TRUE. 
#'        Note: the current script does not take into account that in and before 2013 tax year IR6 and IR9 Right returns 
#'        weren't coded as UN by SYSRR and should be identified through CORRESPONDENCE_OUTBOUND table. It seems as not critical simplification, considering
#'        the decreasing importance of this information and default settings that do not suggest using of Right returns as Nil returns in the 
#'        Outstanding returns model (\code{considerRR = FALSE} by default to reduce the influence of possible errors in the Right Returns process
#'        on the Outstanding returns selection).
#'    }
#'  \item Remove duplicates (leave only unique pairs of IRD numbers and return period dates). It can be noticed that 
#'      the final base table contains TIMESTAMP field. At the modelling step in the Outstanding Returns model \code{timestamp} 
#'      is equal to the DATE_ACTUALLY_DUE of the corresponded return (thus, \code{timestamp} value may vary for different returns). 
#'      Timestamp is used for timestamping in covariates creation scripts to:
#'        \itemize{
#'          \item support reproducibility of the model results
#'          \item at the modelling stage imitate the situation of unavailability of data after a return due date, which is typical at the scoring stage
#'          (so that the model is usually not using the data which is not available during the scoring)
#'        }
#'  }
#'  
#'  At the scoring stage, the function selects currently outstanding returns for scoring their values.
#'  The procedure consists of two steps: 
#'  \enumerate{
#'    \item Select all currently outstanding returns of the given return type. Note: POLICING_PROFILES table is used
#'      instead of CURRENT_OUTSTANDING_RETURNS to provide the reproducibility of results.
#'    \item Remove duplicates (leave only unique pairs of IRD numbers and return period dates). It can be noticed that 
#'      the final base table contains TIMESTAMP field. It is used for timestamping in covariates creation scripts (to support reproducibility).
#'      At the scoring step \code{timestamp} is equal to the \code{timestampB0} (i.e. the date of calculation by default).
#'  }
#' 
#' This function is run within \code{\link{RunModelling}} and \code{\link{RunScoring}} functions. It can also be run independently.
#' 
#' @inheritParams MakeDBConnections
#' @inheritParams RunOutstandingReturns
#' @inheritParams PrepareFieldsNames
#' @inheritParams SetModelParameters
#' @param baseTable A name of the DB base table, which is used to store list of returns for the modelling / scoring population creation.
#' @param firstYear A numeric (year). The first tax year to consider in the modelling population (the oldest returns in the
#'  modelling populations were outstanding for that tax year). By default, it is depends on the \code{yearsBack} parameter value.
#'@param lastYear A numeric (year). The most recent tax year to consider in the modelling population. The parameter is equal
#'  to the previous tax year by default.
#'@param conn An Oracle connection to the Data Warehouse.
#'
#' @return A database table with returns selected for Outstanding returns value modelling / scoring.
#'
#' @examples
#' \dontrun{
#'   ORSelectObjects(modRetName='OR_IR3', returnName='IR3', firstYear=2009, lastYear=2015, e=e)
#' }
#'  
#' @export
ORSelectObjectsNew <- function(modRetName=e$modRetName, 
                            returnName=e$returnName, 
                            baseTable=e$baseTable,
                            projectStage=e$projectStage,
                            firstYear=as.character(as.numeric(eval(e$year)) - eval(e$yearsBack)), 
                            lastYear=as.character(as.numeric(eval(e$year)) - 1), 
                            conn=e$conn,
                            timestampB0=eval(e$timestampB0),
                            UNbyUserIsNill=e$UNbyUserIsNill,
                            considerRR=e$considerRR,
                            stage=e$stage, 
                            log=e$log, e){
  
  #assign("firstYear", as.character(as.numeric(year) - yearsBack), envir=e) # calculate the last return period year to consider
  #assign("lastYear", as.character(as.numeric(year) - 1), envir=e)    # calculate the most recent year for the target population
  
  startM <- Sys.time()
  
  tableName <- paste0(modRetName, "_base_temp_", stage)
  
  timestampB0 <- paste0(" to_date('", timestampB0,"', 'dd/mm/yyyy') ")
  
  if (stage == "modelling"){
    stepName <- "Select objects for outstanding returns modelling"
    # Step 1.
    # The first table created has duplicates that are resolved in a second step.
    # considerRR = FALSE (S068 for 2013 year and earlier???)
    sqlCode <- paste0("
      CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS           
          select distinct
            pp.ird_number,
            pp.return_period_date, ",
            if (toupper(returnName) == 'IR3ALL') {" 'IR3' as return_type, "} else {" pp.return_type, "},
            "--pp.date_originally_due,
            --pp.extension_code,
            --pp.extended_by,
            pp.date_actually_due,
            pp.date_applied,
            pp.finalisation_code,
            pp.finalised_by,
            pp.date_lodged,
            pp.date_created,
            pp.date_finalised,
            ret.date_processed
          from
            policing_profiles pp
            left join returns_keypoints_", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"IR3"} else {toupper(returnName)}," ir ON
              pp.ird_number=ir.ird_number
              and pp.return_period_date=ir.return_period_date
            left JOIN returns ret ON 
              ret.ird_number = ir.ird_number 
              AND ret.return_period_date = ir.return_period_date 
              AND ret.return_version_no = ir.return_version_no
              and ret.return_type = '", if (toupper(returnName) %in% c('IR3A', 'IR3ALL')) {"IR3"} else {toupper(returnName)}, "'
           where
            pp.return_type ", if (toupper(returnName) == 'IR3ALL') {"in ('IR3', 'IR3A') "} else {paste0("='", toupper(returnName),"' ")},"
            and pp.return_period_date >= to_date('31/03/", firstYear,"','DD/MM/YYYY') 
            and pp.return_period_date <= to_date('31/03/", lastYear,"','DD/MM/YYYY')
            and pp.date_actually_due < pp.date_finalised
            and (
              pp.finalisation_code='RL'
              or (pp.finalisation_code='NR' and add_months(pp.date_actually_due, 60) > pp.date_finalised) ",
              if (UNbyUserIsNill) {" or (pp.finalisation_code='UN' and pp.finalised_by < 'A') "},
              if (considerRR) {" or (pp.finalisation_code='UN' and pp.finalised_by='SYSRR') "},
            ") 
            and pp.date_applied < ", timestampB0," 
            and (pp.date_ceased > ", timestampB0," or pp.DATE_CEASED IS NULL)
        
    ")} else {
      stepName <- "Select objects for outstanding returns scoring"
      
      sqlCode <- paste0("
        CREATE GLOBAL TEMPORARY TABLE ", tableName," ON COMMIT PRESERVE ROWS AS
          select 
            pp.ird_number, 
            pp.return_period_date,
            pp.return_type,
            ", timestampB0," as timestamp,
            pp.date_applied,
            pp.date_created
          from
            policing_profiles pp
          where
            pp.return_type ", if (toupper(returnName) == 'IR3ALL') {"in ('IR3', 'IR3A') "} else {paste0("='", toupper(returnName),"' ")},"
            and pp.date_finalised is null
            and pp.finalisation_code = 'XX'
            and pp.date_actually_due < ", timestampB0,"
            and pp.date_applied < ", timestampB0,"
            and (pp.date_ceased > ", timestampB0," or pp.date_ceased is null)
        ")
      }
  
  CreateTable(conn, sqlCode, tableName)
    

  # Step 2.
  # Resolve duplicates (take rows with the most recent date applied and earliest timestamp value (date actually due)).  
  # Embedding the de-duplication increased runtime dramatically.
  tableName <- baseTable
  
  if (stage == "modelling"){
    sqlCode <- paste0(
      if (projectStage == "TEST"){
          paste0("CREATE TABLE ", tableName," AS ")
        } else {
          paste0("CREATE global temporary TABLE ", tableName," on commit preserve rows AS ")
        },
      "
      with a as
        (select
          case
            when ", timestampB0, " < to_date('07/07'||extract(year from sysdate), 'dd/mm/yyyy')
            then to_date('07/07'||extract(year from add_months(sysdate, -12)), 'dd/mm/yyyy')
            else to_date('07/07'||extract(year from sysdate), 'dd/mm/yyyy')
          end as stand_due_date
        from
          dual)
  
      select
        b.ird_number,
        b.return_period_date,
        b.return_type,
        b.date_lodged,
        b.date_applied,
        b.date_created,
        b.finalisation_code,
        b.finalised_by,
        b.date_finalised,
        b.date_processed,
        --b.date_originally_due,
        --b.extension_code,
        --b.extended_by,
        b.date_actually_due,
        ", timestampB0, " as date_run,
        a.stand_due_date,
        add_months(b.date_actually_due, months_between(", timestampB0,", a.stand_due_date)) as due_date_plus,
        case
          when nvl(b.date_processed, b.date_finalised) <= add_months(b.date_actually_due, months_between(", timestampB0,", a.stand_due_date))
          then nvl(b.date_processed, b.date_finalised)
          else add_months(b.date_actually_due, months_between(", timestampB0,", a.stand_due_date))
        end as timestamp
      from
        (select
          tmp.*,
          rank() over (partition by ird_number, return_period_date order by date_processed asc, date_applied desc, date_created desc) as rank_no
        from
          ", modRetName,"_BASE_TEMP_", stage," tmp) b,
        a
      where
        b.rank_no=1
    ")
  } else {
    
    sqlCode <- paste0(
      if (projectStage == "TEST"){
          paste0("CREATE TABLE ", tableName," AS ")
        } else {
          paste0("CREATE global temporary TABLE ", tableName," on commit preserve rows AS ")
        },
      "select * from
        (select
          tmp.*,
          rank() over (partition by ird_number, return_period_date order by date_applied desc, date_created desc) as rank_no
        from
          ", modRetName,"_BASE_TEMP_", stage," tmp)
      where
        rank_no=1
    ")
  }

  CreateTable(conn, sqlCode, tableName)
  
  res <- dbGetQuery(conn, paste0("SELECT 1 FROM ", tableName," GROUP BY ird_number, return_period_date HAVING count(1) > 1"))
  if (dim(res)[1] != 0){warning("Duplications in the base table! All duplicated records will be deleted!")}
  if (dim(res)[1] != 0){dbGetQuery(conn, paste0("delete from ", tableName," where (ird_number, return_period_date) in 
    (select ird_number, return_period_date from ", tableName," group by ird_number, return_period_date having count(1) > 1)"))}
  
  tableName <- paste0(modRetName, "_base_temp_", stage)
  dbGetQuery(conn, paste0("truncate table ", tableName))
  dbGetQuery(conn, paste0("drop table ", tableName))
  
  e$log <- LogEdit(e$modRetName, stepName, log, startM)
}
