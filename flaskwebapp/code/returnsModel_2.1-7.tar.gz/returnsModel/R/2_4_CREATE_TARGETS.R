

# if DataSelect list is not empty:
# Create additional classification targets (e.g. purification targets in the Outstanding returns model, low-risk Right Returns definition targets)
# input:
#   dat - the modelling population (covariates only)
#   modelTargetsList - a vector with names for additional classification targets
#   DataSelect - a list with formulas for additional classification targets calculation
# output:
#   dat - the modelling population (covariates and additional classification targets)
CreateModelTargets <- function(dat, modelTargetsList, DataSelect){
  
    for (i in 1:length(DataSelect)){
      dat[, modelTargetsList[i]] <- DataSelect[[i]](dat)
    }  
  dat
}

#---------------------------------------------------------------------------------------

##########------CREATE THE RIGHT RETURNS MODEL TARGET------############
#' Create the Right Returns model target(s)
#' 
#' \code{RRCreateModelTargets} creates the Right Returns model target(s) using either a standard definition of
#'  Right Returns or a customised definition (a low-value definition) of Right Returns.
#'  
#' If \code{DataSelect} list of customised Right Returns definitions is empty, the \bold{standard definition} of 
#'  Right Returns is used. According to the standard definition, Right Returns consist of:
#'  \itemize{
#'    \item Filed Nil returns (all target income tax keypoints simultaneously have Nil values)
#'    \item Not required returns (finalisation_code='NR' and return hasn't been filed)
#'    \item Uneconomical to pursue returns, recognised as Right returns in previous tax years 
#'      (finalisation_code='UN' and finalised_by='SYSRR' and return hasn't been filed)
#'  }
#' A target field "RR_PROB_NIL" is created. \code{TRUE} target value is assigned to all returns that 
#'  meet the standard Right Returns definition.
#'  
#' If \code{DataSelect} list of customised Right Returns definitions is \bold{not} empty, the \bold{low-risk
#'  definition} of Right Returns is used. According to the low-risk definition, Right Returns consist of:
#'  \itemize{
#'    \item Filed low-risk returns (all target income tax keypoints comply with customised low-risk returns definitions)
#'    \item Not required returns (finalisation_code='NR' and return hasn't been filed)
#'    \item Uneconomical to pursue returns, recognised as Right returns in previous tax years 
#'      (finalisation_code='UN' and finalised_by='SYSRR' and return hasn't been filed)
#'  }
#'  A target field "RR_PROB_NIL" (can be named differently according with set by user model parameters) is created. 
#'    \code{TRUE} target value is assigned to all returns that meet the low-risk Right returns definition.
#' 
#' This function is run within the \code{\link{RunModelling}} function, but also can be run separately. 
#' 
#' @inheritParams CreateValues
#' @inheritParams MakeDBConnections
#' @inheritParams RunModelling
#' @inheritParams SetModelParameters
#' @param dat A data frame. The model building population (covariates only).
#' @param purificationOnly Parameter is not used in the Right Returns model (it is kept for generalisation of functions among different models).
#'  
#' @return \code{dat} A data frame. The model building population (covariates and target(s)).
#' @return For the standard definition only:
#'  \itemize{
#'    \item \code{modelTargets} A vector with the model target name (\code{"RR_PROB_NIL_4"}).
#'    \item \code{interimModelTargets} The same as \code{modelTargets}, because the Right Returns model doesn't
#'      assume interim targets.
#'    \item \code{interimModelTargetsClassific} The same as \code{modelTargets}, because the Right Returns
#'      model's targets are always classification targets.
#' }
#'  
#' @examples
#'  \dontrun{
#'    # Use all parameters with default values
#'    RRCreateModelTargets(e=e)
#'  }
#'  
#' @export
RRCreateModelTargets <- function(dat=e$dat, targetFieldsShort=e$targetFieldsShort, modRetName=e$modRetName, DataSelect=e$DataSelect, 
                                purificationOnly=e$purificationOnly, modelTargetsList=e$modelTargetsList, log=e$log, e){
  startM <- Sys.time()
  stepName <- "Create model targets values"
  
  output=list()
  
  if (length(DataSelect) != 0) {
    
    dat <- CreateModelTargets(dat=dat, modelTargetsList=modelTargetsList, DataSelect=DataSelect)
    
  } else {
    
    output[["modelTargets"]] <- "RR_PROB_NIL_4"
    output[["interimModelTargets"]] <- "RR_PROB_NIL_4"
    output[["interimModelTargetsClassific"]] <- "RR_PROB_NIL_4"
    
    dat[, "RR_PROB_NIL_4"] <- TRUE
    
    for (i in 1:length(targetFieldsShort)) {
      target <- toupper(paste0(targetFieldsShort[[i]], "_B0"))
      dat[, "RR_PROB_NIL_4"] <- dat[, "RR_PROB_NIL_4"] & dat[ , target] == 0
    }
    
  }
  
  output[["dat"]] <- dat
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  output
}

#---------------------------------------------------------------------------------------

##########------CREATE THE OUTSTANDING RETURNS AND (OR) RETURNS PURIFICATION MODEL TARGET------############
#' Create the Outstanding Returns and (or) Returns Purification model target(s)
#' 
#' \code{ORCreateModelTargets} creates interim targets for the Outstanding Returns model and (or)
#'  classification targets for the Returns Purification model.
#'  
#' If \code{DataSelect} list of purification targets is not empty, Returns Purification targets are created
#'  according to formulas given by user. Names of targets are taken from the \code{modelTargetsList} vector.
#'  
#' If \code{purificationOnly} parameter is \bold{not} equal to \code{TRUE}, interim targets for the
#'  Outstanding Returns model are also created according to the \code{targetFieldsShort} vector. Four
#'  interim targets are created for each main target (some of them can be redundant and are deleted during the 
#'  population cleaning):
#'  \itemize{
#'    \item \emph{LABEL_NIL} - classification interim target indicating is a keypoint value nil or not nil
#'    \item \emph{LABEL} - classification interim target indicating is a keypoint value positive or negative
#'    \item \emph{POS} - continuous interim target with numeric positive keypoints values (empty otherwise)
#'    \item \emph{NEG} - continuous interim target with numeric negative keypoints values (empty otherwise)
#'  }
#' 
#' This function is run within the \code{\link{RunModelling}} function, but also can be run separately. 
#' 
#' @inheritParams CreateValues
#' @inheritParams MakeDBConnections
#' @inheritParams RunModelling
#' @inheritParams SetModelParameters
#' @inheritParams RunOutstandingReturns
#' @param dat A data frame. The model building population (covariates only).
#'  
#' @return \code{dat} A data frame. The model building population (covariates and target(s)).
#' @return For the Outstanding returns model:
#'  \itemize{
#'    \code{modelTargets} A vector with the model's main targets names (technically, this is a \code{targetFieldsShort} list
#'      transformed to a vector).
#'    \code{interimModelTargets} A vector of interim model targets names ("LABEL_NIL", "LABEL", "POS", "NEG")
#'    \code{interimModelTargetsClassific} A vector of classification interim model targets (only "LABEL_NIL" and "LABEL" interim targets)
#' }
#'  
#' @examples
#'  \dontrun{
#'    # Use all parameters with default values
#'    ORCreateModelTargets(e=e)
#'  }
#'  
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
ORCreateModelTargets <- function(dat=e$dat, targetFieldsShort=e$targetFieldsShort, modRetName=e$modRetName, DataSelect=e$DataSelect, 
                                purificationOnly=e$purificationOnly, modelTargetsList=e$modelTargetsList, 
                                covYearsBack=e$covYearsBack, log=e$log, e){
  
  startM <- Sys.time()
  stepName <- "Create model targets values"
  
  output = list()
  
  if (length(DataSelect) != 0) {
    dat <- CreateModelTargets(dat=dat, modelTargetsList=modelTargetsList, DataSelect=DataSelect)
  }
  
  if (!purificationOnly){
    DataSelect = list()  
    
    # LABEL_NIL
    DataSelect[[1]] <- function(dat, fieldB0, numModTarget){
      dat[dat[, fieldB0] == 0, numModTarget] <- "NIL"
      dat[dat[, fieldB0] != 0, numModTarget] <- "NOT NIL"
      dat
    }
        
    # LABEL
    DataSelect[[2]] <- function(dat, fieldB0, numModTarget){
      dat[dat[, fieldB0] > 0, numModTarget] <- "POS"
      dat[dat[, fieldB0] < 0, numModTarget] <- "NEG"
      dat
    }
        
    # POS
    DataSelect[[3]] <- function(dat, fieldB0, numModTarget){
      dat[dat[, fieldB0] > 0, numModTarget] <- dat[dat[, fieldB0] > 0, fieldB0]
      dat
    }
    
    # NEG
    DataSelect[[4]] <- function(dat, fieldB0, numModTarget){
      dat[dat[, fieldB0] < 0, numModTarget] <- dat[dat[, fieldB0] < 0, fieldB0]
      dat 
    }
    
    interimModelTargets <- c()
    field <- c()
    foreach (field = targetFieldsShort) %do% {
        
      fieldB0 <- paste0(field, "_B0")
        
      interimModelTargets <- c(interimModelTargets, paste0("LABEL_NIL_", field), paste0("LABEL_", field), paste0(field, "_POS"), 
                              paste0(field, "_NEG"))
        
      for (i in 1:4){
        dat <- DataSelect[[i]](dat, fieldB0, interimModelTargets[length(interimModelTargets)-(4-i)])
  	  }
    }
    
    interimModelTargetsClassific <- interimModelTargets[which(substr(interimModelTargets, 1, 5)=="LABEL")]
    interimModelTargetsClassific <- c(interimModelTargetsClassific, modelTargetsList)
    
    output[["modelTargets"]] <- paste0(c(targetFieldsShort, modelTargetsList))
    output[["interimModelTargets"]] <- c(interimModelTargets, modelTargetsList)
    output[["interimModelTargetsClassific"]] <- interimModelTargetsClassific
  }
  
  if (length(DataSelect) == 0 & purificationOnly){stop("No model targets identified")}
  
  # set classification targets as factors
  # Note: the function isn't applied to classification covariates fields at this step (only to targets fields),
  # because the imputation of missing values has not been done by that moment (it can be done only after conditional split).
  dat <- SetClassificFieldsAsFactors(datTemp=dat, dat=dat, classificTargets=interimModelTargetsClassific, 
                                       classificCovShort = c(), participation=c(), covYearsBack=covYearsBack)
  
  output[["dat"]] <- dat

  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  output
}
