
CreateInterimModelsHTML <- function(dat, modelFits, i=0, j=0, k=0, evalDataSet, filenameMod, outputPath, rfConfMatrix=FALSE, covarImpPlot, intTargets, intervals, 
                                    covarImp, alg, e){
  
  dir.create(outputPath, showWarnings=FALSE)
  filePath <- paste0(outputPath, filenameMod, ".rmd")
  file.create(filePath)
  sink(file=filePath, type = c("output"))
  
  #e$reportDataSet[[filenameMod]] <- evalDataSet
  
  cat("\n####**", filenameMod, "**\n\n---\n\n", sep="")
  
  if (covarImpPlot == "auto"){
    # var Imp plot
    cat("\n **_Variable importance plot_** \n",
      "```{r, echo=FALSE, warning=FALSE, fig.width=12,fig.height=10, fig.align='center'}\n",
      "     randomForest::varImpPlot(modelFits[[", i, "]][[", j,"]][[", k,"]])\n",
      "```\n\n", 
    sep="")
  }
  if (covarImpPlot == "manual"){
    impTop <- tail(covarImp[[i]][[j]][[k]], 20)
    
    cat("\n **_Variable importance plot_** \n", 
        "```{r, echo=FALSE, warning=FALSE, fig.width=6,fig.height=6, fig.align='center'}\n
          ggplot(data=impTop, aes(x=reorder(feature, importance), y=importance)) +
            geom_bar(width=0.4, stat = 'identity', position='dodge', alpha=0.6, color='white', fill='gray92') +
            geom_point(aes(colour=importance), size=2.8, pch=15) +
            scale_colour_gradient(low='#33ccff', high='#006997') +
            coord_flip() +
            PlotsTheme() +
            ylim(0, NA) + 
            ylab('') + 
            xlab('')
        ```\n", sep="")
  }
	
  # classification or regression?
  if (is.factor(dat[, intTargets])){
    #classification model
	
    predVal <- evalDataSet[, which(names(evalDataSet) %in% c("TRUE", "POS", "NIL"))]
    realVal <- evalDataSet[, 1]  
    
  	# RF model confusion matrix
  	if (rfConfMatrix){
  	  cat("**_Confusion matrix (cutOff=0.5)_**")
  	  conf <- round(modelFits[[i]][[j]][[k]]$confusion, 3)  
      print(knitr::kable(conf, align='r'))
  	}
  	
  	# Classification performance
    cat("\n\n", "**_Classification performance_**") 
    CalcPerformMeasures(alg, modelFits[[i]][[j]][[k]], testRes=evalDataSet, trainRes=data.frame(), trainPerf=FALSE)
    
    tab <- CreateClassifPerformTable(predVal=predVal, realVal=realVal, intervals=intervals)
    print(knitr::kable(tab, align='r'))
      
    # prepare data for plot1 and plot2
    names(evalDataSet)[1] <- "real_val"
    evalDataSet <- evalDataSet[!is.na(evalDataSet$real_val), ]
    evalDataSet$real_val_num <- 0
    evalDataSet[evalDataSet$real_val %in% c("NIL", "POS", "TRUE"), "real_val_num"] <- 1
    
    labels <- names(evalDataSet)
    n1 <- which(labels %in% c('POS', 'NIL', 'TRUE'))
    n2 <- CalcIndex(n1 - 1) + 1
    
    # prepare data from plot3
    df <- evalDataSet[, c(1, n1)]
    names(df) <- c("realVal", "predVal")
    
    if (levels(df$realVal)[1] %in% c("TRUE", "NIL", "POS")){
      col <- c("#328298", "#A68435")
    } else {
      col <- c("#A68435", "#328298")
    }
  
    if (dim(evalDataSet)[1] < 1000) {
      alpha1 <- 0.3
      alpha2 <- 0.5
    } else {
      alpha1 <- 0.02
      alpha2 <- 0.1
    }
    
    cat("\n", 
      "```{r, echo=FALSE, warning=FALSE, message=FALSE, fig.width=15, fig.height=5, fig.align='center'}\n    
        plot1 <- 
          ggplot(evalDataSet, aes(x=`", labels[n1],"`, y=real_val_num)) +
            geom_point(alpha = ", alpha1,", size=1.5, col = 'blue') +
            geom_abline(intercept=0, slope=1, color = '#A64535', size = 0.7) +
            geom_smooth(size = 1, col = '#328298') +
            PlotsTheme() + 
            ggtitle('Probability estimate accuracy') +
            xlab('CutOff') + ylab('Proportion') +
            coord_cartesian(xlim = c(-0.01, 1.01), ylim= c(-0.01, 1.01))
        
        cutOff <- 0.5
        tab <- as.data.frame(tab)
        intervals <- eval(intervals)
        tab$cutOff <- intervals[2:length(intervals)]

        plot2 <-
          ggplot(tab) +
            geom_area(aes(x=cutOff, y=`Cumulative % of ", labels[n2]," values`), fill='#FFE4A4', alpha=0.5, col='white') +
            geom_area(aes(x=cutOff, y=`Cumulative % of ", labels[n1]," values`), fill='#328298', alpha=0.5, col='white') +
            PlotsTheme() +
            ggtitle('Cumulative percent') +
            xlab('CutOff') + ylab('Part') 

        plot3 <- 
          ggplot(data=df, aes(x=predVal, y=realVal)) +  
            geom_jitter(aes(color=realVal), alpha=", alpha2,") + 
            geom_vline(xintercept=cutOff, color='#A64535', alpha=0.6) + 
            labs(title=paste0('Threshold at ', cutOff)) + 
            PlotsTheme() + 
            scale_colour_manual(values = col)

        gridExtra::grid.arrange(plot3, plot2, plot1, ncol=3)
        
      ```", sep="")
    
    # ROC curves and performance rates
    predVal <- evalDataSet[, which(names(evalDataSet) %in% c("TRUE", "POS", "NIL"))]
    realVal <- evalDataSet[, 1]  
    tab2 <- CreateClassifPerformTable2(predVal=predVal, realVal=realVal, intervals=intervals)
    cat("\n\n", "**_Classification performance measures_**") 
    print(knitr::kable(tab2[, -dim(tab2)[1]], align='r', row.names=FALSE))

    lvls <- levels(realVal)
    ind2 <- which(levels(realVal) %in% c("POS", "NIL", "TRUE"))
    ind1 <- CalcIndex(ind2)
    ord <- c(lvls[ind1], lvls[ind2])
    
    # create the object of the "prediction" type. Make sure that the order of target labels is correct
    test <- ROCR::prediction(predictions=predVal, labels=realVal, label.ordering = ord)
    
    # ROC curve (TP vs FP rates)
    v <- c(seq(0, 0.3, 0.1), 0.5, 0.7, seq(0.8, 1, by=0.1))
    rocPerf <- ROCR::performance(test, "tpr", "fpr")
    rocAuc <- ROCR::performance(test, "auc")
    auc <- paste0("AUC = ", round(rocAuc@y.values[[1]], digits=2))
    plotDat1 <- data.frame(FP=rocPerf@x.values[[1]], TP=rocPerf@y.values[[1]], Cut=rocPerf@alpha.values[[1]], Point=NA)
    # find the closest performance metrics for the certain cutOff values
    plotDat1[unlist(lapply(v, function(x){which.min(abs(plotDat1$Cut - x))})), "Point"] <- v
    plotDat1 <- plotDat1[plotDat1$Cut != Inf, ]
    
    # Recall vs Precision plot
    rocPre <- ROCR::performance(test, "prec", "rec")  
    plotDat2 <- data.frame(Recall=rocPre@x.values[[1]], Precision=rocPre@y.values[[1]], Cut=rocPre@alpha.values[[1]], Point=NA)
    plotDat2[unlist(lapply(v, function(x){which.min(abs(plotDat2$Cut - x))})), "Point"] <- v
    plotDat2 <- plotDat2[plotDat2$Cut != Inf, ]
    
    points <- unique(plotDat1$Point[!is.na(plotDat1$Point)])
    v <- v[which(v %in% points)]
    
    v1 <- v[order(v, decreasing=TRUE)]
    vv <- paste0("c('", paste(v1, collapse="', '"), "')")
    
    cat("\n", 
      "```{r, echo=FALSE, warning=FALSE, message=FALSE, fig.width=9, fig.height=4, fig.align='center'}\n    
        plot4 <- 
          ggplot(plotDat1, aes(x=FP, y=TP, col=TP)) + 
            ggtitle('ROC curve') +
            geom_abline(intercept=0, slope=1, col='gray48') +
            scale_colour_gradientn('', colours=rainbow(14)[1:11]) +
            geom_line(lwd=1.3) + 
            geom_point(data=plotDat1[!is.na(plotDat1$Point), ], aes(x=FP, y=TP), fill='white', alpha=1, pch=21, size=2.5) +
            geom_text(data=plotDat1[!is.na(plotDat1$Point), ], aes(x=FP, y=TP), label=", vv,", hjust=1.2, vjust=-0.9, size=3, col='black') +
            geom_polygon(aes(x=X, y=Y), data=data.frame(X=c(0.76, 1, 1, 0.76),Y=c(0, 0, 0.1, 0.1)), fill='white', inherit.aes=FALSE) +
            annotate('text', x=0.98, y=0.05, label='", auc, "', hjust=1) +
            PlotsTheme() +
            scale_x_continuous('False Positive Rate (FP)', limits=c(0, 1)) +
            scale_y_continuous('True Positive Rate (TP)', limits=c(0, 1))

        plot5 <- 
          ggplot(plotDat2, aes(x=Precision, y=Recall, col=Precision)) + 
            ggtitle('Precision vs Recall') +
            scale_colour_gradientn('', colours=rainbow(14)[1:11]) +
            geom_line(lwd=1.3) + 
            geom_point(data=plotDat2[!is.na(plotDat2$Point), ], aes(x=Precision, y=Recall), fill='white', alpha=1, pch=21, size=2.5) +
            geom_text(data=plotDat2[!is.na(plotDat2$Point),], aes(x=Precision, y=Recall), label=", vv,", hjust=1.5, vjust=0, size=3, col='black') +
            PlotsTheme() +
            scale_x_continuous('Precision (TP / (TP + FP))', limits=c(0, 1)) +
            scale_y_continuous('Recall (TP)', limits=c(0, 1))

        gridExtra::grid.arrange(plot4, plot5, ncol=2)
        
      ```", sep="")
    
  } 

  if (is.numeric(dat[, intTargets])){
    #regression model
	  
    evalDataSet <- as.data.frame(evalDataSet)
    names(evalDataSet) <- c("real_value", "pred_value")
    evalDataSet$res_val <- evalDataSet$pred_value - evalDataSet$real_value
    evalDataSet <- evalDataSet[!is.na(evalDataSet$real_value), ]
   
  	# Predictive performance table
    predVal <- evalDataSet[, "pred_value"]
    realVal <- evalDataSet[, "real_value"] 
    resVal <- evalDataSet[, "res_val"]
    
    cat("\n", "**_Predictive performance_**")
    CalcPerformMeasures(alg, modelFits[[i]][[j]][[k]], testRes=evalDataSet, trainRes=data.frame(), trainPerf=FALSE)
    
    tmp <- format(round(cbind(summary(realVal)[1:6], summary(predVal), summary(resVal)[1:6]),0), big.mark=",")
    rownames(tmp) <- names(summary(predVal))
    tab <- matrix(tmp, nrow=dim(tmp)[1], ncol=3, dimnames=list(rownames(tmp), c("Real values", "Estimated values", "Residuals")))
    print(knitr::kable(tab, align='r'))
  	
  	# Predictive performance plot
    qMinReal <- quantile(realVal, 0.01)
    qMaxReal <- quantile(realVal, 0.99)
    qMinPred <- quantile(predVal, 0.01)
    qMaxPred <- quantile(predVal, 0.99)
    qMin <- min(qMinReal, qMinPred)
    qMax <- max(qMaxReal, qMaxPred)
    
    qMinResid <- quantile(resVal, 0.01)
    qMaxResid <- quantile(resVal, 0.99)
    qResid <- max(abs(qMinResid), abs(qMaxResid))
    
    
    cat("\n\n**_Predictive performance plots_**\n",
      "```{r, echo=FALSE, warning=FALSE, message=FALSE, fig.width=9, fig.height=9, fig.align='center'}
        
        plot1 <- 
          ggplot(evalDataSet) +
            geom_density(aes(x=real_value), fill='#FFD4A4', col='white', alpha=1) +
            geom_density(aes(x=pred_value), fill='#328298', col='white', alpha=0.4) +
            PlotsTheme() +
            xlim(qMin, qMax) +
            ggtitle('Densities of real and predicted values ') +
            xlab('')

        plot2 <- 
          ggplot(evalDataSet, aes(x=real_value, y=pred_value)) +
            geom_point(col='#328298', alpha=0.3, size=2.5) +
            geom_abline(intersect=0, slope=1, col='#A64535', alpha=0.7, size=0.7) +
            PlotsTheme() +
            #xlim(qMin, qMax) +
            #ylim(qMin, qMax) +
            ggtitle('Predicted vs real values') +
            coord_cartesian(xlim=c(min(0, qMin), max(0, qMax)), ylim=c(min(0, qMin), max(0, qMax)))
            
        plot3 <- 
          ggplot(evalDataSet, aes(x=res_val)) +
            geom_histogram(fill='#99D8EA', col='white', alpha=1) +
            PlotsTheme() +
            #coord_cartesian(xlim=c(qMin, qMax)) +
            ggtitle('Histogram of residuals') +
            xlim(-1 * qResid, qResid)

        gridExtra::grid.arrange(plot1, plot2, plot3, ncol=2, nrow=2)
        
      ```\n\n", 
    sep="")
  }
  
  cat(
    "\n<style type='text/css'>
      table {
        table-layout: fixed;
      } 
      th {
        background-color: rgb(153, 217, 234);
        align: center;
      }
      tr:nth-child(even){
        background: rgb(226, 245, 250)
      }
    </style>", sep=""
  )
  
  # close connection
  sink()
  # render 'rmd' to 'html' file
  #rmarkdown::render(filePath, output_dir=outputPath, intermediates_dir=outputPath, quiet=FALSE) 
  rmarkdown::render(filePath, quiet=TRUE) 
  file.remove(filePath)
}


#---------------------------------------------------------------------------------------------------

CreateMainModelsHTML <- function(i=0, j=0, evalDataSet, filenameMod, outputPath){
  
  dir.create(outputPath, showWarnings=FALSE)
  filePath <- paste0(outputPath, filenameMod, ".rmd")
  file.create(filePath)
  sink(file=filePath, type = c("output"))
  
  #e$reportDataSet[[filenameMod]] <- evalDataSet
  
  cat("\n####**", filenameMod, "**\n\n---\n\n", sep="")
  
#   cat("The part of entities from the evaluation sample with the estimation error less than 15% or an absolute value of the estimation error less than:", "\n\n",
#       "* $500  - ", Calc(evalDataSet, k1=500), "% ", "\n",
#       "* $1,000  - ", Calc(evalDataSet, k1=1000), "% ", "\n",
#       "* $5,000  - ", Calc(evalDataSet, k1=5000), "% ", "\n",
#       "* $10,000  - ", Calc(evalDataSet, k1=10000), "% ", "\n",
#       "* $20,000  - ", Calc(evalDataSet, k1=20000), "% ", "\n",
#   sep = "")

  cat("\n", "**_Confusion matrix_**", "\n", sep = "")
  r <- evalDataSet
  mT <- matrix(c(
    # NEG total number
    length(r[r[,1]<0,2]),
    # NEG predicted as NEG
    length(r[r[,1]<0 & r[,2]<0,2]),
    # NEG predicted as NIL
    length(r[r[,1]<0 & r[,2]==0,2]),
    # NEG predicted as POS
    length(r[r[,1]<0 & r[,2]>0,2]),
    # NIL total number
    length(r[r[,1]==0,2]),
    # NIL predicted as NEG
    length(r[r[,1]==0 & r[,2]<0,2]),
    # NIL predicted as NIL
    length(r[r[,1]==0 & r[,2]==0,2]),
    # NIL predicted as POS
    length(r[r[,1]==0 & r[,2]>0,2]),
    # POS total number
    length(r[r[,1]>0,2]),
    # POS predicted as NEG
    length(r[r[,1]>0 & r[,2]<0,2]),
    # POS predicted as NIL
    length(r[r[,1]>0 & r[,2]==0,2]),
    # POS predicted as POS
    length(r[r[,1]>0 & r[,2]>0,2])), nrow = 4, ncol = 3, dimnames = list(c("Total real number","Estimated as NEG","Estimated as NIL","Estimated as POS"), c("Real NEG","Real NIL","Real POS")))
  
  mText <- format(mT, big.mark=",", trim=TRUE)
  # Add values in percent  
  m <- mT  
  for (h in 2:4) {
    for (g in 1:3){
      m[h, g] <- paste0(mText[h, g], " _(", round(mT[h, g]/mT[1, g]*100,0), "%)_")
      if (h == g + 1) {m[h, g] <- paste0("__", m[h, g], "__", collapse="")}
    }
  }
  m[1, ] <- mText[1, ]
  # Delete 'NEG' rows in a matrix (if target values are always POS or NIL)
  if (sum(mT[,1])==0) {m <- m[-2,-1]}
  # Delete 'POS' rows in a matrix (if values are always NEG or NIL)
  if (sum(mT[,3])==0) {m <- m[-4,-3]}
  
  print(knitr::kable(m, align='r'))
  
  #Matrix of medians (comparison of real and estimated values)
  mTReal <- matrix(c(
    # real median - NEG predicted as NEG
    round(median(r[r[,1]<0 & r[,2]<0,1]),0),
    # real median - NEG predicted as NIL
    round(median(r[r[,1]<0 & r[,2]==0,1]),0),
    # real median - NEG predicted as POS
    round(median(r[r[,1]<0 & r[,2]>0,1]),0),
    # real NEG median
    #round(median(r[r[,1]<0,1]),0),
    # real median - NIL predicted as NEG
    round(median(r[r[,1]==0 & r[,2]<0,1]),0),
    # real median - NIL predicted as NIL
    round(median(r[r[,1]==0 & r[,2]==0,1]),0),
    # real median - NIL predicted as POS
    round(median(r[r[,1]==0 & r[,2]>0,1]),0),
    # real NIL median 
    #round(median(r[r[,1]==0,1]),0),
    # real median - POS predicted as NEG
    round(median(r[r[,1]>0 & r[,2]<0,1]),0),
    # real median - POS predicted as NIL
    round(median(r[r[,1]>0 & r[,2]==0,1]),0),
    # real median - POS predicted as POS
    round(median(r[r[,1]>0 & r[,2]>0,1]),0)),
    nrow = 3, ncol = 3, dimnames = list(c("Estimated as NEG","Estimated as NIL","Estimated as POS"), c("Real NEG","Real NIL","Real POS")))
  
  mTEst <- matrix(c(
    # estimated median - NEG predicted as NEG
    round(median(r[r[,1]<0 & r[,2]<0,2]),0),
    # estimated median - NEG predicted as NIL
    round(median(r[r[,1]<0 & r[,2]==0,2]),0),
    # estimated median - NEG predicted as POS
    round(median(r[r[,1]<0 & r[,2]>0,2]),0),
    # estimated median - NIL predicted as NEG
    round(median(r[r[,1]==0 & r[,2]<0,2]),0),
    # estimated median - NIL predicted as NIL
    round(median(r[r[,1]==0 & r[,2]==0,2]),0),
    # estimated median - NIL predicted as POS
    round(median(r[r[,1]==0 & r[,2]>0,2]),0),
    # estimated median - POS predicted as NEG
    round(median(r[r[,1]>0 & r[,2]<0,2]),0),
    # estimated median - POS predicted as NIL
    round(median(r[r[,1]>0 & r[,2]==0,2]),0),
    # estimated median - POS predicted as POS
    round(median(r[r[,1]>0 & r[,2]>0,2]),0)),
    nrow = 3, ncol = 3, dimnames = list(c("Estimated as NEG","Estimated as NIL","Estimated as POS"), c("Real NEG","Real NIL","Real POS")))
  
  mTReal <- format(mTReal, big.mark=",")
  mTEst <- format(mTEst, big.mark=",")
  
  # Combine matrices with real and estimated medians  
  m <- matrix(nrow = 6, ncol = 4)
  for (h in 1:3){
    for (g in 2:4){
      m[h * 2 - 1, 1] <- "real median:       "
      m[h * 2, 1] <- "est. median:        "
      m[h * 2 - 1, g] <- mTReal[h, g-1]
      m[h * 2, g] <- mTEst[h, g-1]
    }
  }
  
  dimnames(m) <- list(c("Estimated as NEG","", "Estimated as NIL","","Estimated as POS", ""), c("", "Real NEG","Real NIL","Real POS"))
  
  # Delete 'NEG' rows in a matrix (if values are always POS or NIL)
  if (sum(mT[,1])==0) {m <- m[-(1:2),-2]}
  # Delete 'POS' rows in a matrix (if values are always NEG or NIL)
  if (sum(mT[,3])==0) {m <- m[-(5:6),-4]}
  
  cat("\n", "**_Comparison of real and estimated medians values_**", "\n", sep = "")
  print(knitr::kable(m, align='r'))
  cat("\n\n ***\n\n")  
  
  
  cat("\n", "**_Statistics about the real values, estimated values and residuals_**", "\n", sep="")
  tmp1 <- format(round(summary(evalDataSet[,1]),0), big.mark=",")
  tmp2 <- format(round(summary(evalDataSet[,2]),0), big.mark=",")
  tmp3 <- format(round(summary(evalDataSet[,2]-evalDataSet[,1]),0), big.mark=",")
  # use kable function to create tables
  print(knitr::kable(matrix(data=cbind(tmp1, tmp2, tmp3), nrow=6, ncol=3, dimnames=list(names(tmp1),c("Real values", "Predicted values", "Residuals (pred - real)"))), align='r'))
  
  
  cat("\n\n**_Predictive performance plots_**\n",
      "```{r, echo=FALSE, warning=FALSE, message=FALSE, fig.width=9, fig.height=4.5, fig.align='center'}
      xx <- evalDataSet
      xxNotNil <- xx[xx$real_value != 0, ]
      
      x1 <- xxNotNil[ , 1]
      x2 <- xxNotNil[ , 2]
      x <- data.frame('Estimated value'=x2, 'Real value'=x1)
      d <- reshape2::melt(x)

      q1Min <- min(quantile(x1, prob=0.05), quantile(x2, prob=0.05))
      q1Max <- max(quantile(x1, prob=0.95), quantile(x2, prob=0.95))

      plot1 <- 
        ggplot(d) + 
          ggtitle('Distribution of Not Nil target values \n and corresponded estimated values') + 
          geom_density(aes(x=value, y=..count.., fill=variable), alpha=0.45, color='white') + 
          PlotsTheme2() +
          guides(fill = guide_legend(title=NULL)) +
          xlim(q1Min, q1Max)
        
      xxNil <- xx[xx$real_value == 0, ]
      x3 <- xxNil[ , 2]
      x <- data.frame('Estimated value'=x3)
      d <- reshape2::melt(x)

      q2Min <- quantile(x3, prob=0.05)
      q2Max <- quantile(x3, prob=0.95)

      plot2 <- 
        ggplot(d) + 
          ggtitle('Distribution of estimated values \n for corresponded Nil target values') + 
          geom_density(aes(x=value, y=..count.., fill=variable), alpha=0.5, color='white') + 
          PlotsTheme2() +
          guides(fill = guide_legend(title=NULL)) +  
          xlim(q2Min, q2Max)

      gridExtra::grid.arrange(plot1, plot2, ncol=2)
      ```\n\n", 
      sep="")
  
  cat(
    "<style type='text/css'>\n",
    "  th {\n",
    "    background-color: rgb(153, 217, 234);\n",
    "    align: center;\n",
    "  }\n",
    "  tr:nth-child(even){\n",
    "    background: rgb(226, 245, 250)\n",
    "  }\n",
    "</style>\n",
    sep="")
  
  # Close connection
  sink()
  # render 'rmd' to 'html' file
  #rmarkdown::render(input=filePath, output_dir=outputPath, quiet=TRUE) 
  rmarkdown::render(filePath, quiet=TRUE)
  file.remove(filePath)
}


#---------------------------------------------------------------------------------------------

Calc <- function(evalDataSet, k1, k2=15){
  error1 <- abs(evalDataSet[,2] - evalDataSet[,1]) <= k1
  error2 <- abs(evalDataSet[,2] / ((evalDataSet[,1] + evalDataSet[,2]) / 2) * 100 - 100) <= k2
  error2[is.na(error2)] <- TRUE
  
  result <- round(sum(error1 | error2) / dim(evalDataSet)[1] * 100, 0)
  result
}

#----------------------------------------------------------------------------------------------

CreateClassificationExcelReport <- function(returnName, outputPath, modelTargets, modelTargetsList, datList, evalRes, evalInterim, intervals, 
  sumReport, outDat=NULL){

  if (sum(list.files(path=paste0(getwd(), "/inst/")) == "Classification_purification.xlsm") > 0){
    filePath <- paste0(getwd(), "/inst/Classification_purification.xlsm")
  } else {
    filePath <- system.file("Classification_purification.xlsm", package="returnsModel")
  }
  
  wb <- xlsx::loadWorkbook(filePath)    # Load the xlsm file
  newWBname <- paste0(outputPath, "Purification_performance_", returnName, ".xlsm")
  if (file.exists(newWBname)) file.remove(newWBname)
  
  for (j in 1:length(modelTargets)){
    if (modelTargets[j] %in% modelTargetsList){
      
      for (i in 1:length(datList)){
        predVal <- evalRes[[i]][[j]][[1]][, "TRUE"]
        realVal <- evalRes[[i]][[j]][[1]][, 1] 
        
        tab <- CreateClassifPerformTable(predVal=predVal, realVal=realVal, intervals=intervals)
        tab <- as.data.frame(tab[, c(1:4)], stringsAsFactors=FALSE)
        for (z in c(1:4)) {tab[, z] <- as.numeric(tab[, z])} 
        
        sName <- paste0("pop", i, "_", modelTargets[j])
        newSheet <- xlsx::createSheet(wb=wb, sheetName=substr(sName, 1, min(31, nchar(sName))))
        
        xlsx::addDataFrame(x=tab, sheet=newSheet, startRow=5, startColumn=1, row.names=TRUE, col.names=TRUE)  
      }
    
      if (sumReport){
        predVal <- evalInterim[[j]][[1]][, "TRUE"]
        realVal <- evalInterim[[j]][[1]][, 1]
          
        tab <- CreateClassifPerformTable(predVal=predVal, realVal=realVal, intervals=intervals)
        tab <- as.data.frame(tab, stringsAsFactors=FALSE)
        for (z in c(1:4)) {tab[,z] <- as.numeric(tab[,z])} 
        
        sName <- paste0("ALL_POP_", modelTargets[j])
        newSheet <- xlsx::createSheet(wb=wb, sheetName=substr(sName, 1, min(31, nchar(sName))))
          
        xlsx::addDataFrame(x=as.data.frame(tab), sheet=newSheet, startRow=5, startColumn=1, row.names=TRUE, col.names=TRUE)
        
        
        sName <- paste0("ALL_SCOR_", modelTargets[j])
        newSheet <- xlsx::createSheet(wb=wb, sheetName=substr(sName, 1, min(31, nchar(sName))))
          
        tt <- c()
        n <- eval(intervals)
        
        for (i in 1:length(n)){
          tt[i] <- sum(outDat$RR_PROB_NIL_4 >= round(n[i], 2) & !outDat$IS_FILTERED_OUT)
        }
        
        xlsx::addDataFrame(x=t(t(tt)), sheet=newSheet, startRow=6, startColumn=10, row.names=FALSE, col.names=FALSE)
        
      }
    xlsx::saveWorkbook(wb, newWBname)
    }
  }
}

#------------------------------------------------------------------------------------------------

CreateClassifPerformTable <- function(predVal, realVal, intervals){
  prob <- cut(predVal, eval(intervals), right=FALSE, include.lowest=TRUE)
  #tab <- format(table(prob, realVal), big.mark=",")
  tab <- table(prob, realVal)
  tab1 <- round(prop.table(tab, 1), 4)
  tab2 <- prop.table(tab, 2) * 100
  tab <- cbind(tab, tab1, tab2)
  
  labels <- colnames(tab)[1:2]
  n <- which(labels %in% c("POS", "NIL", "TRUE"))
  tab <- cbind(tab, NA, NA)
  if (n == 1){
    tab[, 7] <- round(cumsum(tab[, 5]), 2)
    tab[, 8] <- round(100 - cumsum(tab[, 6]) + tab[, 6], 2)
  } else {
    tab[, 7] <- 100 - cumsum(tab[, 5]) + tab[, 5]
    tab[, 8] <- cumsum(tab[, 6])
  }
  tab[, 5:8] <- round(tab[, 5:8], 2)
  
  colnames(tab)[1:2] <- paste0("Number of ", labels, " values")
  colnames(tab)[3:4] <- paste0("Part of ", labels, " values")
  colnames(tab)[5:6] <- paste0("% of total ", labels, " values")
  colnames(tab)[7:8] <- paste0("Cumulative % of ", labels, " values")
  
  tab
}

CreateClassifPerformTable2 <- function(predVal, realVal, intervals){
  prob <- cut(predVal, eval(intervals), right=FALSE, include.lowest=TRUE)
  tab <- table(prob, realVal)
  
  tab <- cbind(tab, NA, NA)
  tab[, 3] <- cumsum(tab[, 1])
  tab[, 4] <- cumsum(tab[, 2])
  tab[, 3] <- sum(tab[, 1]) - tab[, 3]
  tab[, 4] <- sum(tab[, 2]) - tab[, 4]
  colnames(tab)[3:4] <- c("NIL est NIL", "NOT NIL est NIL")
  
  labels <- colnames(tab)[1:2]
  n <- which(labels %in% c("POS", "NIL", "TRUE"))
  tab <- cbind(tab, NA, NA, NA)
  if (n == 1){
    tab[, 5] <- round(tab[, 3] / sum(tab[, 1]) * 100, 2)
    tab[ ,6] <- round(tab[, 4] / sum(tab[, 2]) * 100, 2)
    tab[, 7] <- round(tab[, 4] / (tab[, 3] + tab[, 4]) * 100, 2)
  } else {
    tab[, 5] <- round(tab[, 4] / sum(tab[, 2]) * 100, 2)
    tab[ ,6] <- round(tab[, 3] / sum(tab[, 1]) * 100, 2)
    tab[, 7] <- round(tab[, 3] / (tab[, 3] + tab[, 4]) * 100, 2)
  }
  colnames(tab)[5:7] <- c("TP", "FP", "FDR")
  
  cbind("Probability cut-off"=eval(intervals)[-1], tab[, 5:7])
}

#------------------------------------------------------------------------------------------------

ORCreateEvalExcelReport <- function(purificationOnly, DataSelect, outputPath, returnName, evalMainRes, modelTargets, datList, outDat, complemTargets, 
                                  estTh, prsTh, thVal, shortNames){
  
  if (!(!purificationOnly & length(DataSelect) != 0)){
    return("Function is not designed for this model type")
  } else {
  
    if (sum(list.files(path=paste0(getwd(), "/inst/")) == "Evaluation_template.xlsm") > 0){
      filePath <- paste0(getwd(), "/inst/Evaluation_template.xlsm")
    } else {
      filePath <- system.file("Evaluation_template.xlsm", package="returnsModel")
    }
    
    wb <- xlsx::loadWorkbook(filePath)
      
    for (k in c(1:length(complemTargets))){
      
      t1 <- which(modelTargets == complemTargets[[k]][1])
      t2 <- which(modelTargets == complemTargets[[k]][2])
      
      shortName <- shortNames[k]
      
      #evalMainResJoint <- list()
      for (i in c(1:length(datList))){
        evalMainResJoint <- cbind(evalMainRes[[i]][[t1]], evalMainRes[[i]][[t2]])
        
        ll <- c()
        for (l in c(1:dim(evalMainResJoint)[2])){
          if (names(evalMainResJoint)[l] == "real_value" & is.factor(evalMainResJoint[, l])){
            ll <- c(ll, l)
          }
        }
        d <- evalMainResJoint[, -ll]
       
        real <- which(names(d) == "real_value")
        est <- which(substr(names(d), 1, 4) == "EST_")
        prs <- which(substr(names(d), 1, 5) == "PROB_")
        
        res <- data.frame()
        
        for (n in estTh[[k]]){
          for (p in prsTh){
    	      for (r in prsTh){
              
              # selected
    	        selected <- d[d[, est] > n & d[, prs[1]] <= p & d[, prs[2]] <= r, ]
              
              # real val > th_val
    	        realPos <- d[d[, real] > thVal[k], ]
              
              # selected and real val > th_val
    	        selectedPos <- selected[selected[, real] > thVal[k],]
              
              # real val <= th_val
    	        realNeg <- d[d[, real] <= thVal[k], ]
              
              # selected and real val <= th_val
    	        selectedNeg <- selected[selected[, real] <= thVal[k], ]
              
              TP <- round(dim(selectedPos)[1] / dim(realPos)[1] * 100,2)
              FP <- round(dim(selectedNeg)[1] / dim(realNeg)[1] * 100,2)
              FDR <- round(dim(selectedNeg)[1] / dim(selected)[1] * 100, 2)
              
              selectedScoring <- sum(outDat$POPULATION_NO==i & round(outDat[, names(d)[est]], 2) > n & round(outDat[, names(d)[prs[1]]], 2) <= p & 
                  round(outDat[, names(d)[prs[2]]], 2) <= r)
              scoringPopTotal <- sum(outDat$POPULATION_NO == i)
              selectedScoringPart <- round(selectedScoring / scoringPopTotal * 100, 2)
                
              res <- rbind(res, c(n, p, r, TP, FP, FDR, selectedScoring, selectedScoringPart))  
  		      }
          }
        }
        
        names(res) <- c("n", "p", "r", paste0("TP", thVal[k]), paste0("FP", thVal[k]), paste0("FDR", thVal[k]), "selectedScoring", "selectedScoringPart")
        
        newSheet <- xlsx::createSheet(wb=wb, sheetName=paste0(shortName, "_pop", i))
        xlsx::addDataFrame(x=res, sheet=newSheet, startRow=1, startColumn=1, row.names=FALSE, col.names=TRUE)
      }
    }
    
    xlsx::saveWorkbook(wb, paste0(outputPath, "Evaluation_", returnName, ".xlsm"))
  }
}

#-----------------------------------------------------------------------------------

PlotsTheme <- function(){
  theme(
    legend.position='none', 
    panel.background = element_rect(fill = 'white', colour = 'gray79'), 
    axis.line = element_line(colour = 'gray87'), 
    panel.grid.major = element_line(colour = 'gray91'), 
    axis.title = element_text(colour = 'gray48', size=5), 
    axis.text = element_text(size=5),
    title = element_text(color = 'gray35', size=7, hjust=0, face='bold')
  )
}

PlotsTheme2 <- function(){
  theme(
    legend.position='bottom', 
    legend.text = element_text(colour='gray48', size=8), 
    panel.background = element_rect(fill = 'white', colour = 'gray79'), 
    axis.line = element_line(colour = 'gray87'), 
    panel.grid.major = element_line(colour = 'gray91'), 
    axis.title = element_text(colour = 'gray48', size=8, face='plain', hjust=0.5), 
    axis.text = element_text(size=8),
    title = element_text(color = 'gray35', size=9, hjust=0, face='italic')
  )
}

