
# PREPARE CLASSIFICATION FIELDS FOR MODELLING
#' Transform classification fields into factors
#' 
#' \code{SetClassificFieldsAsFactors} converts classification fields in the datasets to factors with levels.
#' 
#' A dataset fields should be prepared to the modelling and prediction operations. One of requirements of 
#'  the selected modelling technique (the Random Forest algorithm) is that classification targets and classification covariates 
#'  must be presented as factors with levels. The function also guarantee that fields in the scoring dataset
#'  do not have levels that corresponded fields in the modelling dataset do not have. The solution that was
#'  used is introduction of an additional "Other" level in all classification fields.
#' 
#' @inheritParams BuildModel
#' @inheritParams RunModelling
#' @inheritParams FullModelling
#' @inheritParams SetModelParameters
#' @param datTemp A data set with classification fields.
#' @param classificTargets A vector with fields names. It should contain names of classification interim targets.
#' 
#' @return The dataset with classification targets and (or) covariates fields converted to factor fields with levels 
#'  (including the additional "Other" level).
#' 
#' @examples
#' \dontrun{
#'  # Convert classification targets in the model build population to factors
#'  SetClassificFieldsAsFactors(datTemp=e$dat, dat=e$dat, 
#'    classificTargets=e$interimModelTargetsClassific, 
#'    classificCovShort = c(), participation=c(), e=e)
#'  
#'  # Convert classification covariates to factors
#'  SetClassificFieldsAsFactors(datTemp=datMod, dat=dat, classificTargets=c(), 
#'    classificCovShort=classificCovShort,
#'    participation=participation, e=e)
#' }
#' 
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
SetClassificFieldsAsFactors <- function(datTemp, dat, classificTargets, classificCovShort, participation, covYearsBack){
  
  # The purpose of the function is to add all columns' names that must be treated as factors in the "classificCov" vector.
  # Initially, this vector is empty.
  classificCov <- c()
  
  # if there is at least one income keypoints covariate marked as classification variable, add that keypoints' covariates for all considering periods
  # in the "classificCov" vector
  if (length(classificCovShort) != 0){
    for (i in 1:covYearsBack)
      classificCov <- c(classificCov, paste0(toupper(classificCovShort), "_B", i))
  }
  
  if ("INFORMATION ABOUT CUSTOMERS" %in% participation)
      classificCov <- c(classificCov, toupper("entity_class_b0")) 
  
  # temp variable
  clCov <- c()
  
  # Some groups of covariates include classification covariates that should be treated as factors.
  # If these groups of covariates participate in the modelling, corresponded names of classification covariates should be added in the "classificCOv" vector.
  if ("TAX REGISTRATIONS" %in% participation)
      clCov <- c(clCov, toupper("gst_reg"))
  
  if ("TAX AGENTS" %in% participation)
      clCov <- c(clCov, toupper(c("is_agent_client", "has_changed_agent", "became_agent_client", "ended_relat_with_agents")))
  
  if ("INBOUND INFO ABOUT CESSATION" %in% participation)
      clCov <- c(clCov, toupper("company_or_business_stop"))
  
  if ("REFERENCES STATUS" %in% participation)
      clCov <- c(clCov, toupper(c("is_director", "is_partner", "is_shareholder", "is_beneficiary", "ref_status_dir", "ref_status_ptr", 
                          "ref_status_shr", "ref_status_ben")))
  
   if ("REFERENCES STATUS IR6" %in% participation)
      clCov <- c(clCov, toupper("is_deceased"))
  
  if ("ENTITY CLASS" %in% participation)
      clCov <- c(clCov, toupper("entity_class_sc_tsB0", "entity_class_sc_tsB1"))
  
	
#   if ("GST RETURN EXTRACT" %in% participation)
#       clCov <- c(clCov, toupper(c("NBR_OF_GST_RETURNS")))
  
#   if ("ANNUALISED EMPLOYMENT DATA" %in% participation)
#       clCov <- c(clCov, toupper(c("NBR_OF_PAYE_RETURNS")))
  
  if (length(clCov) != 0){
    for (i in 0:covYearsBack)
	  classificCov <- c(classificCov, paste0(toupper(clCov), "_B", i))
  }  
 
  
  classificCov <- intersect(names(datTemp), classificCov)
  
  # combine classification targets and classification covariates fields (usually one of those vectors will be empty,
  # because the function is ran separately for targets and covariates)
  classificFields <- c(classificTargets, classificCov)
  
  # Convert fields from "classificCOv" to factors
  field <- c()
  foreach (field = classificFields) %do% {
    datTemp[, field] <- as.factor(datTemp[, field])
  }
  
  # At this step we check do fields from the "datTemp" dataset have levels that weren't presented in the modelling build population "dat".
  # This step is essential at the scoring stage, because factors of the scoring dataset may have levels that were absent in the modelling dataset,
  # thus the model doesn't know anything about those level and will crush. To avoid it, we rename all levels that weren't known at the modelling stage
  # as "Other" levels.
  foreach (field = classificCov) %do% {
    l1 <- levels(datTemp[, field])
    l2 <- unique(c(levels(as.factor(dat[, field])), "Other"))
    d <- setdiff(l1, l2)
    
    if (length(d) != 0){
      num <- which(levels(datTemp[, field]) %in% d)
      levels(datTemp[, field])[num] <- "Other"
    }
    
    # Make sure that each classification field of the "datTemp" dataset have all levels that this field in the "dat" dataset has + "Other" level.
    # The lane of code below, in particular, makes sure that all factors in the "datFit" dataset have the "Other" level.
    levels(datTemp[, field]) <- unique(c(levels(as.factor(dat[, field])), "Other"))
  }
  
  datTemp
}

#-------------------------------------------------------------------------------------

# SPLIT THE MODELLING POPULATION INTO TRAINING AND TESTING SETS
#' Create training and testing populations
#' 
#' \code{SplitData} splits the modelling population into training and testing sets according to
#'  a given proportion.
#' 
#' @inheritParams SetModelParameters
#' @inheritParams MakeDBConnections
#' @param dat A dataset to split into training and testing parts.
#' @param rate A real number (between 0 and 1). It shows part of the total number of rows of the input dataset, which will be 
#'  allocated to the testing set. The default value is equal to \emph{0.3}.
#' 
#' @return A list consisted of two elements: the model training dataset (\code{datFit}) and the testing dataset (\code{datHo}).
#' 
#' @examples
#' \dontrun{
#'  SplitData(dat=e$dat, rate=0.3, modRetName=e$modRetName, log=e$log, e=e)
#' }
#' 
#' @export
SplitData <- function(dat, rate=0.3, modRetName=e$modRetName, log=e$log, e){
  startM <- Sys.time()
  stepName <- "Split the data into the training and testing sets"
  
  set.seed(11)
  r <- runif(dim(dat)[1]) > rate 
  output <- list("datFit"=dat[r,], "datHo"=dat[!r,])

  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  output
}

#---------------------------------------------------------------------------------------

# SPLIT A DATASET INTO SUB-POPULATIONS
#' Split a dataset into sub-populations
#' 
#' \code{DoConditionalSplit} splits the dataset into sub-populations depending on the given \code{mask} list.
#' 
#' @inheritParams SetModelParameters
#' @inheritParams RunModelling
#' @inheritParams BuildModel
#' @inheritParams FullModelling
#' @inheritParams MakeDBConnections
#' @param dat A dataset to split into sub-populations.
#' 
#' @return A list. Each element of this list is a data frame. The length of the list is equal to the length of the \code{mask} list.
#'  However, if \code{conditionalSplit} is equal to \code{FALSE}, a list with a single element (a data frame) will be return. This 
#'  data frame will be equal to the input \code{dat} data frame. Note, depending on the \code{mask} conditions, not all rows of 
#'  the input dataset \code{dat} may be selected as part of at least one sub-population. Only rows assigned to any of sub-populations
#'  take part in further the modelling and scoring.
#' 
#' @examples
#' \dontrun{
#'  # Split the datFit population into three sub-populations
#'  DoConditionalSplit(dat=e$datFit, conditionalSplit=TRUE, 
#'    mask=list(c("B1", "B2", "B3"), c("B1", "B2", "no B3"), c("B1", "no B2")), 
#'    log=e$log, e=e)
#'  # Do not do the conditional split
#'  DoConditionalSplit(dat=e$datFit, conditionalSplit=FALSE, log=e$log, e=e)
#' }
#' 
#' @export
DoConditionalSplit <- function(dat, participation=e$participation, targetFieldsShort=e$targetFieldsShort, conditionalSplit=e$conditionalSplit, 
                              modRetName=e$modRetName, mask=eval(e$mask), ssMax=e$ssMax, stage=e$stage, log=e$log, e){  
  startM <- Sys.time()
  stepName <- "Do conditional split"
  
  datList <- list()
  
  if (conditionalSplit & "INCOME TAX RETURN FIELDS" %in% participation){
    splitField <- targetFieldsShort[[1]]
    
    # The length of the output list "datList" is equal to the length of the "mask" list.
    for (i in 1:length(mask)){
      
      splitCondition <- TRUE
      
      # Each element of the "mask" list is a vector consisted of character elements.
      # Each character string gives a condition (rule) on the population.
      # Each sub-population (element of the "datList" list) is defined by the _combination_ of rules given by all elements of corresponded vector.
      for (j in 1:length(mask[[i]])){
    
         # 1 - have returns for the certain period
         if (gregexpr("B", mask[[i]][j])[[1]][1] == 1){
           nn <- gregexpr("[0-9]", mask[[i]][j])[[1]][[1]]
      	   field <- paste0(splitField, "_B", as.numeric(substr(mask[[i]][j], nn, nn)))
      	   split <- !is.na(dat[,field])
    	   }
       
         # 2 - don't have returns for the certain period
         if (gregexpr("B", mask[[i]][j])[[1]][1] == 4){
      	   nn <- gregexpr("[0-9]", mask[[i]][j])[[1]][[1]]
      	   field <- paste0(splitField, "_B", as.numeric(substr(mask[[i]][j], nn, nn)))
      	   split <- is.na(dat[,field])
    	   }
    	 
    	   # 3 - any income returns
         if (gregexpr("any return", mask[[i]][j])[[1]][1] == 1){
      	   field <- "NUM_RETS_FILED_B0"
      	   split <- !is.na(dat[,field])
    	   }
    	 
    	   # 4 - no income returns
         if (gregexpr("no returns", mask[[i]][j])[[1]][1] == 1){
      	   field <- "NUM_RETS_FILED_B0"
      	   split <- is.na(dat[,field])
    	   }
    
        splitCondition <-  splitCondition & split	 
        
      }
      datList[[i]] <- dat[splitCondition,]
    }
    
  } else {
    if (conditionalSplit & !("INCOME TAX RETURN FIELDS" %in% participation)){
      return("Conditional data split can only be done on the base of income keypoints fields. The whole dataset will be used for modelling.")
    }
    datList[[1]] <- dat
  }
  
  if (stage == "modelling"){
    set.seed(11)
    # if some of sub-populations consist of more than ssMax elements, reduce the size of those sub-populations 
    # (randomly selecting the data set of the ssMax size)
    for (i in 1:length(datList)){
      if(dim(datList[[i]])[1] > ssMax){
        datList[[i]] <- DatSampling(datList[[i]], ssMax)
      }
    }
  }
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  datList
}


#-------------------------------------------------------------------------------------

# CLEAN COVATIATES VALUES
#' Clean modelling and scoring data
#' 
#' \code{CleanValues} cleans some income keypoints values and leaves in a population only customers with certain client status codes.
#' 
#' The cleaning procedure includes three steps:
#' \enumerate{ 
#'  \item Clean occasional negative values of the TAXABLE_INCOME keypoint (if this keypoint is used).
#'  \item Impute some missing income keypoints values as nil values. It is done for the following returns:
#'    \itemize{
#'      \item Returns that were finalised as not required (NR);
#'      \item \bold{If \code{UNbyUserIsNill} is TRUE:} Returns that were finalised as uneconomical to pursue by a staff member 
#'        (UN by user);
#'      \item \bold{If \code{considerRR} is TRUE:} Returns that were finalised as Right Returns in the previous years 
#'        (UN by SYSRR or an issued S068 letter for IR6 and IR9 return types in 2013 tax year or earlier).
#'    }
#'  \item Leave data only for customers with client statuses pointed in the \code{clientStatusList} vector.
#' }
#'  
#' @inheritParams FullModelling
#' @inheritParams CreateValues
#' @inheritParams BuildModel
#' @inheritParams MakeDBConnections
#' @inheritParams SetModelParameters
#' @param dat A data frame in which data should be cleaned up.
#' 
#' @return A data frame with cleaned data.
#' 
#' @examples
#' \dontrun{
#'  CleanValues(dat=e$dat, clientStatusList=c('A'), considerRR=FALSE, UNbyUserIsNill=TRUE, e=e)
#' }
#' 
#' @export
#' @import iterators
#' @import parallel
#' @import foreach
#' @import doParallel
CleanValues <- function(dat, clientStatusList=eval(e$clientStatusList), covFieldsShort=e$covFieldsShort, targetFieldsShort=e$targetFieldsShort, 
                        classificCovShort=e$classificCovShort, modRetName=e$modRetName, covYearsBack=e$covYearsBack, considerRR=e$considerRR, 
                        UNbyUserIsNill=e$UNbyUserIsNill, log=e$log, e){
  
  startM <- Sys.time()
  stepName <- "Clean values"
  
  # 1) Treat negative Taxable income values
  for (i in 0:covYearsBack){
    if (sum(names(dat) == paste0("TAXABLE_INCOME_B", i)) != 0){
      name <- paste0("TAXABLE_INCOME_B", i)
      dat[dat[, name] < 0 & !is.na(dat[, name]), name] <- 0
    }
  }
    
  #----------------------------------
  # 2) treat null income keypoints as 0 if a return was finalised as NR (always); UN by user (if UNbyUserIsNill is TRUE); UN by SYSRR (if considerRR is TRUE)
  if (sum(names(dat) == "FINALISATION_CODE_B1")!=0){
    field <- c()
    foreach (field = setdiff(c(covFieldsShort, targetFieldsShort), classificCovShort), .errorhandling='stop') %do%{
      for (i in 0:covYearsBack){
        finCode <- paste0("FINALISATION_CODE_B", i)
        finBy <- paste0("FINALISED_BY_B", i)
        cov <- paste0(toupper(field), "_B", i)
        
        if (sum(names(dat) == cov) != 0){
          #dat[is.na(dat[, cov]) & dat[, finCode] == 'RL' & !is.na(dat[, finCode]), cov] <- 0
          dat[is.na(dat[, cov]) & dat[, finCode] == 'NR' & !is.na(dat[, finCode]), cov] <- 0
          if (UNbyUserIsNill){
            dat[is.na(dat[, cov]) & dat[, finCode] == 'UN' & dat[, finBy] < 'A' & !is.na(dat[, finCode]) & !is.na(dat[, finBy]), cov] <- 0
          }
          if (considerRR){
            dat[is.na(dat[, cov]) & dat[, finCode] == 'UN' & dat[, finBy] == 'SYSRR' & !is.na(dat[, finCode]) & !is.na(dat[, finBy]), cov] <- 0
          }
        }
      }
    }
  }
  
  # For IR6 and IR9 only: treat null income keypoints as 0 if a S068 letter was issued 
  # (2013 tax year and earlier <- this is taken into account during covariates creation, so that we don't have to think about a tax year here)
  if (considerRR){
    if (sum(names(dat) == "S068_B1")!=0){
      field <- c()
      foreach (field = setdiff(c(covFieldsShort, targetFieldsShort), classificCovShort)) %do%{
        for (i in 0:covYearsBack){
          sCode <- paste0("S068_B", i)
          cov <- paste0(toupper(field), "_B", i)
          dat[is.na(dat[, cov]) & dat[, sCode] == 'Y' & !is.na(dat[, sCode]), cov] <- 0
        }
      }
    }
  }
  
  #------------------------------------
  # 3) leave only customers with some statuses
  if (length(clientStatusList) > 0){
    dat <- dat[dat[,"CLIENT_STATUS_B0"] %in% (clientStatusList) & !is.na(dat[,"CLIENT_STATUS_B0"]),]
  }
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
  dat
}


#-------------------------------------------------------------------

# EXCLUDE SOME TARGETS AND COVARIATES
#' Exclude some targets and covariates from the modelling
#' 
#' \code{ExcludeCovar} creates a vector of covariates and targets that should be excluded from the population.
#' 
#' The following columns will be excluded from the modelling:
#' \itemize{
#'  \item Covariates with no data available or with only a very small amount of data available (this rule is not applied for 
#'    "COMPANY_OR_BUSINESS_STOP_B0" and "COMPANY_OR_BUSINESS_STOP_B1" covariates from the "INBOUND INFO ABOUT CESSATION" covariates group).
#'  \item Redundant interim targets columns in the Outstanding Returns model.
#'  \item Several other covariates columns, which are used only for data cleaning, not for modelling (such as finalisation codes, client statuses).
#' }
#' 
#' @inheritParams BuildModel 
#' @inheritParams FullModelling
#' @inheritParams MakeDBConnections
#' @inheritParams SetModelParameters
#' @param dat A dataset. Usually it is equal to \code{datFit} (the model training population).
#' 
#' @return A list with two elements:
#'  \itemize{
#'    \item \code{excludeCov} A vector with column names which will be excluded from the consideration during the modelling.
#'    \item \code{interimModelTargets} An updated vector with interim targets names. This vector may change in the Outstanding Returns model when
#'      at least one of main target keypoints has a bi-modal distribution (only nil and positive OR nil and negative values).
#'  }
#' 
#' @examples
#' \dontrun{
#'  ExcludeCovar(dat=e$datFit, e=e)
#' }
#' 
#' @export
ExcludeCovar <- function(dat, groupCovNames=e$groupCovNames, interimModelTargets=e$interimModelTargets, returnName=e$returnName,
                            modRetName=e$modRetName, covYearsBack=e$covYearsBack, log=e$log, e){
  startM <- Sys.time()
  stepName <- "Exclude unnecessary fields"
    
  excludeCov <- c()
    
  # exclude columns without data (or almost without data - when a field's values are not empty for less than 5% of rows)
  nam <- c()
  foreach(nam=names(dat)) %do%
    if (sum(!is.na(dat[,nam])) / dim(dat)[1] * 100 < 5)
      excludeCov <- c(excludeCov, nam)
  
  # Delete redundant targets fields.
  # In the OR model all for possible interim targets (LABEL_NIL, LABEL, POS, NEG) are automatically created.
  # All four targets are used for keipoints with possible negative, nil, and positive values (keypoints with tri-modal distribution).
  # Only two targets are needed for keypoints with only nil and positive OR nil and negative possible values (keypoints with bi-modal distribution).
  # In the case of bi-modal distributed keypoint, one of POS or NEG targets will have only empty values and will be already included in the "excludeCOv" 
  # vector at the previous step. But we also do not need LABEL target for a bi-modal keypoint's modelling. So that, LABEL field also should be added in 
  # the "excludeCov" vector.
  if (length(intersect(excludeCov, interimModelTargets)) != 0){
    k <- which(interimModelTargets %in% excludeCov)
    k <- 4 * ceiling(k / 4) - 2
    excludeCov <- c(excludeCov, interimModelTargets[k])
  }
  # Update "interimModelTargets" vector accordingly 
  interimModelTargets <- setdiff(interimModelTargets, excludeCov)
        
  # exclude income keypoints for B0 period (B0 income keypoints can't participate in the model, because these covariates values are not known 
  # at the scoring stage)
  st <- length(groupCovNames[['INCOME TAX RETURN FIELDS']]) 
  while (st >= 1){
    excludeCov <- c(excludeCov, paste0(toupper(groupCovNames[['INCOME TAX RETURN FIELDS']][[st]]), "_B0"))
    st <- st-1
  }
  
#   if (toupper(returnName) %in% c("IR3", "IR3A", "IR3NR", "IR3ALL"))
#     excludeCov <- unique(c(excludeCov, "CLIENT_STATUS_B0", paste0("FINALISATION_CODE_B", 0:covYearsBack), paste0("FINALISED_BY_B", 0:covYearsBack)))
#     
#   
#   if (toupper(returnName) %in% c("IR4", "IR6", "IR7", "IR9"))
#     excludeCov <- unique(c(excludeCov, "CLIENT_STATUS_B0", paste0("FINALISATION_CODE_B", 0:covYearsBack), paste0("FINALISED_BY_B", 0:covYearsBack),
#                             paste0("S068_B", 1:covYearsBack)))
  
  # exclude other fields that are used only for data cleaning 
  excludeCov <- unique(c(excludeCov, "CLIENT_STATUS_B0", paste0("FINALISATION_CODE_B", 0:covYearsBack), paste0("FINALISED_BY_B", 0:covYearsBack),
                         paste0("S068_B", 0:covYearsBack)
                         , paste0("IS_DECEASED_B", 4:covYearsBack)
                         ))
    
  # do not exclude COMPANY_OR_BUSINESS_STOP_B0" and  "COMPANY_OR_BUSINESS_STOP_B1" covariates even if there is not enough data available (<5%)
  # because this covariates will be empty for many entities by its' nature.
  excludeCov <- setdiff(excludeCov, c("COMPANY_OR_BUSINESS_STOP_B0", "COMPANY_OR_BUSINESS_STOP_B1", "IS_DECEASED_B0", "IS_DECEASED_B1", "IS_DECEASED_B2", "IS_DECEASED_B3",
                                      "IS_DECEASED_B4", "IS_DECEASED_B5", "MAX_IS_DECEASED_B0"))
  
  output <- list("interimModelTargets"=interimModelTargets, "excludeCov"=excludeCov)
  e$log <- LogEdit(modRetName, stepName, log, startM)
    
  output
}

#-------------------------------------------------------------------------------------

# Function for imputation of missing values in the data frames.
# Only covariates values are treated.
# Missing values in classification covariates are substituted by the character "Other".
# Missing values in covariates "YEARS_SINCE_FILED_B0" and "YS_NN_..._B0" are substituted by 99.
# All other missing values are substituted by value parameter (usually 0).
#
# input:
#   datT - an input data frame with some missing values
#   value - missing values are replaced by this default value (usually 0)
#   interimModelTargets - a vector with interim model targets
#   classificCovShort - a vector of short names of classification covariates
#   stage - modelling or scoring
#   covYearsBack - the number of years we look back during the covariates creation 
#       (covariates are created for periods from 0 years back to "covYearsBack" years back)
#   targetFieldsShort - a vector of short names of main targets
# output:
#   a data frame with imputed missing values
ImputeMissingValues <- function(datT, value, interimModelTargets, classificCovShort, stage, covYearsBack, targetFieldsShort){
  namesDat <- names(datT)
  classificCov <- c()
  if (length(classificCovShort) != 0){
    for (i in 1:covYearsBack){
	  classificCov <- c(classificCov, paste0(toupper(classificCovShort), "_B", i))
	}
  } 
  
  # treat other missed values
  m <- if (stage == "modelling") {
    length(namesDat) - length(interimModelTargets)
  } else {
    length(namesDat)
  }
  
  for (name in setdiff(names(datT), c(interimModelTargets, "IRD_NUMBER", "RETURN_PERIOD_DATE_BASE", "RETURN_TYPE"))){
    if (name %in% classificCov){
      datT[is.na(datT[, name]), name] <- "Other" 
    } else {
      if (name %in% c("ENTITY_AGE", "YEARS_SINCE_FILED_B0", paste0("YS_NN_", targetFieldsShort,"_B0", collapse=""))){
        datT[is.na(datT[, name]), name] <- 999
      } else {
        datT[is.na(datT[, name]), name] <- value
      }
    }
  }
  datT
}


#-------------------------------------------------------------------------------------

# Select a random sample of the given sample size from the given data frame.
# If a desired sample size is less than an initial data frame size, the function selects a random sample from the given data frame.
# If a desired sample size is bigger than an initial data frame size, the function does the oversampling from the given data frame.
# input:
#   dataFrame - a data frame of size N
#   sampleSize - a desired size of a sample 
# output:
#   A random sample of size "sampleSize" from an input data frame "dataFrame" (with or without replacement depending on the desired sample size).
#   If an input sample size has a zero size, it is returned without changes.
DatSampling <- function(dataFrame, sampleSize){
  if (dim(dataFrame)[1] != 0){
    N <- dim(dataFrame)[1]
    if (N >= sampleSize){
      sampleRows <- sample(1:N, size=sampleSize, replace=FALSE)
      dataFrame <- dataFrame[sampleRows,]
    }
    if (N < sampleSize){
      sampleRows <- sample(1:N, size=sampleSize, replace=TRUE)
      dataFrame <- dataFrame[sampleRows,]
    }
  }
  dataFrame
}

#------------------------------------------------------------------------------------


# Right Returns function
# Apply business rules to filter Right Returns customers
# (Those business rules were introduced to reduce the number of false positive results; the bright line property test was added in 2015 year after
# changes in regulations)
#' Filter Right Returns customers
#' 
#' \code{RRDoFiltering} applies a set of business rules to filter Right Returns customers.
#' 
#' Filters remove from the RR list all customers:
#' \itemize{
#'  \item with the predicted RR_PROB_NIL value is being less than set \emph{cutOff} probability for a certain return type;
#'  \item who do not pass the bright line property test;
#' }
#' For the Individual Selection, additional filters also remove customers:
#' \itemize{
#'  \item who have Salary and Wages income for the year the selection relates to \bold{(during the 1st run only!)};
#'  \item whose non-s/w income for B1 period is more than $500 \bold{AND} their non-s/w income consists not only of dividends and interests;
#'  \item whose non-s/w income for B2 period is more than $5000.
#' }
#' 
#' @inheritParams SavingResults
#' @inheritParams FullModelling
#' @inheritParams RunRightReturns
#' @inheritParams BuildModel
#' @inheritParams PrepareFieldsNames
#' @inheritParams MakeDBConnections
#' @inheritParams CreateValues
#' @inheritParams SetModelParameters
#' @param datScor A data frame. The scoring population.
#' @param value A numeric value. A standard value to impute missing values. It is equal to 0 by default.
#' @param cutOffCoeff A real number from 0 to 1. A cut-off probability. All returns with predicted value of RR_PROB_NIL is being more than or 
#'  equal to \code{cutOffCoeff} are marked as Right Returns.
#' 
#' @return A data frame - the part of the \code{datScor} data frame, containing only Right Returns customers who weren't filtered by business rules.
#'  Only two columns are left: IRD number and return type.
#' 
#' @examples
#' \dontrun{
#'  RRDoFiltering(datScor=e$datScor, outDat=e$outDat, cutOffCoeff=0.8)
#' }
#' 
#' @export
RRDoFiltering <- function(datScor=e$datScor, outDat=e$outDat, value=0, cutOffCoeff=e$cutOffCoeff, returnName=e$returnName, runNo=e$runNo, year=e$year,
                        conn=e$conn, conn2=e$conn2, classificCovShort=e$classificCovShort, stage=e$stage, modRetName=e$modRetName, covYearsBack=e$covYearsBack,
                        targetFieldsShort=e$targetFieldsShort, log=e$log, e){
  
  startM <- Sys.time()
  stepName <- "Do filtering"
  
  
  #if (dim(datScor)[1] == 0){stop("No right returns were identified")}
  datScor <- ImputeMissingValues(datT=datScor, value=0, interimModelTargets=c(), classificCovShort, stage, covYearsBack, targetFieldsShort)
  print(dim(datScor))

  #----------------------------------
  
  if (returnName %in% c('IR3', 'IR3A', 'IR3NR', 'IR3All')){
    
    # 2) Do exclusions for IR3, IR3A, IR3NR
    # Salary and wage customers are excluded from Individual 1st run
    # (all customers who have Salary and Wages income for the year the selection relates to should be excluded)
    if (runNo == 1) {
      if (sum(names(datScor) == "EMS_WAGES_B0") == 0){
        datScor$EMS_WAGES_B0 <- datScor$EMS_PENSIONS_B0 + datScor$EMS_STUDENT_ALLOWANCE_B0 + datScor$EMS_BENEFITS_B0 + datScor$EMS_WAGES_W_B0 + 
                                datScor$EMS_WAGES_P_B0
      }
      datScor <- datScor[datScor$EMS_WAGES_B0 <= 0, ]
      print(dim(datScor))
    }
  
    # 3) Business rules 1: leave only customers that for B1 period:
    #  - don't have non-s/w income
    #  - non-s/w income consists only of dividends and interests
    #  - non-s/w income is less than $500
    
    # these three rules above are equal to the following rule: 
    # Delete customers who for the B1 period
    #  (a) have non-s/w income which is more than $500 
    #   AND
    #  (b) their non-s/w income consists not only of dividends and interests 
    # Those customers are seemed too risky to be classified as Right Returns customers.
    
    # non-s/w income without dividends and interests
    nonSWWithoutDI <- c("overseas_income_828",
    "total_estate_trust_income_806",
  	"total_partnership_income_808",
  	"total_active_ltc_income_100792",
  	"total_shareholder_salary_809",
  	"net_rents_826",
  	"net_profit_702",
  	"other_income_827")
    
    # non-s/w income including dividends and interests
    nonSWWithDI <- c("overseas_income_828",
    "total_estate_trust_income_806",
    "total_partnership_income_808",
  	"total_active_ltc_income_100792",
  	"total_shareholder_salary_809",
  	"net_rents_826",
  	"net_profit_702",
  	"other_income_827",
    "total_interest_802",
    "total_gross_dividends_804")
     
    nonSWWithoutDIB1 <- intersect(paste0(toupper(CreateShortNames(nonSWWithoutDI, transf=list())), "_B1"), names(datScor))
    nonSWWithDIB1 <- intersect(paste0(toupper(CreateShortNames(nonSWWithDI, transf=list())), "_B1"), names(datScor))
    
    # filter data from datScor
    datScor <- datScor[!(rowSums(abs(datScor[, nonSWWithoutDIB1]) != 0) != 0 & rowSums(datScor[, nonSWWithDIB1]) > 500) , ]
    print(dim(datScor))
    #if (dim(datScor)[1] == 0){stop("No right returns were identified")}
    #-----------------------------------------------
    
    # 4) Also exclude customers whose non-s/w income during the B2 period was more than $5000.
    # Again, those customers are too risky to be classified as Right Returns customers.
    nonSWWithDIB2 <- intersect(paste0(toupper(CreateShortNames(nonSWWithDI, transf=list())), "_B2"), names(datScor))
    # filter
    datScor <- datScor[rowSums(datScor[, nonSWWithDIB1]) <= 5000 , ]
    print(dim(datScor))
    #if (dim(datScor)[1] == 0){stop("No right returns were identified")}
    #----------------------------------------------
      
    #5) # output file for the 2nd Individual select should not include customers who were picked up by the 1st Individual select
    if (runNo == 2){
      exclusion <- ExcludeIrdNumbers(e=e)
      #irdNumbersIR3 <- irdNumbersInd[!(irdNumbersInd[,"IRD_NUMBER"] %in% exclusion),]
      datScor <- datScor[!(datScor[,"IRD_NUMBER"] %in% exclusion),]
    }
    
  }
  
  # 6) property filtering
  # Using the property data, we are trying to identify customers that do not pass the bright line test.
  #  - they bought a property on 01/10/2015 or after AND 
  #  - they sold the same property during the considering tax year AND
  #  - less than 2 years passed between buying and selling
  #  - any exceptions (main house, etc.) does not apply to them
  #
  # Connection between a seller and a buyer is identified by the same IRD number or the same full name.
  # Customers who do not pass the bright lane test, can not be Right Returns customers.
  
  if (year > 2015) {
    if (!dbExistsTable(conn2, "RR_PROPERTY_EXL")){
    
      sqlCode <- paste0("
        CREATE TABLE RR_PROPERTY_EXL AS
          WITH t AS
            (SELECT DISTINCT
              sell.ird_number as ird_number_seller,
              buy.ird_number as ird_number_buyer
            FROM 
              property.l_tax_statement buy
              INNER JOIN property.l_title_instrument_title buy_ti ON
                buy_ti.tin_id = buy.tin_id
              INNER JOIN property.l_tax_statement sell ON 
        		    buy.ird_number = sell.ird_number 
        		    OR regexp_replace(upper(buy.full_name),'[^A-Z0-9]','') = regexp_replace(upper(sell.full_name),'[^A-Z0-9]','')
              INNER JOIN property.l_title_instrument_title sell_ti ON
                sell_ti.tin_id = sell.tin_id
                AND buy_ti.ttl_title_no = sell_ti.ttl_title_no        
            WHERE
              buy.transferor_or_transferee = 'TTEE' AND
              sell.transferor_or_transferee = 'TTOR' AND
              sell.lodged_datetime between to_date('01/04/", year-1,"', 'dd/mm/yyyy') and to_date('31/03/", year,"', 'dd/mm/yyyy') AND
              buy.lodged_datetime >= to_date('01/10/2015', 'dd/mm/yyyy') AND
              add_months(buy.lodged_datetime, 24) >= sell.lodged_datetime AND
              sell.exemption_code IS NULL AND
        	    -- make it sure that a customer didn't own the property before 01/10/2015
              not exists 
          	    (select 1 
                  from property.i_prop_hist_own_summary_2015 s
                  where
                    s.ttl_title_no = sell_ti.ttl_title_no and
                    (s.ownerstr = regexp_replace(upper(sell.full_name),'[^A-Z0-9]','') 
                    or s.ird_number = sell.ird_number)))
          
          select ird_number_seller as ird_number from t
           union 
          select ird_number_buyer as ird_number from t")
    
      res <- dbGetQuery(conn2, sqlCode)
    }
  }
     
  exclusion <- c()
  
  if (year > 2015){
    exclusion <- dbGetQuery(conn2, "select * from RR_PROPERTY_EXL")
    print(paste0("Customers excluded by the property filter: ", sum(datScor[,"IRD_NUMBER"] %in% exclusion[,1])))
  }
    #datScorFiltered <- datScor[!(datScor[,"IRD_NUMBER"] %in% exclusion[,1]), c("IRD_NUMBER", "RETURN_TYPE")] 
    datScorFiltered <- datScor[!(datScor[,"IRD_NUMBER"] %in% exclusion[,1]),] 
    print(dim(datScorFiltered))
    #if (dim(datScor)[1] == 0){stop("No right returns were identified")}
  
  
  #--------------------
  # 1) use cutOffCoeff. Select only results with the RR_PROB_NIL value is being more than or equal to the "cutOffCoeff" coefficient.
  irdNumbers <- outDat[outDat[,"RR_PROB_NIL_4"] >= cutOffCoeff, "IRD_NUMBER"]
  datScorRR <- datScorFiltered[datScorFiltered[,"IRD_NUMBER"] %in% irdNumbers,]
  print(dim(datScorRR))
  
  e$log <- LogEdit(modRetName, stepName, log, startM)
  
	list("datScorRR"=datScorRR, "datScorFiltered"=datScorFiltered)
}

#----------------------------------------------------------------------

# The output files for Individuals 2nd run do not include customers who were picked up by the 1st Individuals run.
ExcludeIrdNumbers <- function(year=e$year, conn=e$conn, e){

	#construct start and end date of the year
	#yearRun <- format(Sys.Date(), '%Y')  -- inherited from main script
  # The 1st run is usually dome in March.
	date1 <- paste0("01/03/", year)
	date2 <- paste0("31/03/", year)

	sqlCode <- paste0("
		select distinct 
			ird_number 
		from 
			(SELECT 
				rl1.ird_number, 
				rl1.location_number, 
				rl1.return_type, 
				rl1.return_period_date, 
				rl1.TRANSACTION_STATUS, 
				ts1.description AS status_desc, 
				ts1.status_code_3,
				rl1.date_begin,
				MIN(rl1.date_applied) AS for_uniq
			FROM
				RETURN_LODGEMENTS rl1 
						LEFT OUTER JOIN RETURN_SOURCES rs1
						ON (rl1.return_source = rs1.return_source
							AND rs1.date_ceased IS NULL
							AND rs1.validated = 'Y')
						LEFT OUTER JOIN transaction_status_Codes ts1
						ON (rl1.transaction_status = ts1.transaction_status_code
							AND ts1.date_ceased IS NULL
							AND ts1.validated ='Y')
						WHERE rl1.return_type IN ('IR3','IR3A','IR3NR')                
						AND rl1.return_period_date = to_Date('", date2, "', 'dd/mm/yyyy')
						AND rl1.date_begin BETWEEN to_Date('", date1, "', 'dd/mm/yyyy') AND to_Date ('", date2, "', 'dd/mm/yyyy')
						AND rl1.date_applied BETWEEN to_Date('", date1, "', 'dd/mm/yyyy') AND to_Date ('", date2, "', 'dd/mm/yyyy')
						AND rl1.transaction_status IN ('83','84') -- RRN and RRA transaction statuses (Right Return customer without and with an agent)
						group by rl1.ird_number, rl1.location_number, rl1.return_type, rl1.return_period_date, 
							   rl1.TRANSACTION_STATUS, ts1.status_code_3, ts1.description,
								 rl1.date_begin
						order by 1,2    
				)
			")
				
	dbGetQuery(conn, sqlCode) 
}

#------------------------------------------------------------------------

DeleteOutliers <- function(dat=e$dat, modelTargets=e$modelTargets, e){
  
  filter <- TRUE
  
  for(m in modelTargets){
    
    name <- paste0(m, "_B0")
    
    if (name %in% names(dat)) {
      
      name <- paste0(m, "_POS")
      if (name %in% names(dat)) {
        q <- quantile(dat[!is.na(dat[,name]), name], probs=0.999)
        filterNew <- dat[,name] < q
        filterNew[is.na(filterNew)] <- TRUE
        filter <- filter & filterNew
      }
      
      name <- paste0(m, "_NEG")
      if (name %in% names(dat)) {
        q <- quantile(dat[!is.na(dat[,name]), name], probs=0.001)
        filterNew <- dat[,name] > q
        filterNew[is.na(filterNew)] <- TRUE
        filter <- filter & filterNew
      }
      
    }
  }
  dat <- dat[filter, ]
}

#--------------------------------------------------------------------------
#' Prepare data for modelling (impute missing values, set factors)
#' 
#' @param dat A dats set to prepare for modelling.
#' @param datList Conditionally splitted dastFit data set.
#' @param excludeCov Vector of covariates to exclude from modelling.
#' @param interimModelTargets Vecor of interim modelling targets.
#' @param participation Vector of groups of covariates to use.
#' @param classificCovShort Short names of classification covariates.
#' @param stage Stage (modeling, scoring)
#' @param covYearsBack Numeric. For how many years back covariates are craeted.
#' @param targetFieldsShort Short names of targets fields.
#' @param eval Logical. Is data being prepared for evaluation.
#' @param e Environment.
#' @export
PrepareData <- function(dat=e$dat, datList=e$datList, excludeCov=e$excludeCov, interimModelTargets=e$interimModelTargets,
                        participation=e$participation, classificCovShort=e$classificCovShort, stage=e$stage,
                        covYearsBack=e$covYearsBack, targetFieldsShort=e$targetFieldsShort, eval=FALSE, log=e$log, e){
  
  # temporary create a modelling dataframe with imputed missing values
  # we need it mainly to know all possible values of classification variables
  dat <- ImputeMissingValues(datT=dat, value=0, interimModelTargets=interimModelTargets, classificCovShort=classificCovShort, stage=stage, 
                                      covYearsBack=covYearsBack, targetFieldsShort=targetFieldsShort)
  
  i <- 1
  #foreach(i=1:2, .packages="doParallel", .export=c("ImputeMissingValues", "SetClassificFieldsAsFactors"), .errorhandling='stop') %dopar% {
  foreach(i=1:length(datList), .packages="doParallel", .export=c("ImputeMissingValues", "SetClassificFieldsAsFactors"), 
          .errorhandling='stop') %dopar% {
    
    datMod <- datList[[i]]
    if (!eval){
      datMod <- datMod[, -which(names(datMod) %in% excludeCov)]
    }
     
    datMod <- ImputeMissingValues(datT=datMod, value=0, interimModelTargets=interimModelTargets, classificCovShort=classificCovShort, stage=stage, 
                                 covYearsBack=covYearsBack, targetFieldsShort=targetFieldsShort)
     
    datMod <- SetClassificFieldsAsFactors(datTemp=datMod, dat=dat, classificTargets=c(), classificCovShort=classificCovShort, 
                                         participation=participation, covYearsBack=covYearsBack)
    
    datMod

  }
  
}

#--------------------------------------------------------------------

# Create a vector of columns that shouldn't be considered as covariates
# input:
#   RFdat - a dataset for modelling
#   interimModelTargets - a vector of interim model targets names.
#   conditionalSplit - a logical. If TRUE a few separate models are built for different parts 
#     of the model population data set (according to a value of "mask" parameter). If FALSE, one model 
#     for the whole model population is built.
#   m - a particular vector from the mask list
#   groupCovNamesInc - a vector of covariates from the Income keypoints group
# output:
#   excludeCols - a vector of NAMES of columns that should be excluded from the covariates

CreateExcludeCols <- function(datMod, conditionalSplit, mask, groupCovNamesInc, datList=e$datList, interimModelTargets=e$interimModelTargets, e){
  
  i <- 1
  foreach(i=1:length(datList), .errorhandling='stop') %dopar% {
    
    excludeCols <- which(names(datMod[[i]]) %in% c("IRD_NUMBER", "RETURN_PERIOD_DATE_BASE", "RETURN_TYPE", interimModelTargets))
    
    # Returns from the sub-population with the "c("B1", "no B2")" mask may both have B3 data and do not have it.
    # We exclude B3 income keypoints covariates from the model for this sub-population, because there is no
    # certainty here for a lot of B3 covariates are they nil or null (so that it may cause a misclassification).
    if (conditionalSplit){
      if (sum(mask[[i]] == c("B1", "no B2")) == 2){
        st <- length(groupCovNamesInc) 
        exclTemp <- c()
        while (st >= 1){
          exclTemp <- c(exclTemp, paste0(toupper(groupCovNamesInc[[st]]), "_B3"))
          st <- st-1
        }
        
        exclTemp <- which(names(datMod[[i]]) %in% exclTemp)
        excludeCols <- unique(c(excludeCols, exclTemp))
      }
    }
    
    names(datMod[[i]])[excludeCols]
    
  }
}


