
##########------BUILD RR EVALUATION REPORTS------############
#' Build evaluation reports for the Right Returns model
#' 
#' \code{RRCreateEvaluationReport} creates a set of evaluation reports for the Right Returns model, including detailed and 
#'  aggregated HTML reports and XLSM report with classification models performance (which can be used for the \emph{cutOff} coefficient 
#'  selection).
#' 
#' This function is run within the \code{\link{FullModelling}} function, but also can be run separately. 
#'  
#' @inheritParams BuildModel
#' @inheritParams DoEvaluation
#' @inheritParams FullModelling
#' @inheritParams RunModelling
#' @inheritParams JoinSptittedResults
#' @param evalInterim A list with two levels: the index of a main target and the index of an interim target. Each element of this list is a joint of 
#'  an interim model target values through all sub-populations.
#' @param evalMainRes A list with two levels: the sub-population's number and the index of a main target. This variable contains 
#'  results of calculation of the main model targets depending on the interim model targets' values and the model type.
#' @param evalAllRes A list with one level: the index of a main target. Each element of this list is a joint of a main model target values through all
#'  sub-populations.
#' 
#' @return The result of the function usage is a set of HTML reports created in the output folders. This function is designed for the Right
#'  Returns model, and it returns three types of reports:
#'  \enumerate{
#'    \item \emph{Detailed HTML reports}. They are created in the "Detailed reports" folder and contain information about performance of all interim 
#'      models.
#'    \item \emph{Aggregated HTML reports}. They are created in the "All populations together" folder and contain information about performance 
#'      of all interim models aggregated through all sub-populations.
#'    \item \emph{Classification models performance report} This XLSM report is created in the main output folder and contains performance 
#'      characteristics of the classification models. This report can be used for the \emph{cutOff} coefficients selection.
#'  }
#'  
#' @examples
#'  \dontrun{
#'    RRCreateEvaluationReport(e=e)
#'  }
#'  
#' @export
RRCreateEvaluationReport <- function(dat=e$dat, modelFits=e$modelFits, datList=e$datList, modelTargets=e$modelTargets, 
                                      interimModelTargets=e$interimModelTargets, returnName=e$returnName, outputPath=e$outputPath, 
                                      modelTargetsList=e$modelTargetsList, evalRes=e$evalRes, evalInterim=e$evalInterim, evalMainRes=e$evalMainRes, 
                                      evalAllRes=e$evalAllRes, intervals=e$intervals, outDat=e$outDat, alg=e$alg, covarImp=e$covarImp, e){
  
  #e$reportDataSet <- list()
  outputPathT <- paste0(outputPath, "HTML - classification targets\\")
  dir.create(outputPathT, showWarnings=FALSE)
  
  if (alg == "R_RF"){
    rfConfMatrix <- TRUE
    covarImpPlot <- "auto"
  }
  if (alg == "RSpark_RF"){
    rfConfMatrix <- FALSE
    covarImpPlot <- "manual"
  }
  
  #level1 (i,j,k)
  for (i in 1:length(datList)){
    for (j in 1:length(modelTargets)){
      
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text') 
      for (k in 1:length(intTargets)){
        filenameMod <- paste0(returnName, "_pop", i, "_", intTargets[k])
        CreateInterimModelsHTML(dat=dat, modelFits=modelFits, i=i, j=j, k=k, evalDataSet=evalRes[[i]][[j]][[k]], filenameMod=filenameMod, 
          outputPath=paste0(outputPathT, "Detailed reports\\"), rfConfMatrix=rfConfMatrix, covarImpPlot=covarImpPlot, covarImp=covarImp,
          intTargets=intTargets[k], intervals=intervals, alg=alg, e=e)
      }
    }
  }
  
  #level2 (j,k)
  for (j in 1:length(modelTargets)){
    
    intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text') 
    for (k in 1:length(intTargets)){
      filenameMod <- paste0(returnName, "_", intTargets[k])
      CreateInterimModelsHTML(dat=dat, modelFits=modelFits, j=j, k=k, evalDataSet=evalInterim[[j]][[k]], filenameMod=filenameMod, 
        outputPath=paste0(outputPathT, "All populations together\\"), rfConfMatrix=FALSE, covarImpPlot="none", intTargets=intTargets[k], intervals=intervals, alg=alg, e=e)
    }
  }
  
  # classification performance XLSM reports (in the RR model, for all targets. That's why modelTargetsList=modelTargets). 
  CreateClassificationExcelReport(returnName=returnName, outputPath=outputPath, modelTargets=modelTargets, modelTargetsList=modelTargets, datList=datList, 
                                  evalRes=evalRes, evalInterim=evalInterim, intervals=intervals, sumReport=TRUE, outDat=outDat)
  
}

#--------------------------------------------------------------------------------------------------------------------------

##########------BUILD OR / RP EVALUATION REPORTS------############
#' Build evaluation reports for the Outstanding Returns model
#' 
#' \code{ORCreateEvaluationReport} creates a set of evaluation reports for the Outstanding Returns model, including detailed and 
#'  aggregated HTML reports and XLSM report with classification models performance.
#' 
#' This function is run within the \code{\link{FullModelling}} function, but also can be run separately. 
#'  
#' @inheritParams BuildModel
#' @inheritParams DoEvaluation
#' @inheritParams FullModelling
#' @inheritParams RunModelling
#' @inheritParams JoinSptittedResults
#' @param evalInterim A list with two levels: the index of a main target and the index of an interim target. Each element of this list is a joint of 
#'  an interim model target values through all sub-populations.
#' @param evalMainRes A list with two levels: the sub-population's number and the index of a main target. This variable contains 
#'  results of calculation of the main model targets depending on the interim model targets' values and the model type.
#' @param evalAllRes A list with one level: the index of a main target. Each element of this list is a joint of a main model target values through all
#'  sub-populations.
#' 
#' @return The result of the function usage is a set of reports created in the output folders. This function is designed for the Outstanding
#'  Returns model, and it returns three types of reports:
#'  \enumerate{
#'    \item \emph{Detailed HTML reports}. They are created in the "Detailed reports" folder and contain information about performance of all interim 
#'      models. Reports have different content for classification and regression interim models.
#'    \item \emph{Aggregated main targets reports}. They are created in the "Main targets reports" folder and contain information about performance 
#'      of all main models (results presented separately for each sub-population). 
#'    \item \emph{Classification models performance report} This XLSM report is created in the main output folder and contains performance 
#'      characteristics of the purification targets (if any). This report can be used for the \emph{cutOff} coefficients selection.
#'  }
#'  
#' @examples
#'  \dontrun{
#'    ORCreateEvaluationReport(e=e)
#'  }
#'  
#' @export
ORCreateEvaluationReport <- function(dat=e$dat, modelFits=e$modelFits, datList=e$datList, modelTargets=e$modelTargets, 
                                     interimModelTargets=e$interimModelTargets, returnName=e$returnName, 
                                     outputPath=e$outputPath, modelTargetsList=e$modelTargetsList, evalRes=e$evalRes, 
                                     evalInterim=e$evalInterim, evalMainRes=e$evalMainRes, evalAllRes=e$evalAllRes, 
                                     intervals=e$intervals, alg=e$alg, covarImp=e$covarImp, e){
  
  #e$reportDataSet <- list()
  
  # If the model contains both Outstanding returns targets and Purification targets, detailed HTML reports are created in different sub-folders:
  outputPath1 <- paste0(outputPath, "HTML - returns value targets\\")
  outputPath2 <- paste0(outputPath, "HTML - classification targets\\")
  dir.create(outputPath1, showWarnings=FALSE)
  dir.create(outputPath2, showWarnings=FALSE)
  
  if (alg == "R_RF"){
    rfConfMatrix <- TRUE
    covarImpPlot <- "auto"
  }
  if (alg == "RSpark_RF"){
    rfConfMatrix <- FALSE
    covarImpPlot <- "manual"
  }
  
  # reports of level 1 and level 3 were left as the most informative for stakeholders
  
  #level1 (i,j,k)
  for (i in 1:length(datList)){
    for (j in 1:length(modelTargets)){
      
      if (modelTargets[j] %in% modelTargetsList){
        outputPathT <- outputPath2
      } else {
        outputPathT <- paste0(outputPath1, "Detailed reports\\")
      }
      
      intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text') 
      for (k in 1:length(intTargets)){
        filenameMod <- paste0(returnName, "_pop", i, "_", intTargets[k])
        CreateInterimModelsHTML(dat=dat, modelFits=modelFits, i=i, j=j, k=k, evalDataSet=evalRes[[i]][[j]][[k]], filenameMod=filenameMod, 
          outputPath=outputPathT, rfConfMatrix=rfConfMatrix, covarImpPlot=covarImpPlot, intTargets=intTargets[k], intervals=intervals, covarImp=covarImp, alg=alg,
          e=e)
      }
    }
  }
  
#   #level2 (j,k)
#   for (j in 1:length(modelTargets)){
#     intTargets <- ChoseInterimModels(modelTargets[j], interimModelTargets, numORtext='text') 
#     for (k in 1:length(intTargets)){
#       filenameMod <- paste0(returnName, "_", intTargets[k])
#       CreateInterimModelsHTML(j=j, k=k, evalDataSet=evalInterim[[j]][[k]], filenameMod=filenameMod, 
#         outputPath=paste0(outputPath, "Level2(j,k)\\"), rfConfMatrix=FALSE, intTargets=intTargets[k], e=e)
#     }
#   }
  
  #level3 (i,j)
  for (i in 1:length(datList)){
    for (j in 1:length(modelTargets)){
      if (!(modelTargets[j] %in% modelTargetsList)){
        outputPathT <- outputPath1
        filenameMod <- paste0(returnName, "_pop", i, "_", modelTargets[j])
        CreateMainModelsHTML(i=i, j=j, evalDataSet=evalMainRes[[i]][[j]], filenameMod=filenameMod, outputPath=paste0(outputPathT, "Main targets reports\\"))
      }
    }
  }
  
  #   #level4 (j)
  #   for (j in 1:length(modelTargets)){
  #     filenameMod <- paste0(returnName, "_", modelTargets[j])
  #     CreateMainModelsHTML(j=j, evalDataSet=evalAllRes[[j]], filenameMod=filenameMod, outputPath=paste0(outputPath, "Level4(j)\\"), e=e)
  #   }
  
  # delete empty folders
  if (length(list.files(path=outputPath1)) == 0) unlink(x=substr(outputPath1, 1, nchar(outputPath1)-1), recursive=TRUE)
  if (length(list.files(path=outputPath2)) == 0) unlink(x=substr(outputPath2, 1, nchar(outputPath2)-1), recursive=TRUE)  
  
  
  
  # Classification performance report (xlsm)  
  # In the OR model, this report is created only for purification targets (that's why modelTargetsList=modelTargetsList)
  CreateClassificationExcelReport(returnName=returnName, outputPath=outputPath, modelTargets=modelTargets, modelTargetsList=modelTargetsList, datList=datList, 
                                  evalRes=evalRes, evalInterim=evalInterim, intervals=intervals, sumReport=FALSE)
  
}
