##

# Do on the package loading:
#.onLoad <- function(libname, pkgname){
#}

# Show the start up message on the package attachment
.onAttach <- function(libname, pkgname){
  #if (!exists("e", mode="environment")){
  #     assign("e", new.env(), envir=as.environment("package:returnsModel"))
  #     e$conn <- ""
  #     e$conn1 <- ""
  #     e$log <- ""
  packageStartupMessage("Start with 'help(package=returnsModel)' to read information about the package.")
  #} else {stop("Please clear the workspace")}
}

